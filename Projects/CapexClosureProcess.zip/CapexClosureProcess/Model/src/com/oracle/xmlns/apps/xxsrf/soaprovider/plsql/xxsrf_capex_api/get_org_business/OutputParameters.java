
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.get_org_business;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GET_ORG_BUSINESS" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/get_org_business/}APPS.SRF_FLEX_TABLE" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getorgbusiness"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GET_ORG_BUSINESS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/get_org_business/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFFLEXTABLE> getorgbusiness;

    /**
     * Gets the value of the getorgbusiness property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFFLEXTABLE }{@code >}
     *     
     */
    public JAXBElement<APPSSRFFLEXTABLE> getGETORGBUSINESS() {
        return getorgbusiness;
    }

    /**
     * Sets the value of the getorgbusiness property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFFLEXTABLE }{@code >}
     *     
     */
    public void setGETORGBUSINESS(JAXBElement<APPSSRFFLEXTABLE> value) {
        this.getorgbusiness = ((JAXBElement<APPSSRFFLEXTABLE> ) value);
    }

}
