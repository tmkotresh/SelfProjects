
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETASSETVALUE" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/}APPS.SRF_ASSET_CALC_TAB" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getassetvalue"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GETASSETVALUE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFASSETCALCTAB> getassetvalue;

    /**
     * Gets the value of the getassetvalue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFASSETCALCTAB }{@code >}
     *     
     */
    public JAXBElement<APPSSRFASSETCALCTAB> getGETASSETVALUE() {
        return getassetvalue;
    }

    /**
     * Sets the value of the getassetvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFASSETCALCTAB }{@code >}
     *     
     */
    public void setGETASSETVALUE(JAXBElement<APPSSRFASSETCALCTAB> value) {
        this.getassetvalue = ((JAXBElement<APPSSRFASSETCALCTAB> ) value);
    }

}
