
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.closecapex;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.closecapex package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InputParametersCCAPEXCLOSUREDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_CAPEX_CLOSURE_DATE");
    private final static QName _InputParametersCUNIT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_UNIT");
    private final static QName _InputParametersCPRODUCT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_PRODUCT");
    private final static QName _InputParametersCBUSINESS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_BUSINESS");
    private final static QName _InputParametersCREMARKS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_REMARKS");
    private final static QName _InputParametersCSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_STATUS");
    private final static QName _InputParametersCCAPITALIZATIONDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_CAPITALIZATION_DATE");
    private final static QName _InputParametersCCAPITALIZATIONCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_CAPITALIZATION_COST");
    private final static QName _InputParametersCCAPEXNUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "C_CAPEX_NUMBER");
    private final static QName _OutputParametersREQUESTSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", "REQUEST_STATUS");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.closecapex
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_CAPEX_CLOSURE_DATE", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCCAPEXCLOSUREDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCCAPEXCLOSUREDATE_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_UNIT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCUNIT(String value) {
        return new JAXBElement<String>(_InputParametersCUNIT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_PRODUCT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCPRODUCT(String value) {
        return new JAXBElement<String>(_InputParametersCPRODUCT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_BUSINESS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUSINESS(String value) {
        return new JAXBElement<String>(_InputParametersCBUSINESS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_REMARKS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCREMARKS(String value) {
        return new JAXBElement<String>(_InputParametersCREMARKS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_STATUS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCSTATUS(String value) {
        return new JAXBElement<String>(_InputParametersCSTATUS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_CAPITALIZATION_DATE", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCCAPITALIZATIONDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCCAPITALIZATIONDATE_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_CAPITALIZATION_COST", scope = InputParameters.class)
    public JAXBElement<BigDecimal> createInputParametersCCAPITALIZATIONCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InputParametersCCAPITALIZATIONCOST_QNAME, BigDecimal.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "C_CAPEX_NUMBER", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXNUMBER(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXNUMBER_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", name = "REQUEST_STATUS", scope = OutputParameters.class)
    public JAXBElement<String> createOutputParametersREQUESTSTATUS(String value) {
        return new JAXBElement<String>(_OutputParametersREQUESTSTATUS_QNAME, String.class, OutputParameters.class, value);
    }

}
