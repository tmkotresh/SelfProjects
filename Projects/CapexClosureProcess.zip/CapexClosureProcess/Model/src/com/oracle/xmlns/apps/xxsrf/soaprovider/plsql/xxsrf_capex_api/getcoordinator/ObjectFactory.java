
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcoordinator;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcoordinator package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OutputParametersGETCOORDINATOR_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "GETCOORDINATOR");
    private final static QName _InputParametersCUSER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "C_USER");
    private final static QName _APPSSRFUSEROBJUSERSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "USER_STATUS");
    private final static QName _APPSSRFUSEROBJOUNAME_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "OU_NAME");
    private final static QName _APPSSRFUSEROBJOU_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "OU");
    private final static QName _APPSSRFUSEROBJPERSONID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "PERSON_ID");
    private final static QName _APPSSRFUSEROBJUSERNAME_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "USER_NAME");
    private final static QName _APPSSRFUSEROBJUNITNAME_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "UNIT_NAME");
    private final static QName _APPSSRFUSEROBJUSERID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "USER_ID");
    private final static QName _APPSSRFUSEROBJEMPLOYEENUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "EMPLOYEE_NUMBER");
    private final static QName _APPSSRFUSEROBJUNIT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "UNIT");
    private final static QName _APPSSRFUSEROBJFULLNAME_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "FULL_NAME");
    private final static QName _APPSSRFUSEROBJEMPLOYEEEMAIL_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "EMPLOYEE_EMAIL");
    private final static QName _APPSSRFUSEROBJUSEREMAIL_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", "USER_EMAIL");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcoordinator
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFUSERTABLE }
     * 
     */
    public APPSSRFUSERTABLE createAPPSSRFUSERTABLE() {
        return new APPSSRFUSERTABLE();
    }

    /**
     * Create an instance of {@link APPSSRFUSEROBJ }
     * 
     */
    public APPSSRFUSEROBJ createAPPSSRFUSEROBJ() {
        return new APPSSRFUSEROBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFUSERTABLE }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "GETCOORDINATOR", scope = OutputParameters.class)
    public JAXBElement<APPSSRFUSERTABLE> createOutputParametersGETCOORDINATOR(APPSSRFUSERTABLE value) {
        return new JAXBElement<APPSSRFUSERTABLE>(_OutputParametersGETCOORDINATOR_QNAME, APPSSRFUSERTABLE.class, OutputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "C_USER", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCUSER(String value) {
        return new JAXBElement<String>(_InputParametersCUSER_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "USER_STATUS", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJUSERSTATUS(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJUSERSTATUS_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "OU_NAME", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJOUNAME(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJOUNAME_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "OU", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFUSEROBJOU(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFUSEROBJOU_QNAME, BigDecimal.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "PERSON_ID", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFUSEROBJPERSONID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFUSEROBJPERSONID_QNAME, BigDecimal.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "USER_NAME", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJUSERNAME(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJUSERNAME_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "UNIT_NAME", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJUNITNAME(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJUNITNAME_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "USER_ID", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFUSEROBJUSERID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFUSEROBJUSERID_QNAME, BigDecimal.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "EMPLOYEE_NUMBER", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJEMPLOYEENUMBER(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJEMPLOYEENUMBER_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "UNIT", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJUNIT(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJUNIT_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "FULL_NAME", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJFULLNAME(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJFULLNAME_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "EMPLOYEE_EMAIL", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJEMPLOYEEEMAIL(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJEMPLOYEEEMAIL_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcoordinator/", name = "USER_EMAIL", scope = APPSSRFUSEROBJ.class)
    public JAXBElement<String> createAPPSSRFUSEROBJUSEREMAIL(String value) {
        return new JAXBElement<String>(_APPSSRFUSEROBJUSEREMAIL_QNAME, String.class, APPSSRFUSEROBJ.class, value);
    }

}
