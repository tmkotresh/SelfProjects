
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getbudgetrefdtl;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APPS.SRF_BUDGETREF_OBJ complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_BUDGETREF_OBJ">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CAPEX_NUMBER" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_TITLE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BUDGET_REF" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BUDGET_REF_AMOUNT" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_BUDGETREF_OBJ", propOrder = {
    "capexnumber",
    "capextitle",
    "budgetref",
    "budgetrefamount"
})
public class APPSSRFBUDGETREFOBJ {

    @XmlElementRef(name = "CAPEX_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexnumber;
    @XmlElementRef(name = "CAPEX_TITLE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capextitle;
    @XmlElementRef(name = "BUDGET_REF", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", type = JAXBElement.class)
    protected JAXBElement<String> budgetref;
    @XmlElementRef(name = "BUDGET_REF_AMOUNT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> budgetrefamount;

    /**
     * Gets the value of the capexnumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXNUMBER() {
        return capexnumber;
    }

    /**
     * Sets the value of the capexnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXNUMBER(JAXBElement<String> value) {
        this.capexnumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capextitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXTITLE() {
        return capextitle;
    }

    /**
     * Sets the value of the capextitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXTITLE(JAXBElement<String> value) {
        this.capextitle = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the budgetref property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBUDGETREF() {
        return budgetref;
    }

    /**
     * Sets the value of the budgetref property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBUDGETREF(JAXBElement<String> value) {
        this.budgetref = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the budgetrefamount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getBUDGETREFAMOUNT() {
        return budgetrefamount;
    }

    /**
     * Sets the value of the budgetrefamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setBUDGETREFAMOUNT(JAXBElement<BigDecimal> value) {
        this.budgetrefamount = ((JAXBElement<BigDecimal> ) value);
    }

}
