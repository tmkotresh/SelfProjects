
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexdtl;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexdtl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _APPSSRFCAPEXOBJCAPEXSEQNO_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_SEQ_NO");
    private final static QName _APPSSRFCAPEXOBJCAPEXCLOSUREDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_CLOSURE_DATE");
    private final static QName _APPSSRFCAPEXOBJCOORDINATOR_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CO_ORDINATOR");
    private final static QName _APPSSRFCAPEXOBJCAPEXCATEGORY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_CATEGORY");
    private final static QName _APPSSRFCAPEXOBJDEPARTMENT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "DEPARTMENT");
    private final static QName _APPSSRFCAPEXOBJNOTBUDGETEDFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "NOTBUDGETED_FLAG");
    private final static QName _APPSSRFCAPEXOBJCAPEXSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_STATUS");
    private final static QName _APPSSRFCAPEXOBJBUSINESS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "BUSINESS");
    private final static QName _APPSSRFCAPEXOBJCAPEXCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_COST");
    private final static QName _APPSSRFCAPEXOBJPAYMENTSCHEDULE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "PAYMENT_SCHEDULE");
    private final static QName _APPSSRFCAPEXOBJROIREALISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ROI_REALISTIC");
    private final static QName _APPSSRFCAPEXOBJCAPEXTITLE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_TITLE");
    private final static QName _APPSSRFCAPEXOBJSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "STATUS");
    private final static QName _APPSSRFCAPEXOBJSCHEDULEDATEOFCOMPLETION_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "SCHEDULE_DATE_OF_COMPLETION");
    private final static QName _APPSSRFCAPEXOBJREPLACEMENTFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "REPLACEMENT_FLAG");
    private final static QName _APPSSRFCAPEXOBJROIPESSIMISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ROI_PESSIMISTIC");
    private final static QName _APPSSRFCAPEXOBJPURPOSE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "PURPOSE");
    private final static QName _APPSSRFCAPEXOBJBUDGETREF_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "BUDGET_REF");
    private final static QName _APPSSRFCAPEXOBJEMPLOYEENUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "EMPLOYEE_NUMBER");
    private final static QName _APPSSRFCAPEXOBJCAPEXTYPE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_TYPE");
    private final static QName _APPSSRFCAPEXOBJBUDGETEDFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "BUDGETED_FLAG");
    private final static QName _APPSSRFCAPEXOBJCAPEXDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_DATE");
    private final static QName _APPSSRFCAPEXOBJORIGINALSCHEDULEDATEOFCOMP_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ORIGINAL_SCHEDULE_DATE_OF_COMP");
    private final static QName _APPSSRFCAPEXOBJCAPEXID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_ID");
    private final static QName _APPSSRFCAPEXOBJCOSTCENTER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "COST_CENTER");
    private final static QName _APPSSRFCAPEXOBJCAPEXSUBTITLE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_SUB_TITLE");
    private final static QName _APPSSRFCAPEXOBJUNIT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "UNIT");
    private final static QName _APPSSRFCAPEXOBJORIGINALCAPEXCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ORIGINAL_CAPEX_COST");
    private final static QName _APPSSRFCAPEXOBJBUDGETREFAMOUNT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "BUDGET_REF_AMOUNT");
    private final static QName _APPSSRFCAPEXOBJASSETCATEGORY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ASSET_CATEGORY");
    private final static QName _APPSSRFCAPEXOBJORGID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ORG_ID");
    private final static QName _APPSSRFCAPEXOBJCAPEXNUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "CAPEX_NUMBER");
    private final static QName _APPSSRFCAPEXOBJROIOPTIMISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "ROI_OPTIMISTIC");
    private final static QName _APPSSRFCAPEXOBJPRODUCT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "PRODUCT");
    private final static QName _InputParametersCCAPEXNO_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "C_CAPEXNO");
    private final static QName _OutputParametersGETCAPEXDTL_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", "GETCAPEXDTL");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexdtl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFCAPEXTAB }
     * 
     */
    public APPSSRFCAPEXTAB createAPPSSRFCAPEXTAB() {
        return new APPSSRFCAPEXTAB();
    }

    /**
     * Create an instance of {@link APPSSRFCAPEXOBJ }
     * 
     */
    public APPSSRFCAPEXOBJ createAPPSSRFCAPEXOBJ() {
        return new APPSSRFCAPEXOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_SEQ_NO", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXSEQNO(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXSEQNO_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_CLOSURE_DATE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<XMLGregorianCalendar> createAPPSSRFCAPEXOBJCAPEXCLOSUREDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_APPSSRFCAPEXOBJCAPEXCLOSUREDATE_QNAME, XMLGregorianCalendar.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CO_ORDINATOR", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCOORDINATOR(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCOORDINATOR_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_CATEGORY", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXCATEGORY(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXCATEGORY_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "DEPARTMENT", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJDEPARTMENT(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJDEPARTMENT_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "NOTBUDGETED_FLAG", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJNOTBUDGETEDFLAG(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJNOTBUDGETEDFLAG_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_STATUS", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXSTATUS(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXSTATUS_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "BUSINESS", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJBUSINESS(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJBUSINESS_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_COST", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFCAPEXOBJCAPEXCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFCAPEXOBJCAPEXCOST_QNAME, BigDecimal.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "PAYMENT_SCHEDULE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJPAYMENTSCHEDULE(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJPAYMENTSCHEDULE_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ROI_REALISTIC", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJROIREALISTIC(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJROIREALISTIC_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_TITLE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXTITLE(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXTITLE_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "STATUS", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJSTATUS(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJSTATUS_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "SCHEDULE_DATE_OF_COMPLETION", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<XMLGregorianCalendar> createAPPSSRFCAPEXOBJSCHEDULEDATEOFCOMPLETION(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_APPSSRFCAPEXOBJSCHEDULEDATEOFCOMPLETION_QNAME, XMLGregorianCalendar.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "REPLACEMENT_FLAG", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJREPLACEMENTFLAG(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJREPLACEMENTFLAG_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ROI_PESSIMISTIC", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJROIPESSIMISTIC(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJROIPESSIMISTIC_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "PURPOSE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJPURPOSE(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJPURPOSE_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "BUDGET_REF", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJBUDGETREF(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJBUDGETREF_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "EMPLOYEE_NUMBER", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJEMPLOYEENUMBER(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJEMPLOYEENUMBER_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_TYPE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXTYPE(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXTYPE_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "BUDGETED_FLAG", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJBUDGETEDFLAG(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJBUDGETEDFLAG_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_DATE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<XMLGregorianCalendar> createAPPSSRFCAPEXOBJCAPEXDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_APPSSRFCAPEXOBJCAPEXDATE_QNAME, XMLGregorianCalendar.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ORIGINAL_SCHEDULE_DATE_OF_COMP", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<XMLGregorianCalendar> createAPPSSRFCAPEXOBJORIGINALSCHEDULEDATEOFCOMP(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_APPSSRFCAPEXOBJORIGINALSCHEDULEDATEOFCOMP_QNAME, XMLGregorianCalendar.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_ID", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXID(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXID_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "COST_CENTER", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCOSTCENTER(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCOSTCENTER_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_SUB_TITLE", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXSUBTITLE(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXSUBTITLE_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "UNIT", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJUNIT(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJUNIT_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ORIGINAL_CAPEX_COST", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFCAPEXOBJORIGINALCAPEXCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFCAPEXOBJORIGINALCAPEXCOST_QNAME, BigDecimal.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "BUDGET_REF_AMOUNT", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFCAPEXOBJBUDGETREFAMOUNT(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFCAPEXOBJBUDGETREFAMOUNT_QNAME, BigDecimal.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ASSET_CATEGORY", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJASSETCATEGORY(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJASSETCATEGORY_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ORG_ID", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFCAPEXOBJORGID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFCAPEXOBJORGID_QNAME, BigDecimal.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "CAPEX_NUMBER", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJCAPEXNUMBER(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJCAPEXNUMBER_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "ROI_OPTIMISTIC", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJROIOPTIMISTIC(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJROIOPTIMISTIC_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "PRODUCT", scope = APPSSRFCAPEXOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXOBJPRODUCT(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXOBJPRODUCT_QNAME, String.class, APPSSRFCAPEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "C_CAPEXNO", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXNO(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXNO_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFCAPEXTAB }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", name = "GETCAPEXDTL", scope = OutputParameters.class)
    public JAXBElement<APPSSRFCAPEXTAB> createOutputParametersGETCAPEXDTL(APPSSRFCAPEXTAB value) {
        return new JAXBElement<APPSSRFCAPEXTAB>(_OutputParametersGETCAPEXDTL_QNAME, APPSSRFCAPEXTAB.class, OutputParameters.class, value);
    }

}
