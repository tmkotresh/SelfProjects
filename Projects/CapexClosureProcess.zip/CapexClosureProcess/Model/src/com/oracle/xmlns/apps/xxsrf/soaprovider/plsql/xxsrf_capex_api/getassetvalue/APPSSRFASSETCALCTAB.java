
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APPS.SRF_ASSET_CALC_TAB complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_ASSET_CALC_TAB">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETASSETVALUE_ITEM" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/}APPS.SRF_ASSET_CALC_OBJ" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_ASSET_CALC_TAB", propOrder = {
    "getassetvalueitem"
})
public class APPSSRFASSETCALCTAB {

    @XmlElement(name = "GETASSETVALUE_ITEM", nillable = true)
    protected List<APPSSRFASSETCALCOBJ> getassetvalueitem;

    /**
     * Gets the value of the getassetvalueitem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the getassetvalueitem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGETASSETVALUEITEM().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link APPSSRFASSETCALCOBJ }
     * 
     * 
     */
    public List<APPSSRFASSETCALCOBJ> getGETASSETVALUEITEM() {
        if (getassetvalueitem == null) {
            getassetvalueitem = new ArrayList<APPSSRFASSETCALCOBJ>();
        }
        return this.getassetvalueitem;
    }

}
