
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexdtl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETCAPEXDTL" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/}APPS.SRF_CAPEX_TAB" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getcapexdtl"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GETCAPEXDTL", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFCAPEXTAB> getcapexdtl;

    /**
     * Gets the value of the getcapexdtl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFCAPEXTAB }{@code >}
     *     
     */
    public JAXBElement<APPSSRFCAPEXTAB> getGETCAPEXDTL() {
        return getcapexdtl;
    }

    /**
     * Sets the value of the getcapexdtl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFCAPEXTAB }{@code >}
     *     
     */
    public void setGETCAPEXDTL(JAXBElement<APPSSRFCAPEXTAB> value) {
        this.getcapexdtl = ((JAXBElement<APPSSRFCAPEXTAB> ) value);
    }

}
