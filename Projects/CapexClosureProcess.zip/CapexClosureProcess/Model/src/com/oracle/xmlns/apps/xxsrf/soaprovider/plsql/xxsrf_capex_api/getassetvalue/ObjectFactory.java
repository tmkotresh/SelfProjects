
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InputParametersCCOMBINATION1_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "C_COMBINATION1");
    private final static QName _InputParametersCBU_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "C_BU");
    private final static QName _APPSSRFASSETCALCOBJORIGINALCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "ORIGINAL_COST");
    private final static QName _APPSSRFASSETCALCOBJDEPRNRESERVE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "DEPRN_RESERVE");
    private final static QName _APPSSRFASSETCALCOBJDATESERVICE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "DATE_SERVICE");
    private final static QName _APPSSRFASSETCALCOBJLIFE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "LIFE");
    private final static QName _APPSSRFASSETCALCOBJNETBOOKVALUE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "NET_BOOK_VALUE");
    private final static QName _APPSSRFASSETCALCOBJBOOK_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "BOOK");
    private final static QName _APPSSRFASSETCALCOBJASSETID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "ASSET_ID");
    private final static QName _APPSSRFASSETCALCOBJASSETDESC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "ASSET_DESC");
    private final static QName _OutputParametersGETASSETVALUE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", "GETASSETVALUE");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFASSETCALCTAB }
     * 
     */
    public APPSSRFASSETCALCTAB createAPPSSRFASSETCALCTAB() {
        return new APPSSRFASSETCALCTAB();
    }

    /**
     * Create an instance of {@link APPSSRFASSETCALCOBJ }
     * 
     */
    public APPSSRFASSETCALCOBJ createAPPSSRFASSETCALCOBJ() {
        return new APPSSRFASSETCALCOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "C_COMBINATION1", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCOMBINATION1(String value) {
        return new JAXBElement<String>(_InputParametersCCOMBINATION1_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "C_BU", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBU(String value) {
        return new JAXBElement<String>(_InputParametersCBU_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "ORIGINAL_COST", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFASSETCALCOBJORIGINALCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFASSETCALCOBJORIGINALCOST_QNAME, BigDecimal.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "DEPRN_RESERVE", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFASSETCALCOBJDEPRNRESERVE(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFASSETCALCOBJDEPRNRESERVE_QNAME, BigDecimal.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "DATE_SERVICE", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<XMLGregorianCalendar> createAPPSSRFASSETCALCOBJDATESERVICE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_APPSSRFASSETCALCOBJDATESERVICE_QNAME, XMLGregorianCalendar.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "LIFE", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFASSETCALCOBJLIFE(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFASSETCALCOBJLIFE_QNAME, BigDecimal.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "NET_BOOK_VALUE", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFASSETCALCOBJNETBOOKVALUE(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFASSETCALCOBJNETBOOKVALUE_QNAME, BigDecimal.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "BOOK", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<String> createAPPSSRFASSETCALCOBJBOOK(String value) {
        return new JAXBElement<String>(_APPSSRFASSETCALCOBJBOOK_QNAME, String.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "ASSET_ID", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFASSETCALCOBJASSETID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFASSETCALCOBJASSETID_QNAME, BigDecimal.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "ASSET_DESC", scope = APPSSRFASSETCALCOBJ.class)
    public JAXBElement<String> createAPPSSRFASSETCALCOBJASSETDESC(String value) {
        return new JAXBElement<String>(_APPSSRFASSETCALCOBJASSETDESC_QNAME, String.class, APPSSRFASSETCALCOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFASSETCALCTAB }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", name = "GETASSETVALUE", scope = OutputParameters.class)
    public JAXBElement<APPSSRFASSETCALCTAB> createOutputParametersGETASSETVALUE(APPSSRFASSETCALCTAB value) {
        return new JAXBElement<APPSSRFASSETCALCTAB>(_OutputParametersGETASSETVALUE_QNAME, APPSSRFASSETCALCTAB.class, OutputParameters.class, value);
    }

}
