
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetvalue;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for APPS.SRF_ASSET_CALC_OBJ complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_ASSET_CALC_OBJ">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ASSET_ID" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ASSET_DESC" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BOOK" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DATE_SERVICE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="LIFE" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ORIGINAL_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="DEPRN_RESERVE" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="NET_BOOK_VALUE" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_ASSET_CALC_OBJ", propOrder = {
    "assetid",
    "assetdesc",
    "book",
    "dateservice",
    "life",
    "originalcost",
    "deprnreserve",
    "netbookvalue"
})
public class APPSSRFASSETCALCOBJ {

    @XmlElementRef(name = "ASSET_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> assetid;
    @XmlElementRef(name = "ASSET_DESC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<String> assetdesc;
    @XmlElementRef(name = "BOOK", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<String> book;
    @XmlElementRef(name = "DATE_SERVICE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> dateservice;
    @XmlElementRef(name = "LIFE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> life;
    @XmlElementRef(name = "ORIGINAL_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> originalcost;
    @XmlElementRef(name = "DEPRN_RESERVE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> deprnreserve;
    @XmlElementRef(name = "NET_BOOK_VALUE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetvalue/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> netbookvalue;

    /**
     * Gets the value of the assetid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getASSETID() {
        return assetid;
    }

    /**
     * Sets the value of the assetid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setASSETID(JAXBElement<BigDecimal> value) {
        this.assetid = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the assetdesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getASSETDESC() {
        return assetdesc;
    }

    /**
     * Sets the value of the assetdesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setASSETDESC(JAXBElement<String> value) {
        this.assetdesc = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the book property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBOOK() {
        return book;
    }

    /**
     * Sets the value of the book property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBOOK(JAXBElement<String> value) {
        this.book = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the dateservice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getDATESERVICE() {
        return dateservice;
    }

    /**
     * Sets the value of the dateservice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setDATESERVICE(JAXBElement<XMLGregorianCalendar> value) {
        this.dateservice = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the life property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getLIFE() {
        return life;
    }

    /**
     * Sets the value of the life property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setLIFE(JAXBElement<BigDecimal> value) {
        this.life = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the originalcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getORIGINALCOST() {
        return originalcost;
    }

    /**
     * Sets the value of the originalcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setORIGINALCOST(JAXBElement<BigDecimal> value) {
        this.originalcost = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the deprnreserve property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getDEPRNRESERVE() {
        return deprnreserve;
    }

    /**
     * Sets the value of the deprnreserve property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setDEPRNRESERVE(JAXBElement<BigDecimal> value) {
        this.deprnreserve = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the netbookvalue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getNETBOOKVALUE() {
        return netbookvalue;
    }

    /**
     * Sets the value of the netbookvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setNETBOOKVALUE(JAXBElement<BigDecimal> value) {
        this.netbookvalue = ((JAXBElement<BigDecimal> ) value);
    }

}
