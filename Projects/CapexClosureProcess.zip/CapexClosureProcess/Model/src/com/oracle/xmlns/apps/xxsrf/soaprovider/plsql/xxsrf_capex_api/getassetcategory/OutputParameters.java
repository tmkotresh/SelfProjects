
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetcategory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETASSETCATEGORY" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/}APPS.SRF_ASSET_CAT_TAB" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getassetcategory"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GETASSETCATEGORY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFASSETCATTAB> getassetcategory;

    /**
     * Gets the value of the getassetcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFASSETCATTAB }{@code >}
     *     
     */
    public JAXBElement<APPSSRFASSETCATTAB> getGETASSETCATEGORY() {
        return getassetcategory;
    }

    /**
     * Sets the value of the getassetcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFASSETCATTAB }{@code >}
     *     
     */
    public void setGETASSETCATEGORY(JAXBElement<APPSSRFASSETCATTAB> value) {
        this.getassetcategory = ((JAXBElement<APPSSRFASSETCATTAB> ) value);
    }

}
