
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getproduct;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APPS.SRF_FLEX_TABLE complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_FLEX_TABLE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETPRODUCT_ITEM" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getproduct/}APPS.SRF_FLEX_OBJ" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_FLEX_TABLE", propOrder = {
    "getproductitem"
})
public class APPSSRFFLEXTABLE {

    @XmlElement(name = "GETPRODUCT_ITEM", nillable = true)
    protected List<APPSSRFFLEXOBJ> getproductitem;

    /**
     * Gets the value of the getproductitem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the getproductitem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGETPRODUCTITEM().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link APPSSRFFLEXOBJ }
     * 
     * 
     */
    public List<APPSSRFFLEXOBJ> getGETPRODUCTITEM() {
        if (getproductitem == null) {
            getproductitem = new ArrayList<APPSSRFFLEXOBJ>();
        }
        return this.getproductitem;
    }

}
