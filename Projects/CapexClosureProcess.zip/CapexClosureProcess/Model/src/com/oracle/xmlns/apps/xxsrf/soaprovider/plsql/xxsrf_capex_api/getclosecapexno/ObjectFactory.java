
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getclosecapexno;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getclosecapexno package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OutputParametersGETCLOSECAPEXNO_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", "GETCLOSECAPEXNO");
    private final static QName _InputParametersCCORDINATOR_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", "C_CORDINATOR");
    private final static QName _InputParametersCBUSINESS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", "C_BUSINESS");
    private final static QName _InputParametersCUNIT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", "C_UNIT");
    private final static QName _APPSSRFCAPEXNOOBJCAPEXNO_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", "CAPEXNO");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getclosecapexno
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFCAPEXNOTABLE }
     * 
     */
    public APPSSRFCAPEXNOTABLE createAPPSSRFCAPEXNOTABLE() {
        return new APPSSRFCAPEXNOTABLE();
    }

    /**
     * Create an instance of {@link APPSSRFCAPEXNOOBJ }
     * 
     */
    public APPSSRFCAPEXNOOBJ createAPPSSRFCAPEXNOOBJ() {
        return new APPSSRFCAPEXNOOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFCAPEXNOTABLE }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", name = "GETCLOSECAPEXNO", scope = OutputParameters.class)
    public JAXBElement<APPSSRFCAPEXNOTABLE> createOutputParametersGETCLOSECAPEXNO(APPSSRFCAPEXNOTABLE value) {
        return new JAXBElement<APPSSRFCAPEXNOTABLE>(_OutputParametersGETCLOSECAPEXNO_QNAME, APPSSRFCAPEXNOTABLE.class, OutputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", name = "C_CORDINATOR", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCORDINATOR(String value) {
        return new JAXBElement<String>(_InputParametersCCORDINATOR_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", name = "C_BUSINESS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUSINESS(String value) {
        return new JAXBElement<String>(_InputParametersCBUSINESS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", name = "C_UNIT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCUNIT(String value) {
        return new JAXBElement<String>(_InputParametersCUNIT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getclosecapexno/", name = "CAPEXNO", scope = APPSSRFCAPEXNOOBJ.class)
    public JAXBElement<String> createAPPSSRFCAPEXNOOBJCAPEXNO(String value) {
        return new JAXBElement<String>(_APPSSRFCAPEXNOOBJCAPEXNO_QNAME, String.class, APPSSRFCAPEXNOOBJ.class, value);
    }

}
