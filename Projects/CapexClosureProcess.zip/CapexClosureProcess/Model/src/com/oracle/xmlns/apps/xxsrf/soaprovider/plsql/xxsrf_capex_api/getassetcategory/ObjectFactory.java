
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetcategory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetcategory package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OutputParametersGETASSETCATEGORY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/", "GETASSETCATEGORY");
    private final static QName _APPSSRFASSETCATOBJCOMBINATION1_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/", "COMBINATION1");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetcategory
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFASSETCATTAB }
     * 
     */
    public APPSSRFASSETCATTAB createAPPSSRFASSETCATTAB() {
        return new APPSSRFASSETCATTAB();
    }

    /**
     * Create an instance of {@link APPSSRFASSETCATOBJ }
     * 
     */
    public APPSSRFASSETCATOBJ createAPPSSRFASSETCATOBJ() {
        return new APPSSRFASSETCATOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFASSETCATTAB }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/", name = "GETASSETCATEGORY", scope = OutputParameters.class)
    public JAXBElement<APPSSRFASSETCATTAB> createOutputParametersGETASSETCATEGORY(APPSSRFASSETCATTAB value) {
        return new JAXBElement<APPSSRFASSETCATTAB>(_OutputParametersGETASSETCATEGORY_QNAME, APPSSRFASSETCATTAB.class, OutputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/", name = "COMBINATION1", scope = APPSSRFASSETCATOBJ.class)
    public JAXBElement<String> createAPPSSRFASSETCATOBJCOMBINATION1(String value) {
        return new JAXBElement<String>(_APPSSRFASSETCATOBJCOMBINATION1_QNAME, String.class, APPSSRFASSETCATOBJ.class, value);
    }

}
