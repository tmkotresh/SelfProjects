@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexno/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexno;
