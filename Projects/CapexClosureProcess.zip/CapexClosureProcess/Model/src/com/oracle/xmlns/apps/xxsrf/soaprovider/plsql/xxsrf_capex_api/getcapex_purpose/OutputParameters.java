
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapex_purpose;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETCAPEX_PURPOSE" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/}APPS.SRF_FLEX_TABLE" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getcapexpurpose"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GETCAPEX_PURPOSE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFFLEXTABLE> getcapexpurpose;

    /**
     * Gets the value of the getcapexpurpose property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFFLEXTABLE }{@code >}
     *     
     */
    public JAXBElement<APPSSRFFLEXTABLE> getGETCAPEXPURPOSE() {
        return getcapexpurpose;
    }

    /**
     * Sets the value of the getcapexpurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFFLEXTABLE }{@code >}
     *     
     */
    public void setGETCAPEXPURPOSE(JAXBElement<APPSSRFFLEXTABLE> value) {
        this.getcapexpurpose = ((JAXBElement<APPSSRFFLEXTABLE> ) value);
    }

}
