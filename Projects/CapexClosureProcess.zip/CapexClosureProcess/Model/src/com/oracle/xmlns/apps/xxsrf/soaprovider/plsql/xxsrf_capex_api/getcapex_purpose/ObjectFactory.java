
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapex_purpose;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapex_purpose package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _APPSSRFFLEXOBJDESCRIPTION_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", "DESCRIPTION");
    private final static QName _APPSSRFFLEXOBJFLEXID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", "FLEX_ID");
    private final static QName _APPSSRFFLEXOBJFLEXVALUE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", "FLEX_VALUE");
    private final static QName _OutputParametersGETCAPEXPURPOSE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", "GETCAPEX_PURPOSE");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapex_purpose
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFFLEXTABLE }
     * 
     */
    public APPSSRFFLEXTABLE createAPPSSRFFLEXTABLE() {
        return new APPSSRFFLEXTABLE();
    }

    /**
     * Create an instance of {@link APPSSRFFLEXOBJ }
     * 
     */
    public APPSSRFFLEXOBJ createAPPSSRFFLEXOBJ() {
        return new APPSSRFFLEXOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", name = "DESCRIPTION", scope = APPSSRFFLEXOBJ.class)
    public JAXBElement<String> createAPPSSRFFLEXOBJDESCRIPTION(String value) {
        return new JAXBElement<String>(_APPSSRFFLEXOBJDESCRIPTION_QNAME, String.class, APPSSRFFLEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", name = "FLEX_ID", scope = APPSSRFFLEXOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFFLEXOBJFLEXID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFFLEXOBJFLEXID_QNAME, BigDecimal.class, APPSSRFFLEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", name = "FLEX_VALUE", scope = APPSSRFFLEXOBJ.class)
    public JAXBElement<String> createAPPSSRFFLEXOBJFLEXVALUE(String value) {
        return new JAXBElement<String>(_APPSSRFFLEXOBJFLEXVALUE_QNAME, String.class, APPSSRFFLEXOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFFLEXTABLE }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_purpose/", name = "GETCAPEX_PURPOSE", scope = OutputParameters.class)
    public JAXBElement<APPSSRFFLEXTABLE> createOutputParametersGETCAPEXPURPOSE(APPSSRFFLEXTABLE value) {
        return new JAXBElement<APPSSRFFLEXTABLE>(_OutputParametersGETCAPEXPURPOSE_QNAME, APPSSRFFLEXTABLE.class, OutputParameters.class, value);
    }

}
