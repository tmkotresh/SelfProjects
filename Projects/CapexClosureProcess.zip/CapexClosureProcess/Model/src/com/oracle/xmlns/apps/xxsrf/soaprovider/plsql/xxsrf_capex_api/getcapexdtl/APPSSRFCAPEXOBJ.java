
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapexdtl;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for APPS.SRF_CAPEX_OBJ complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_CAPEX_OBJ">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CAPEX_TYPE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_NUMBER" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="CAPEX_TITLE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_SUB_TITLE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="200"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="COST_CENTER" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CO_ORDINATOR" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="80"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BUDGETED_FLAG" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="NOTBUDGETED_FLAG" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BUDGET_REF" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="REPLACEMENT_FLAG" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SCHEDULE_DATE_OF_COMPLETION" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="STATUS" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="15"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EMPLOYEE_NUMBER" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_STATUS" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="30"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_CLOSURE_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="ORG_ID" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ORIGINAL_CAPEX_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ORIGINAL_SCHEDULE_DATE_OF_COMP" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="BUSINESS" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="240"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="UNIT" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="240"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PRODUCT" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="240"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_SEQ_NO" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_CATEGORY" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="PAYMENT_SCHEDULE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1000"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CAPEX_ID" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BUDGET_REF_AMOUNT" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PURPOSE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="150"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ROI_REALISTIC" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ROI_OPTIMISTIC" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ROI_PESSIMISTIC" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DEPARTMENT" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="100"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ASSET_CATEGORY" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_CAPEX_OBJ", propOrder = {
    "capextype",
    "capexnumber",
    "capexdate",
    "capextitle",
    "capexsubtitle",
    "capexcost",
    "costcenter",
    "coordinator",
    "budgetedflag",
    "notbudgetedflag",
    "budgetref",
    "replacementflag",
    "scheduledateofcompletion",
    "status",
    "employeenumber",
    "capexstatus",
    "capexclosuredate",
    "orgid",
    "originalcapexcost",
    "originalscheduledateofcomp",
    "business",
    "unit",
    "product",
    "capexseqno",
    "capexcategory",
    "paymentschedule",
    "capexid",
    "budgetrefamount",
    "purpose",
    "roirealistic",
    "roioptimistic",
    "roipessimistic",
    "department",
    "assetcategory"
})
public class APPSSRFCAPEXOBJ {

    @XmlElementRef(name = "CAPEX_TYPE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capextype;
    @XmlElementRef(name = "CAPEX_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexnumber;
    @XmlElementRef(name = "CAPEX_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> capexdate;
    @XmlElementRef(name = "CAPEX_TITLE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capextitle;
    @XmlElementRef(name = "CAPEX_SUB_TITLE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexsubtitle;
    @XmlElementRef(name = "CAPEX_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> capexcost;
    @XmlElementRef(name = "COST_CENTER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> costcenter;
    @XmlElementRef(name = "CO_ORDINATOR", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> coordinator;
    @XmlElementRef(name = "BUDGETED_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> budgetedflag;
    @XmlElementRef(name = "NOTBUDGETED_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> notbudgetedflag;
    @XmlElementRef(name = "BUDGET_REF", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> budgetref;
    @XmlElementRef(name = "REPLACEMENT_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> replacementflag;
    @XmlElementRef(name = "SCHEDULE_DATE_OF_COMPLETION", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> scheduledateofcompletion;
    @XmlElementRef(name = "STATUS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> status;
    @XmlElementRef(name = "EMPLOYEE_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> employeenumber;
    @XmlElementRef(name = "CAPEX_STATUS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexstatus;
    @XmlElementRef(name = "CAPEX_CLOSURE_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> capexclosuredate;
    @XmlElementRef(name = "ORG_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> orgid;
    @XmlElementRef(name = "ORIGINAL_CAPEX_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> originalcapexcost;
    @XmlElementRef(name = "ORIGINAL_SCHEDULE_DATE_OF_COMP", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> originalscheduledateofcomp;
    @XmlElementRef(name = "BUSINESS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> business;
    @XmlElementRef(name = "UNIT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> unit;
    @XmlElementRef(name = "PRODUCT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> product;
    @XmlElementRef(name = "CAPEX_SEQ_NO", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexseqno;
    @XmlElementRef(name = "CAPEX_CATEGORY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexcategory;
    @XmlElementRef(name = "PAYMENT_SCHEDULE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> paymentschedule;
    @XmlElementRef(name = "CAPEX_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> capexid;
    @XmlElementRef(name = "BUDGET_REF_AMOUNT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> budgetrefamount;
    @XmlElementRef(name = "PURPOSE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> purpose;
    @XmlElementRef(name = "ROI_REALISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> roirealistic;
    @XmlElementRef(name = "ROI_OPTIMISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> roioptimistic;
    @XmlElementRef(name = "ROI_PESSIMISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> roipessimistic;
    @XmlElementRef(name = "DEPARTMENT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> department;
    @XmlElementRef(name = "ASSET_CATEGORY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapexdtl/", type = JAXBElement.class)
    protected JAXBElement<String> assetcategory;

    /**
     * Gets the value of the capextype property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXTYPE() {
        return capextype;
    }

    /**
     * Sets the value of the capextype property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXTYPE(JAXBElement<String> value) {
        this.capextype = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexnumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXNUMBER() {
        return capexnumber;
    }

    /**
     * Sets the value of the capexnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXNUMBER(JAXBElement<String> value) {
        this.capexnumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexdate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCAPEXDATE() {
        return capexdate;
    }

    /**
     * Sets the value of the capexdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCAPEXDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.capexdate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the capextitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXTITLE() {
        return capextitle;
    }

    /**
     * Sets the value of the capextitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXTITLE(JAXBElement<String> value) {
        this.capextitle = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexsubtitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXSUBTITLE() {
        return capexsubtitle;
    }

    /**
     * Sets the value of the capexsubtitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXSUBTITLE(JAXBElement<String> value) {
        this.capexsubtitle = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCAPEXCOST() {
        return capexcost;
    }

    /**
     * Sets the value of the capexcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCAPEXCOST(JAXBElement<BigDecimal> value) {
        this.capexcost = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the costcenter property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCOSTCENTER() {
        return costcenter;
    }

    /**
     * Sets the value of the costcenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCOSTCENTER(JAXBElement<String> value) {
        this.costcenter = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the coordinator property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCOORDINATOR() {
        return coordinator;
    }

    /**
     * Sets the value of the coordinator property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCOORDINATOR(JAXBElement<String> value) {
        this.coordinator = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the budgetedflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBUDGETEDFLAG() {
        return budgetedflag;
    }

    /**
     * Sets the value of the budgetedflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBUDGETEDFLAG(JAXBElement<String> value) {
        this.budgetedflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the notbudgetedflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNOTBUDGETEDFLAG() {
        return notbudgetedflag;
    }

    /**
     * Sets the value of the notbudgetedflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNOTBUDGETEDFLAG(JAXBElement<String> value) {
        this.notbudgetedflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the budgetref property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBUDGETREF() {
        return budgetref;
    }

    /**
     * Sets the value of the budgetref property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBUDGETREF(JAXBElement<String> value) {
        this.budgetref = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the replacementflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getREPLACEMENTFLAG() {
        return replacementflag;
    }

    /**
     * Sets the value of the replacementflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setREPLACEMENTFLAG(JAXBElement<String> value) {
        this.replacementflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the scheduledateofcompletion property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getSCHEDULEDATEOFCOMPLETION() {
        return scheduledateofcompletion;
    }

    /**
     * Sets the value of the scheduledateofcompletion property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setSCHEDULEDATEOFCOMPLETION(JAXBElement<XMLGregorianCalendar> value) {
        this.scheduledateofcompletion = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSTATUS() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSTATUS(JAXBElement<String> value) {
        this.status = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the employeenumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEMPLOYEENUMBER() {
        return employeenumber;
    }

    /**
     * Sets the value of the employeenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEMPLOYEENUMBER(JAXBElement<String> value) {
        this.employeenumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexstatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXSTATUS() {
        return capexstatus;
    }

    /**
     * Sets the value of the capexstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXSTATUS(JAXBElement<String> value) {
        this.capexstatus = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexclosuredate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCAPEXCLOSUREDATE() {
        return capexclosuredate;
    }

    /**
     * Sets the value of the capexclosuredate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCAPEXCLOSUREDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.capexclosuredate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the orgid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getORGID() {
        return orgid;
    }

    /**
     * Sets the value of the orgid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setORGID(JAXBElement<BigDecimal> value) {
        this.orgid = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the originalcapexcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getORIGINALCAPEXCOST() {
        return originalcapexcost;
    }

    /**
     * Sets the value of the originalcapexcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setORIGINALCAPEXCOST(JAXBElement<BigDecimal> value) {
        this.originalcapexcost = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the originalscheduledateofcomp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getORIGINALSCHEDULEDATEOFCOMP() {
        return originalscheduledateofcomp;
    }

    /**
     * Sets the value of the originalscheduledateofcomp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setORIGINALSCHEDULEDATEOFCOMP(JAXBElement<XMLGregorianCalendar> value) {
        this.originalscheduledateofcomp = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the business property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBUSINESS() {
        return business;
    }

    /**
     * Sets the value of the business property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBUSINESS(JAXBElement<String> value) {
        this.business = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the unit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUNIT() {
        return unit;
    }

    /**
     * Sets the value of the unit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUNIT(JAXBElement<String> value) {
        this.unit = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the product property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPRODUCT() {
        return product;
    }

    /**
     * Sets the value of the product property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPRODUCT(JAXBElement<String> value) {
        this.product = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexseqno property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXSEQNO() {
        return capexseqno;
    }

    /**
     * Sets the value of the capexseqno property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXSEQNO(JAXBElement<String> value) {
        this.capexseqno = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXCATEGORY() {
        return capexcategory;
    }

    /**
     * Sets the value of the capexcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXCATEGORY(JAXBElement<String> value) {
        this.capexcategory = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the paymentschedule property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPAYMENTSCHEDULE() {
        return paymentschedule;
    }

    /**
     * Sets the value of the paymentschedule property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPAYMENTSCHEDULE(JAXBElement<String> value) {
        this.paymentschedule = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the capexid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCAPEXID() {
        return capexid;
    }

    /**
     * Sets the value of the capexid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCAPEXID(JAXBElement<String> value) {
        this.capexid = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the budgetrefamount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getBUDGETREFAMOUNT() {
        return budgetrefamount;
    }

    /**
     * Sets the value of the budgetrefamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setBUDGETREFAMOUNT(JAXBElement<BigDecimal> value) {
        this.budgetrefamount = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the purpose property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPURPOSE() {
        return purpose;
    }

    /**
     * Sets the value of the purpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPURPOSE(JAXBElement<String> value) {
        this.purpose = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the roirealistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getROIREALISTIC() {
        return roirealistic;
    }

    /**
     * Sets the value of the roirealistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setROIREALISTIC(JAXBElement<String> value) {
        this.roirealistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the roioptimistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getROIOPTIMISTIC() {
        return roioptimistic;
    }

    /**
     * Sets the value of the roioptimistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setROIOPTIMISTIC(JAXBElement<String> value) {
        this.roioptimistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the roipessimistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getROIPESSIMISTIC() {
        return roipessimistic;
    }

    /**
     * Sets the value of the roipessimistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setROIPESSIMISTIC(JAXBElement<String> value) {
        this.roipessimistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the department property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDEPARTMENT() {
        return department;
    }

    /**
     * Sets the value of the department property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDEPARTMENT(JAXBElement<String> value) {
        this.department = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the assetcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getASSETCATEGORY() {
        return assetcategory;
    }

    /**
     * Sets the value of the assetcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setASSETCATEGORY(JAXBElement<String> value) {
        this.assetcategory = ((JAXBElement<String> ) value);
    }

}
