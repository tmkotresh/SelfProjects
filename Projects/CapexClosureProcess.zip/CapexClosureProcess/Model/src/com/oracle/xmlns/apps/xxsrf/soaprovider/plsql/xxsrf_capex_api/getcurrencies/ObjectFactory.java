
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcurrencies;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcurrencies package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _APPSSRFOUOBJORGID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", "ORG_ID");
    private final static QName _APPSSRFOUOBJOUNAME_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", "OU_NAME");
    private final static QName _OutputParametersGETCURRENCIES_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", "GETCURRENCIES");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcurrencies
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFOUTABLE }
     * 
     */
    public APPSSRFOUTABLE createAPPSSRFOUTABLE() {
        return new APPSSRFOUTABLE();
    }

    /**
     * Create an instance of {@link APPSSRFOUOBJ }
     * 
     */
    public APPSSRFOUOBJ createAPPSSRFOUOBJ() {
        return new APPSSRFOUOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", name = "ORG_ID", scope = APPSSRFOUOBJ.class)
    public JAXBElement<String> createAPPSSRFOUOBJORGID(String value) {
        return new JAXBElement<String>(_APPSSRFOUOBJORGID_QNAME, String.class, APPSSRFOUOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", name = "OU_NAME", scope = APPSSRFOUOBJ.class)
    public JAXBElement<String> createAPPSSRFOUOBJOUNAME(String value) {
        return new JAXBElement<String>(_APPSSRFOUOBJOUNAME_QNAME, String.class, APPSSRFOUOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFOUTABLE }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcurrencies/", name = "GETCURRENCIES", scope = OutputParameters.class)
    public JAXBElement<APPSSRFOUTABLE> createOutputParametersGETCURRENCIES(APPSSRFOUTABLE value) {
        return new JAXBElement<APPSSRFOUTABLE>(_OutputParametersGETCURRENCIES_QNAME, APPSSRFOUTABLE.class, OutputParameters.class, value);
    }

}
