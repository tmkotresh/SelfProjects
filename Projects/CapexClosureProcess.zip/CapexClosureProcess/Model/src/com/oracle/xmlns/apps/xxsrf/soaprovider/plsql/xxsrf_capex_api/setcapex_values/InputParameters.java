
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.setcapex_values;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="C_CAPEX_TITLE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_SUB_TITLE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_BUSINESS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_UNIT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_PRODUCT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_COST_CENTER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_DIVERSIFICATION_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_IT_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_QUALITY_IMPROVEMENT_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_OTHERS_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ADDITIONAL_CAPACITY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_COST_REDUCTION_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_SAFETY_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_RANDD_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_CATEGORY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_BUDGETED_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_NOTBUDGETED_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_BUDGET_REF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_BUDGET_REF_AMOUNT" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="C_PURPOSE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_SCHEDULE_DATE_OF_COMPLETION" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_REPLACEMENT_FLAG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_PAYMENT_SCHEDULE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CO_ORDINATOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ORG_ID" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="C_EMPLOYEE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_STATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_SEQ_NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_CLOSURE_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_ORIGINAL_CAPEX_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="C_ORIGINAL_SCH_DATE_COMP" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_COMMENTES" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_REMARKS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ROI_REALISTIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ROI_OPTIMISTIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ROI_PESSIMISTIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_DEPARTMENT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_ASSET_CATEGORY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "ccapextitle",
    "ccapexsubtitle",
    "cbusiness",
    "cunit",
    "cproduct",
    "ccostcenter",
    "cdiversificationflag",
    "citflag",
    "cqualityimprovementflag",
    "cothersflag",
    "cadditionalcapacity",
    "ccostreductionflag",
    "csafetyflag",
    "cranddflag",
    "ccapexcategory",
    "cbudgetedflag",
    "cnotbudgetedflag",
    "cbudgetref",
    "cbudgetrefamount",
    "cpurpose",
    "cscheduledateofcompletion",
    "creplacementflag",
    "cpaymentschedule",
    "ccoordinator",
    "corgid",
    "cemployeenumber",
    "cstatus",
    "ccapexseqno",
    "ccapexnumber",
    "ccapexid",
    "ccapexdate",
    "ccapexcost",
    "ccapextype",
    "ccapexclosuredate",
    "coriginalcapexcost",
    "coriginalschdatecomp",
    "ccommentes",
    "cremarks",
    "croirealistic",
    "croioptimistic",
    "croipessimistic",
    "cdepartment",
    "cassetcategory"
})
@XmlRootElement(name = "InputParameters")
public class InputParameters {

    @XmlElementRef(name = "C_CAPEX_TITLE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapextitle;
    @XmlElementRef(name = "C_CAPEX_SUB_TITLE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexsubtitle;
    @XmlElementRef(name = "C_BUSINESS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cbusiness;
    @XmlElementRef(name = "C_UNIT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cunit;
    @XmlElementRef(name = "C_PRODUCT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cproduct;
    @XmlElementRef(name = "C_COST_CENTER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccostcenter;
    @XmlElementRef(name = "C_DIVERSIFICATION_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cdiversificationflag;
    @XmlElementRef(name = "C_IT_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> citflag;
    @XmlElementRef(name = "C_QUALITY_IMPROVEMENT_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cqualityimprovementflag;
    @XmlElementRef(name = "C_OTHERS_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cothersflag;
    @XmlElementRef(name = "C_ADDITIONAL_CAPACITY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cadditionalcapacity;
    @XmlElementRef(name = "C_COST_REDUCTION_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccostreductionflag;
    @XmlElementRef(name = "C_SAFETY_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> csafetyflag;
    @XmlElementRef(name = "C_RANDD_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cranddflag;
    @XmlElementRef(name = "C_CAPEX_CATEGORY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexcategory;
    @XmlElementRef(name = "C_BUDGETED_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cbudgetedflag;
    @XmlElementRef(name = "C_NOTBUDGETED_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cnotbudgetedflag;
    @XmlElementRef(name = "C_BUDGET_REF", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cbudgetref;
    @XmlElementRef(name = "C_BUDGET_REF_AMOUNT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> cbudgetrefamount;
    @XmlElementRef(name = "C_PURPOSE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cpurpose;
    @XmlElementRef(name = "C_SCHEDULE_DATE_OF_COMPLETION", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> cscheduledateofcompletion;
    @XmlElementRef(name = "C_REPLACEMENT_FLAG", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> creplacementflag;
    @XmlElementRef(name = "C_PAYMENT_SCHEDULE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cpaymentschedule;
    @XmlElementRef(name = "C_CO_ORDINATOR", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccoordinator;
    @XmlElementRef(name = "C_ORG_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> corgid;
    @XmlElementRef(name = "C_EMPLOYEE_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cemployeenumber;
    @XmlElementRef(name = "C_STATUS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cstatus;
    @XmlElementRef(name = "C_CAPEX_SEQ_NO", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexseqno;
    @XmlElementRef(name = "C_CAPEX_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexnumber;
    @XmlElementRef(name = "C_CAPEX_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexid;
    @XmlElementRef(name = "C_CAPEX_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> ccapexdate;
    @XmlElementRef(name = "C_CAPEX_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> ccapexcost;
    @XmlElementRef(name = "C_CAPEX_TYPE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccapextype;
    @XmlElementRef(name = "C_CAPEX_CLOSURE_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> ccapexclosuredate;
    @XmlElementRef(name = "C_ORIGINAL_CAPEX_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> coriginalcapexcost;
    @XmlElementRef(name = "C_ORIGINAL_SCH_DATE_COMP", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> coriginalschdatecomp;
    @XmlElementRef(name = "C_COMMENTES", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> ccommentes;
    @XmlElementRef(name = "C_REMARKS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cremarks;
    @XmlElementRef(name = "C_ROI_REALISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> croirealistic;
    @XmlElementRef(name = "C_ROI_OPTIMISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> croioptimistic;
    @XmlElementRef(name = "C_ROI_PESSIMISTIC", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> croipessimistic;
    @XmlElementRef(name = "C_DEPARTMENT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cdepartment;
    @XmlElementRef(name = "C_ASSET_CATEGORY", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", type = JAXBElement.class)
    protected JAXBElement<String> cassetcategory;

    /**
     * Gets the value of the ccapextitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXTITLE() {
        return ccapextitle;
    }

    /**
     * Sets the value of the ccapextitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXTITLE(JAXBElement<String> value) {
        this.ccapextitle = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexsubtitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXSUBTITLE() {
        return ccapexsubtitle;
    }

    /**
     * Sets the value of the ccapexsubtitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXSUBTITLE(JAXBElement<String> value) {
        this.ccapexsubtitle = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cbusiness property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCBUSINESS() {
        return cbusiness;
    }

    /**
     * Sets the value of the cbusiness property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCBUSINESS(JAXBElement<String> value) {
        this.cbusiness = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cunit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCUNIT() {
        return cunit;
    }

    /**
     * Sets the value of the cunit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCUNIT(JAXBElement<String> value) {
        this.cunit = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cproduct property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCPRODUCT() {
        return cproduct;
    }

    /**
     * Sets the value of the cproduct property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCPRODUCT(JAXBElement<String> value) {
        this.cproduct = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccostcenter property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCOSTCENTER() {
        return ccostcenter;
    }

    /**
     * Sets the value of the ccostcenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCOSTCENTER(JAXBElement<String> value) {
        this.ccostcenter = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cdiversificationflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCDIVERSIFICATIONFLAG() {
        return cdiversificationflag;
    }

    /**
     * Sets the value of the cdiversificationflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCDIVERSIFICATIONFLAG(JAXBElement<String> value) {
        this.cdiversificationflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the citflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCITFLAG() {
        return citflag;
    }

    /**
     * Sets the value of the citflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCITFLAG(JAXBElement<String> value) {
        this.citflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cqualityimprovementflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCQUALITYIMPROVEMENTFLAG() {
        return cqualityimprovementflag;
    }

    /**
     * Sets the value of the cqualityimprovementflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCQUALITYIMPROVEMENTFLAG(JAXBElement<String> value) {
        this.cqualityimprovementflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cothersflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCOTHERSFLAG() {
        return cothersflag;
    }

    /**
     * Sets the value of the cothersflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCOTHERSFLAG(JAXBElement<String> value) {
        this.cothersflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cadditionalcapacity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCADDITIONALCAPACITY() {
        return cadditionalcapacity;
    }

    /**
     * Sets the value of the cadditionalcapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCADDITIONALCAPACITY(JAXBElement<String> value) {
        this.cadditionalcapacity = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccostreductionflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCOSTREDUCTIONFLAG() {
        return ccostreductionflag;
    }

    /**
     * Sets the value of the ccostreductionflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCOSTREDUCTIONFLAG(JAXBElement<String> value) {
        this.ccostreductionflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the csafetyflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCSAFETYFLAG() {
        return csafetyflag;
    }

    /**
     * Sets the value of the csafetyflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCSAFETYFLAG(JAXBElement<String> value) {
        this.csafetyflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cranddflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCRANDDFLAG() {
        return cranddflag;
    }

    /**
     * Sets the value of the cranddflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCRANDDFLAG(JAXBElement<String> value) {
        this.cranddflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXCATEGORY() {
        return ccapexcategory;
    }

    /**
     * Sets the value of the ccapexcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXCATEGORY(JAXBElement<String> value) {
        this.ccapexcategory = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cbudgetedflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCBUDGETEDFLAG() {
        return cbudgetedflag;
    }

    /**
     * Sets the value of the cbudgetedflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCBUDGETEDFLAG(JAXBElement<String> value) {
        this.cbudgetedflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cnotbudgetedflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCNOTBUDGETEDFLAG() {
        return cnotbudgetedflag;
    }

    /**
     * Sets the value of the cnotbudgetedflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCNOTBUDGETEDFLAG(JAXBElement<String> value) {
        this.cnotbudgetedflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cbudgetref property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCBUDGETREF() {
        return cbudgetref;
    }

    /**
     * Sets the value of the cbudgetref property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCBUDGETREF(JAXBElement<String> value) {
        this.cbudgetref = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cbudgetrefamount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCBUDGETREFAMOUNT() {
        return cbudgetrefamount;
    }

    /**
     * Sets the value of the cbudgetrefamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCBUDGETREFAMOUNT(JAXBElement<BigDecimal> value) {
        this.cbudgetrefamount = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the cpurpose property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCPURPOSE() {
        return cpurpose;
    }

    /**
     * Sets the value of the cpurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCPURPOSE(JAXBElement<String> value) {
        this.cpurpose = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cscheduledateofcompletion property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCSCHEDULEDATEOFCOMPLETION() {
        return cscheduledateofcompletion;
    }

    /**
     * Sets the value of the cscheduledateofcompletion property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCSCHEDULEDATEOFCOMPLETION(JAXBElement<XMLGregorianCalendar> value) {
        this.cscheduledateofcompletion = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the creplacementflag property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCREPLACEMENTFLAG() {
        return creplacementflag;
    }

    /**
     * Sets the value of the creplacementflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCREPLACEMENTFLAG(JAXBElement<String> value) {
        this.creplacementflag = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cpaymentschedule property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCPAYMENTSCHEDULE() {
        return cpaymentschedule;
    }

    /**
     * Sets the value of the cpaymentschedule property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCPAYMENTSCHEDULE(JAXBElement<String> value) {
        this.cpaymentschedule = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccoordinator property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCOORDINATOR() {
        return ccoordinator;
    }

    /**
     * Sets the value of the ccoordinator property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCOORDINATOR(JAXBElement<String> value) {
        this.ccoordinator = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the corgid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCORGID() {
        return corgid;
    }

    /**
     * Sets the value of the corgid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCORGID(JAXBElement<BigDecimal> value) {
        this.corgid = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the cemployeenumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCEMPLOYEENUMBER() {
        return cemployeenumber;
    }

    /**
     * Sets the value of the cemployeenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCEMPLOYEENUMBER(JAXBElement<String> value) {
        this.cemployeenumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cstatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCSTATUS() {
        return cstatus;
    }

    /**
     * Sets the value of the cstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCSTATUS(JAXBElement<String> value) {
        this.cstatus = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexseqno property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXSEQNO() {
        return ccapexseqno;
    }

    /**
     * Sets the value of the ccapexseqno property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXSEQNO(JAXBElement<String> value) {
        this.ccapexseqno = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexnumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXNUMBER() {
        return ccapexnumber;
    }

    /**
     * Sets the value of the ccapexnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXNUMBER(JAXBElement<String> value) {
        this.ccapexnumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXID() {
        return ccapexid;
    }

    /**
     * Sets the value of the ccapexid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXID(JAXBElement<String> value) {
        this.ccapexid = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexdate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCCAPEXDATE() {
        return ccapexdate;
    }

    /**
     * Sets the value of the ccapexdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCCAPEXDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.ccapexdate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the ccapexcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCCAPEXCOST() {
        return ccapexcost;
    }

    /**
     * Sets the value of the ccapexcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCCAPEXCOST(JAXBElement<BigDecimal> value) {
        this.ccapexcost = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the ccapextype property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXTYPE() {
        return ccapextype;
    }

    /**
     * Sets the value of the ccapextype property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXTYPE(JAXBElement<String> value) {
        this.ccapextype = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexclosuredate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCCAPEXCLOSUREDATE() {
        return ccapexclosuredate;
    }

    /**
     * Sets the value of the ccapexclosuredate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCCAPEXCLOSUREDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.ccapexclosuredate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the coriginalcapexcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCORIGINALCAPEXCOST() {
        return coriginalcapexcost;
    }

    /**
     * Sets the value of the coriginalcapexcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCORIGINALCAPEXCOST(JAXBElement<BigDecimal> value) {
        this.coriginalcapexcost = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the coriginalschdatecomp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCORIGINALSCHDATECOMP() {
        return coriginalschdatecomp;
    }

    /**
     * Sets the value of the coriginalschdatecomp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCORIGINALSCHDATECOMP(JAXBElement<XMLGregorianCalendar> value) {
        this.coriginalschdatecomp = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the ccommentes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCOMMENTES() {
        return ccommentes;
    }

    /**
     * Sets the value of the ccommentes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCOMMENTES(JAXBElement<String> value) {
        this.ccommentes = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cremarks property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCREMARKS() {
        return cremarks;
    }

    /**
     * Sets the value of the cremarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCREMARKS(JAXBElement<String> value) {
        this.cremarks = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the croirealistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCROIREALISTIC() {
        return croirealistic;
    }

    /**
     * Sets the value of the croirealistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCROIREALISTIC(JAXBElement<String> value) {
        this.croirealistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the croioptimistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCROIOPTIMISTIC() {
        return croioptimistic;
    }

    /**
     * Sets the value of the croioptimistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCROIOPTIMISTIC(JAXBElement<String> value) {
        this.croioptimistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the croipessimistic property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCROIPESSIMISTIC() {
        return croipessimistic;
    }

    /**
     * Sets the value of the croipessimistic property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCROIPESSIMISTIC(JAXBElement<String> value) {
        this.croipessimistic = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cdepartment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCDEPARTMENT() {
        return cdepartment;
    }

    /**
     * Sets the value of the cdepartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCDEPARTMENT(JAXBElement<String> value) {
        this.cdepartment = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cassetcategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCASSETCATEGORY() {
        return cassetcategory;
    }

    /**
     * Sets the value of the cassetcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCASSETCATEGORY(JAXBElement<String> value) {
        this.cassetcategory = ((JAXBElement<String> ) value);
    }

}
