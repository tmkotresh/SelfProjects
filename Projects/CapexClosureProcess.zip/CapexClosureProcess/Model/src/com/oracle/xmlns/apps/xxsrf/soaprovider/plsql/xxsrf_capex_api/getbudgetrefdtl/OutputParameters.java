
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getbudgetrefdtl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETBUDGETREFDTL" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/}APPS.SRF_BUDGETREF_TAB" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getbudgetrefdtl"
})
@XmlRootElement(name = "OutputParameters")
public class OutputParameters {

    @XmlElementRef(name = "GETBUDGETREFDTL", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", type = JAXBElement.class)
    protected JAXBElement<APPSSRFBUDGETREFTAB> getbudgetrefdtl;

    /**
     * Gets the value of the getbudgetrefdtl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFBUDGETREFTAB }{@code >}
     *     
     */
    public JAXBElement<APPSSRFBUDGETREFTAB> getGETBUDGETREFDTL() {
        return getbudgetrefdtl;
    }

    /**
     * Sets the value of the getbudgetrefdtl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link APPSSRFBUDGETREFTAB }{@code >}
     *     
     */
    public void setGETBUDGETREFDTL(JAXBElement<APPSSRFBUDGETREFTAB> value) {
        this.getbudgetrefdtl = ((JAXBElement<APPSSRFBUDGETREFTAB> ) value);
    }

}
