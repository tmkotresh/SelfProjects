
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getassetcategory;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APPS.SRF_ASSET_CAT_TAB complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_ASSET_CAT_TAB">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GETASSETCATEGORY_ITEM" type="{http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getassetcategory/}APPS.SRF_ASSET_CAT_OBJ" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_ASSET_CAT_TAB", propOrder = {
    "getassetcategoryitem"
})
public class APPSSRFASSETCATTAB {

    @XmlElement(name = "GETASSETCATEGORY_ITEM", nillable = true)
    protected List<APPSSRFASSETCATOBJ> getassetcategoryitem;

    /**
     * Gets the value of the getassetcategoryitem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the getassetcategoryitem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGETASSETCATEGORYITEM().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link APPSSRFASSETCATOBJ }
     * 
     * 
     */
    public List<APPSSRFASSETCATOBJ> getGETASSETCATEGORYITEM() {
        if (getassetcategoryitem == null) {
            getassetcategoryitem = new ArrayList<APPSSRFASSETCATOBJ>();
        }
        return this.getassetcategoryitem;
    }

}
