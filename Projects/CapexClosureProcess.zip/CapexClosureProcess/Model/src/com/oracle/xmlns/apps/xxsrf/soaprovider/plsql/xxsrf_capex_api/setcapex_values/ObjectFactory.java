
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.setcapex_values;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.setcapex_values package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InputParametersCROIPESSIMISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ROI_PESSIMISTIC");
    private final static QName _InputParametersCPURPOSE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_PURPOSE");
    private final static QName _InputParametersCPRODUCT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_PRODUCT");
    private final static QName _InputParametersCREPLACEMENTFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_REPLACEMENT_FLAG");
    private final static QName _InputParametersCROIOPTIMISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ROI_OPTIMISTIC");
    private final static QName _InputParametersCITFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_IT_FLAG");
    private final static QName _InputParametersCREMARKS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_REMARKS");
    private final static QName _InputParametersCBUDGETREF_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_BUDGET_REF");
    private final static QName _InputParametersCCAPEXCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_COST");
    private final static QName _InputParametersCCOMMENTES_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_COMMENTES");
    private final static QName _InputParametersCNOTBUDGETEDFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_NOTBUDGETED_FLAG");
    private final static QName _InputParametersCSAFETYFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_SAFETY_FLAG");
    private final static QName _InputParametersCQUALITYIMPROVEMENTFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_QUALITY_IMPROVEMENT_FLAG");
    private final static QName _InputParametersCORGID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ORG_ID");
    private final static QName _InputParametersCROIREALISTIC_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ROI_REALISTIC");
    private final static QName _InputParametersCBUDGETEDFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_BUDGETED_FLAG");
    private final static QName _InputParametersCCAPEXID_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_ID");
    private final static QName _InputParametersCBUDGETREFAMOUNT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_BUDGET_REF_AMOUNT");
    private final static QName _InputParametersCCAPEXCLOSUREDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_CLOSURE_DATE");
    private final static QName _InputParametersCCAPEXTITLE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_TITLE");
    private final static QName _InputParametersCOTHERSFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_OTHERS_FLAG");
    private final static QName _InputParametersCBUSINESS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_BUSINESS");
    private final static QName _InputParametersCCOSTREDUCTIONFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_COST_REDUCTION_FLAG");
    private final static QName _InputParametersCDIVERSIFICATIONFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_DIVERSIFICATION_FLAG");
    private final static QName _InputParametersCCAPEXSEQNO_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_SEQ_NO");
    private final static QName _InputParametersCCAPEXDATE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_DATE");
    private final static QName _InputParametersCRANDDFLAG_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_RANDD_FLAG");
    private final static QName _InputParametersCCAPEXTYPE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_TYPE");
    private final static QName _InputParametersCCOORDINATOR_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CO_ORDINATOR");
    private final static QName _InputParametersCADDITIONALCAPACITY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ADDITIONAL_CAPACITY");
    private final static QName _InputParametersCCAPEXSUBTITLE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_SUB_TITLE");
    private final static QName _InputParametersCCAPEXCATEGORY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_CATEGORY");
    private final static QName _InputParametersCPAYMENTSCHEDULE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_PAYMENT_SCHEDULE");
    private final static QName _InputParametersCASSETCATEGORY_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ASSET_CATEGORY");
    private final static QName _InputParametersCEMPLOYEENUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_EMPLOYEE_NUMBER");
    private final static QName _InputParametersCUNIT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_UNIT");
    private final static QName _InputParametersCSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_STATUS");
    private final static QName _InputParametersCORIGINALSCHDATECOMP_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ORIGINAL_SCH_DATE_COMP");
    private final static QName _InputParametersCORIGINALCAPEXCOST_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_ORIGINAL_CAPEX_COST");
    private final static QName _InputParametersCCOSTCENTER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_COST_CENTER");
    private final static QName _InputParametersCSCHEDULEDATEOFCOMPLETION_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_SCHEDULE_DATE_OF_COMPLETION");
    private final static QName _InputParametersCCAPEXNUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_CAPEX_NUMBER");
    private final static QName _InputParametersCDEPARTMENT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "C_DEPARTMENT");
    private final static QName _OutputParametersREQUESTSTATUS_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", "REQUEST_STATUS");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.setcapex_values
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ROI_PESSIMISTIC", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCROIPESSIMISTIC(String value) {
        return new JAXBElement<String>(_InputParametersCROIPESSIMISTIC_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_PURPOSE", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCPURPOSE(String value) {
        return new JAXBElement<String>(_InputParametersCPURPOSE_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_PRODUCT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCPRODUCT(String value) {
        return new JAXBElement<String>(_InputParametersCPRODUCT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_REPLACEMENT_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCREPLACEMENTFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCREPLACEMENTFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ROI_OPTIMISTIC", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCROIOPTIMISTIC(String value) {
        return new JAXBElement<String>(_InputParametersCROIOPTIMISTIC_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_IT_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCITFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCITFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_REMARKS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCREMARKS(String value) {
        return new JAXBElement<String>(_InputParametersCREMARKS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_BUDGET_REF", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUDGETREF(String value) {
        return new JAXBElement<String>(_InputParametersCBUDGETREF_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_COST", scope = InputParameters.class)
    public JAXBElement<BigDecimal> createInputParametersCCAPEXCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InputParametersCCAPEXCOST_QNAME, BigDecimal.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_COMMENTES", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCOMMENTES(String value) {
        return new JAXBElement<String>(_InputParametersCCOMMENTES_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_NOTBUDGETED_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCNOTBUDGETEDFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCNOTBUDGETEDFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_SAFETY_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCSAFETYFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCSAFETYFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_QUALITY_IMPROVEMENT_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCQUALITYIMPROVEMENTFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCQUALITYIMPROVEMENTFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ORG_ID", scope = InputParameters.class)
    public JAXBElement<BigDecimal> createInputParametersCORGID(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InputParametersCORGID_QNAME, BigDecimal.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ROI_REALISTIC", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCROIREALISTIC(String value) {
        return new JAXBElement<String>(_InputParametersCROIREALISTIC_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_BUDGETED_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUDGETEDFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCBUDGETEDFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_ID", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXID(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXID_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_BUDGET_REF_AMOUNT", scope = InputParameters.class)
    public JAXBElement<BigDecimal> createInputParametersCBUDGETREFAMOUNT(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InputParametersCBUDGETREFAMOUNT_QNAME, BigDecimal.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_CLOSURE_DATE", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCCAPEXCLOSUREDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCCAPEXCLOSUREDATE_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_TITLE", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXTITLE(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXTITLE_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_OTHERS_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCOTHERSFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCOTHERSFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_BUSINESS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUSINESS(String value) {
        return new JAXBElement<String>(_InputParametersCBUSINESS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_COST_REDUCTION_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCOSTREDUCTIONFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCCOSTREDUCTIONFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_DIVERSIFICATION_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCDIVERSIFICATIONFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCDIVERSIFICATIONFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_SEQ_NO", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXSEQNO(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXSEQNO_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_DATE", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCCAPEXDATE(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCCAPEXDATE_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_RANDD_FLAG", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCRANDDFLAG(String value) {
        return new JAXBElement<String>(_InputParametersCRANDDFLAG_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_TYPE", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXTYPE(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXTYPE_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CO_ORDINATOR", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCOORDINATOR(String value) {
        return new JAXBElement<String>(_InputParametersCCOORDINATOR_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ADDITIONAL_CAPACITY", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCADDITIONALCAPACITY(String value) {
        return new JAXBElement<String>(_InputParametersCADDITIONALCAPACITY_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_SUB_TITLE", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXSUBTITLE(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXSUBTITLE_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_CATEGORY", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXCATEGORY(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXCATEGORY_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_PAYMENT_SCHEDULE", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCPAYMENTSCHEDULE(String value) {
        return new JAXBElement<String>(_InputParametersCPAYMENTSCHEDULE_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ASSET_CATEGORY", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCASSETCATEGORY(String value) {
        return new JAXBElement<String>(_InputParametersCASSETCATEGORY_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_EMPLOYEE_NUMBER", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCEMPLOYEENUMBER(String value) {
        return new JAXBElement<String>(_InputParametersCEMPLOYEENUMBER_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_UNIT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCUNIT(String value) {
        return new JAXBElement<String>(_InputParametersCUNIT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_STATUS", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCSTATUS(String value) {
        return new JAXBElement<String>(_InputParametersCSTATUS_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ORIGINAL_SCH_DATE_COMP", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCORIGINALSCHDATECOMP(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCORIGINALSCHDATECOMP_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_ORIGINAL_CAPEX_COST", scope = InputParameters.class)
    public JAXBElement<BigDecimal> createInputParametersCORIGINALCAPEXCOST(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_InputParametersCORIGINALCAPEXCOST_QNAME, BigDecimal.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_COST_CENTER", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCOSTCENTER(String value) {
        return new JAXBElement<String>(_InputParametersCCOSTCENTER_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_SCHEDULE_DATE_OF_COMPLETION", scope = InputParameters.class)
    public JAXBElement<XMLGregorianCalendar> createInputParametersCSCHEDULEDATEOFCOMPLETION(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InputParametersCSCHEDULEDATEOFCOMPLETION_QNAME, XMLGregorianCalendar.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_CAPEX_NUMBER", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCCAPEXNUMBER(String value) {
        return new JAXBElement<String>(_InputParametersCCAPEXNUMBER_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "C_DEPARTMENT", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCDEPARTMENT(String value) {
        return new JAXBElement<String>(_InputParametersCDEPARTMENT_QNAME, String.class, InputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/setcapex_values/", name = "REQUEST_STATUS", scope = OutputParameters.class)
    public JAXBElement<String> createOutputParametersREQUESTSTATUS(String value) {
        return new JAXBElement<String>(_OutputParametersREQUESTSTATUS_QNAME, String.class, OutputParameters.class, value);
    }

}
