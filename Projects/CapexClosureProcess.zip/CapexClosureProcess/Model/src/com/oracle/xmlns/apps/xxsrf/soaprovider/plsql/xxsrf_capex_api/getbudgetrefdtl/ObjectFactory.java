
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getbudgetrefdtl;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getbudgetrefdtl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _APPSSRFBUDGETREFOBJCAPEXTITLE_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "CAPEX_TITLE");
    private final static QName _APPSSRFBUDGETREFOBJBUDGETREF_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "BUDGET_REF");
    private final static QName _APPSSRFBUDGETREFOBJBUDGETREFAMOUNT_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "BUDGET_REF_AMOUNT");
    private final static QName _APPSSRFBUDGETREFOBJCAPEXNUMBER_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "CAPEX_NUMBER");
    private final static QName _OutputParametersGETBUDGETREFDTL_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "GETBUDGETREFDTL");
    private final static QName _InputParametersCBUDGETREF_QNAME = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", "C_BUDGETREF");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getbudgetrefdtl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InputParameters }
     * 
     */
    public InputParameters createInputParameters() {
        return new InputParameters();
    }

    /**
     * Create an instance of {@link OutputParameters }
     * 
     */
    public OutputParameters createOutputParameters() {
        return new OutputParameters();
    }

    /**
     * Create an instance of {@link APPSSRFBUDGETREFTAB }
     * 
     */
    public APPSSRFBUDGETREFTAB createAPPSSRFBUDGETREFTAB() {
        return new APPSSRFBUDGETREFTAB();
    }

    /**
     * Create an instance of {@link APPSSRFBUDGETREFOBJ }
     * 
     */
    public APPSSRFBUDGETREFOBJ createAPPSSRFBUDGETREFOBJ() {
        return new APPSSRFBUDGETREFOBJ();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "CAPEX_TITLE", scope = APPSSRFBUDGETREFOBJ.class)
    public JAXBElement<String> createAPPSSRFBUDGETREFOBJCAPEXTITLE(String value) {
        return new JAXBElement<String>(_APPSSRFBUDGETREFOBJCAPEXTITLE_QNAME, String.class, APPSSRFBUDGETREFOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "BUDGET_REF", scope = APPSSRFBUDGETREFOBJ.class)
    public JAXBElement<String> createAPPSSRFBUDGETREFOBJBUDGETREF(String value) {
        return new JAXBElement<String>(_APPSSRFBUDGETREFOBJBUDGETREF_QNAME, String.class, APPSSRFBUDGETREFOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "BUDGET_REF_AMOUNT", scope = APPSSRFBUDGETREFOBJ.class)
    public JAXBElement<BigDecimal> createAPPSSRFBUDGETREFOBJBUDGETREFAMOUNT(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_APPSSRFBUDGETREFOBJBUDGETREFAMOUNT_QNAME, BigDecimal.class, APPSSRFBUDGETREFOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "CAPEX_NUMBER", scope = APPSSRFBUDGETREFOBJ.class)
    public JAXBElement<String> createAPPSSRFBUDGETREFOBJCAPEXNUMBER(String value) {
        return new JAXBElement<String>(_APPSSRFBUDGETREFOBJCAPEXNUMBER_QNAME, String.class, APPSSRFBUDGETREFOBJ.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APPSSRFBUDGETREFTAB }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "GETBUDGETREFDTL", scope = OutputParameters.class)
    public JAXBElement<APPSSRFBUDGETREFTAB> createOutputParametersGETBUDGETREFDTL(APPSSRFBUDGETREFTAB value) {
        return new JAXBElement<APPSSRFBUDGETREFTAB>(_OutputParametersGETBUDGETREFDTL_QNAME, APPSSRFBUDGETREFTAB.class, OutputParameters.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getbudgetrefdtl/", name = "C_BUDGETREF", scope = InputParameters.class)
    public JAXBElement<String> createInputParametersCBUDGETREF(String value) {
        return new JAXBElement<String>(_InputParametersCBUDGETREF_QNAME, String.class, InputParameters.class, value);
    }

}
