
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.closecapex;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="C_CAPEX_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_BUSINESS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_UNIT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_PRODUCT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_STATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_REMARKS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="C_CAPEX_CLOSURE_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_CAPITALIZATION_DATE" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="C_CAPITALIZATION_COST" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "ccapexnumber",
    "cbusiness",
    "cunit",
    "cproduct",
    "cstatus",
    "cremarks",
    "ccapexclosuredate",
    "ccapitalizationdate",
    "ccapitalizationcost"
})
@XmlRootElement(name = "InputParameters")
public class InputParameters {

    @XmlElementRef(name = "C_CAPEX_NUMBER", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> ccapexnumber;
    @XmlElementRef(name = "C_BUSINESS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> cbusiness;
    @XmlElementRef(name = "C_UNIT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> cunit;
    @XmlElementRef(name = "C_PRODUCT", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> cproduct;
    @XmlElementRef(name = "C_STATUS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> cstatus;
    @XmlElementRef(name = "C_REMARKS", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<String> cremarks;
    @XmlElementRef(name = "C_CAPEX_CLOSURE_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> ccapexclosuredate;
    @XmlElementRef(name = "C_CAPITALIZATION_DATE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> ccapitalizationdate;
    @XmlElementRef(name = "C_CAPITALIZATION_COST", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/closecapex/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> ccapitalizationcost;

    /**
     * Gets the value of the ccapexnumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCCAPEXNUMBER() {
        return ccapexnumber;
    }

    /**
     * Sets the value of the ccapexnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCCAPEXNUMBER(JAXBElement<String> value) {
        this.ccapexnumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cbusiness property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCBUSINESS() {
        return cbusiness;
    }

    /**
     * Sets the value of the cbusiness property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCBUSINESS(JAXBElement<String> value) {
        this.cbusiness = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cunit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCUNIT() {
        return cunit;
    }

    /**
     * Sets the value of the cunit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCUNIT(JAXBElement<String> value) {
        this.cunit = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cproduct property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCPRODUCT() {
        return cproduct;
    }

    /**
     * Sets the value of the cproduct property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCPRODUCT(JAXBElement<String> value) {
        this.cproduct = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cstatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCSTATUS() {
        return cstatus;
    }

    /**
     * Sets the value of the cstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCSTATUS(JAXBElement<String> value) {
        this.cstatus = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cremarks property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCREMARKS() {
        return cremarks;
    }

    /**
     * Sets the value of the cremarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCREMARKS(JAXBElement<String> value) {
        this.cremarks = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the ccapexclosuredate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCCAPEXCLOSUREDATE() {
        return ccapexclosuredate;
    }

    /**
     * Sets the value of the ccapexclosuredate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCCAPEXCLOSUREDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.ccapexclosuredate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the ccapitalizationdate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCCAPITALIZATIONDATE() {
        return ccapitalizationdate;
    }

    /**
     * Sets the value of the ccapitalizationdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCCAPITALIZATIONDATE(JAXBElement<XMLGregorianCalendar> value) {
        this.ccapitalizationdate = ((JAXBElement<XMLGregorianCalendar> ) value);
    }

    /**
     * Gets the value of the ccapitalizationcost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCCAPITALIZATIONCOST() {
        return ccapitalizationcost;
    }

    /**
     * Sets the value of the ccapitalizationcost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCCAPITALIZATIONCOST(JAXBElement<BigDecimal> value) {
        this.ccapitalizationcost = ((JAXBElement<BigDecimal> ) value);
    }

}
