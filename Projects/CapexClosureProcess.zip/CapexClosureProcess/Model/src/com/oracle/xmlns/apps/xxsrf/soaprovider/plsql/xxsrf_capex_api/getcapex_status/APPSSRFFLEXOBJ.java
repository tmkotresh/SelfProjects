
package com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.getcapex_status;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APPS.SRF_FLEX_OBJ complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APPS.SRF_FLEX_OBJ">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FLEX_ID" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="FLEX_VALUE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DESCRIPTION" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="250"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APPS.SRF_FLEX_OBJ", propOrder = {
    "flexid",
    "flexvalue",
    "description"
})
public class APPSSRFFLEXOBJ {

    @XmlElementRef(name = "FLEX_ID", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_status/", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> flexid;
    @XmlElementRef(name = "FLEX_VALUE", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_status/", type = JAXBElement.class)
    protected JAXBElement<String> flexvalue;
    @XmlElementRef(name = "DESCRIPTION", namespace = "http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/getcapex_status/", type = JAXBElement.class)
    protected JAXBElement<String> description;

    /**
     * Gets the value of the flexid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getFLEXID() {
        return flexid;
    }

    /**
     * Sets the value of the flexid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setFLEXID(JAXBElement<BigDecimal> value) {
        this.flexid = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the flexvalue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFLEXVALUE() {
        return flexvalue;
    }

    /**
     * Sets the value of the flexvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFLEXVALUE(JAXBElement<String> value) {
        this.flexvalue = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDESCRIPTION() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDESCRIPTION(JAXBElement<String> value) {
        this.description = ((JAXBElement<String> ) value);
    }

}
