package com.srf.cp.model.utility;

import com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.XXSRF_CAPEX_API_PortType;
import com.oracle.xmlns.apps.xxsrf.soaprovider.plsql.xxsrf_capex_api.XXSRF_CAPEX_API_Service;
import oracle.wsm.security.util.SecurityConstants;

import com.sun.xml.ws.developer.WSBindingProvider;

import java.io.FileInputStream;
import java.io.InputStream;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.Map;

import java.util.Properties;

import javax.xml.ws.BindingProvider;

import weblogic.wsee.jws.jaxws.owsm.SecurityPoliciesFeature;

import oracle.adf.share.logging.ADFLogger;

import javax.xml.namespace.QName;

public class WebserviceHelper {
    public WebserviceHelper() {
        super();
    }
    private static final ADFLogger LOGGER =
        ADFLogger.createADFLogger(WebserviceHelper.class); 
    private static InputStream input=null;
    
    private static Properties prop = new Properties();
    //String url = null;
    
    
    
    
    
   
    
    
    
    private static XXSRF_CAPEX_API_Service xXSRF_CAPEX_API_Service;
    
    public XXSRF_CAPEX_API_PortType getWsPort(){
        //UAT & Dev URL
        
        String url = "http://R12DEVAPP.srf.com:80/webservices/SOAProvider/plsql/xxsrf_capex_api/?wsdl";
        
        //Production URL
        //String url = "http://r12prodappha.srf.com:8025/webservices/SOAProvider/plsql/xxsrf_capex_api/?wsdl";
                      
        
        
        URL urlObj= null;
        
//        try {
//                    input = new FileInputStream("/app/scripts/SRFConfig.properties");
//                    prop.load(input);
//                    url = prop.getProperty("CAPEX_CLOSURE_URL");
//                    LOGGER.info("WSDL URL "+url);
//                    //System.out.println("URL info "+url);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
        try {
            urlObj = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        QName qName = new QName("http://xmlns.oracle.com/apps/xxsrf/soaprovider/plsql/xxsrf_capex_api/",
                              "XXSRF_CAPEX_API_Service");
        xXSRF_CAPEX_API_Service = new XXSRF_CAPEX_API_Service(urlObj,qName);
            SecurityPoliciesFeature securityFeatures =
                new SecurityPoliciesFeature(new String[] { "oracle/wss_username_token_client_policy" });
            XXSRF_CAPEX_API_PortType xXSRF_CAPEX_API_PortType = xXSRF_CAPEX_API_Service.getXXSRF_CAPEX_API_Port(securityFeatures);
            // Add your code to call the desired methods.
            
            
            BindingProvider bindingProvider =
                (BindingProvider)xXSRF_CAPEX_API_PortType;
          Map<String, Object> context = bindingProvider.getRequestContext();
          //context.put(WSBindingProvider.USERNAME_PROPERTY, "BPM_PAYABLE");
          //context.put(WSBindingProvider.PASSWORD_PROPERTY, "oracle1234");
          context.put(SecurityConstants.ClientConstants.WSS_CSF_KEY, "user-key");
          return xXSRF_CAPEX_API_PortType;
    }
}
