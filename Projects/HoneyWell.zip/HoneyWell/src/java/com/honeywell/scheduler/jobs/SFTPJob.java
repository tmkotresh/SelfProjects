
package com.honeywell.scheduler.jobs;

import com.honeywell.scheduler.ReadFileFromServer;
import com.honeywell.toppic.customer.CustomerTxtToXML;
import com.honeywell.toppic.material.MaterialTxtToXML;
import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.honeywell.utils.Constants;
import com.honeywell.utils.DatabaseUtility;
import com.honeywell.utils.DeleteHistoryFiles;
import com.honeywell.utils.KillJob;

import com.honeywell.utils.UploadListGenerator;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.Logger;

/**
 * This class is responsible for executing tasks like reading files from Inbound SFTP server
 * and executing Toppic(Customer,Material and Pricing).
 * 
 * @author kmatada
 */
@DisallowConcurrentExecution
public class SFTPJob implements Job {

    static {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }
    private static final Logger _logger = Logger.getLogger(SFTPJob.class.getName());

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        _logger.info("**********BEGIN***********");
        
        ArrayList<String> salesOrgList = new ArrayList<>();
       // Calendar cal = Calendar.getInstance();
        Date date = new Date();

        String formatedDate = new SimpleDateFormat("YYYYMMdd").format(date);

        _logger.info("Start Toppic Data Transfer at     " + date.toString());
        
        _logger.info("Running for Date      " + formatedDate);

        //Setting permission for the log file
        File folder = new File(Constants.JCS_LOG_FILE_LOCATION);
        try {
            for (File f : folder.listFiles()) {
                f.setExecutable(true, false);
                f.setReadable(true, false);
                f.setWritable(true, false);
            }

        } catch (Exception e) {
              e.printStackTrace();
            _logger.info("Exception while setting permission for log file creation"+e);
            
        }

        //Connecting to Inbound SFTP server to read files and put it into JCS input folder
        try {
          //  new ReadFileFromServer().transfarFileSftpToJCS(Constants.IB_SFTP_SOURCE_FOLDER, Constants.JCS_INPUT_FOLDER, Constants.USER_NAME, Constants.HOST_NAME, Constants.PASSWORD, Constants.PORT);
            _logger.info("Transfer of files from Honeywell Inbound SFTP server is completed");
        } catch (Exception e) {
              e.printStackTrace();
            _logger.info("Error occured while transferring files from inbound sftp server to JCS"+e);
            
        }
        /*
        This code will get the list of sales org from the database by calling DBUtils
         */

        try {
            salesOrgList = new DatabaseUtility().getAllSalesOrgs();
            
        //    salesOrgList.add("2092");
        } catch (Exception e) {
             
            _logger.info("Exception while fetching sales org list from data base " + e);
        }

        for (String salesOrg : salesOrgList) {
            String countryName = new DatabaseUtility().getCountry(salesOrg);
            _logger.info("\n");
            _logger.info("*** Converting Data for SalesOrg " + salesOrg+" - "+countryName);
            //Processing Customer files
            try {

                new CustomerTxtToXML().generateXML(salesOrg);

            } catch (Exception e) {
                
                _logger.info("Exception while processing Customer files" + e);
                
                

            }

            //Processing Material files
            try {

                new MaterialTxtToXML().generateXML(salesOrg);

            } catch (Exception e) {
                 
                _logger.info("Exception while processing Material files" + e);

            }

            //Processing Pricing  files
            try {
                _logger.info("Processing  Pricing file for sales org "+salesOrg);
                new ReadLineandGenerateMapping().initializeProcessingPricingFiles(salesOrg);
               
               //    _logger.info("Pricing file Processing end");
            } catch (Exception e) {
                
                _logger.info("Exception while processing Pricing files" + e);

            }

        }
        
       // _logger.info(" Conversion complete at " +cal.getTime());

        try {

            //new FoldertoZipConverter().createZip();
            new UploadListGenerator().generateXml();
           // _logger.info("Uploaded file upload_list.xml per ftp to honeywell at resources.bigmachines.com");
        } catch (Exception e) {
            _logger.info("Exception during UploadListGenerator " + e);
        }
        
//        
//        try {
//            File OutPutFolder = new File(Constants.JCS_OUTPUT_FOLDER);
//            for (File file : OutPutFolder.listFiles()) {
//                if (!file.isDirectory()) {
//                    file.delete();
//                }
//            }
//            //FileUtils.forceDelete(f);
//        } catch (Exception e) {
//            _logger.info("Exception while deleting content of Output folder");
//        }
//        
        
       Date date2 = new Date();
       
       new DeleteHistoryFiles().deleteOuputXMLFiles();
       new DeleteHistoryFiles().deleteProcessedHistoryFiles();
       _logger.info("End Toppic Data Transfer at     " + date2.toString());
//         try{
//             new KillJob().killJob();
//         }catch(Exception e){
//            _logger.info("Exception while killing the Job"+e) ;
//         }
        _logger.info("**********END***********");

    }
      
         
      
    
}


