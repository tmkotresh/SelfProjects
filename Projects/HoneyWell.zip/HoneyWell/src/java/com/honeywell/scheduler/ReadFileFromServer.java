/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.scheduler;

/**
 *
 * @author kmatada
 */
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import com.jcraft.jsch.Channel;

import com.jcraft.jsch.ProxyHTTP;
import com.jcraft.jsch.SftpException;
import com.honeywell.utils.Constants;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;


import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Properties;
import java.util.Vector;
import org.apache.log4j.Logger;

/**
 *
 * @author kmatada
 */
public class ReadFileFromServer {
	private JSch jsch;
    private Session session;
    private static final Logger _logger = Logger.getLogger(ReadFileFromServer.class.getName());
    //private static  Logger logger = null;
    private static Properties prop = new Properties();
    private static InputStream input = null;
    
    static{
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }

    public static void main(String[] args) throws JSchException, SftpException {

        //logger=GetLogger.getLogger("com.honywell.readfile.ReadFileFromServer")	;	
        ReadFileFromServer rfs = new ReadFileFromServer();

        rfs.transfarFileSftpToJCS(Constants.IB_SFTP_SOURCE_FOLDER, Constants.JCS_INPUT_FOLDER, Constants.USER_NAME, Constants.HOST_NAME, Constants.PASSWORD, Constants.PORT);

        //
    }

    public void transfarFileSftpToJCS(String sourceFolder, String desFolder, String user, String hostName, String password, int port) {

        JSch jsch = new JSch();

        Session session = null;
        Channel channel = null;

        try {
            //input = new FileInputStream("D:\\Work\\HoneyWell\\hwwebmethodsconfig.properties");
            input = new FileInputStream(Constants.CONFIG_PROPERTY);
            prop.load(input);
        } catch (FileNotFoundException ex) {
            _logger.info("Properties file not found");
            
        } catch (IOException ex) {
            //Logger.getLogger(ReadFileFromServer.class.getName()).log(Level.SEVERE, null, ex);
        }
//        _logger.info("user name " + prop.getProperty("ibsftp_username"));
//        _logger.info("host name " + prop.getProperty("ibsftp_host"));
//        _logger.info("port " + prop.getProperty("ibsftp_port"));
//        _logger.info("private key location " + prop.getProperty("privateKey"));
        
        

        try {
            // System.getProperties().put("http.proxyHost", "www-proxy.uk.oracle.com");
            //System.getProperties().put("http.proxyPort", "80");
            //String privateKey = "/u01/data/backup/sshKey/honeywell_openssh.ppk";
            //jsch.addIdentity("D:\\Work\\HoneyWell\\SFTP_Server\\honeywell_openssh.ppk");
            
            
            
            //Setting private SSH key to connect to SFTP server
        	
        	
        	
        	
            jsch.addIdentity(prop.getProperty("privateKey"));

            session = jsch.getSession(prop.getProperty("ibsftp_username"), prop.getProperty("ibsftp_host"), Integer.parseInt(prop.getProperty("ibsftp_port")));
            //session = jsch.getSession("sap_bigmachines", "mftp.honeywell.com", 22);
           // _logger.info("Getting the session: " + session.toString());
            
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword("");
           // session.setProxy(new ProxyHTTP("www-proxy.uk.oracle.com",80));
            session.connect();
            channel = session.openChannel("sftp");
            //_logger.info("Successfully opened the SFTP channel");
            channel.connect();
           // _logger.info("Successfully connected");
            ChannelSftp sftpChannel = (ChannelSftp) channel;
           // _logger.info("Connected to SFTP channel successfully");
            
            /* Reading source folder files and place them in destination folder */

            sftpChannel.cd(sourceFolder);

           // _logger.info("Going to transfer  " + sourceFolder + " SFTP directory to  " + desFolder );
            Vector<ChannelSftp.LsEntry> list = sftpChannel.ls(sourceFolder);
            String pattern = "yyy-MM-dd HH:mm:ss";
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            Date date = new Date();
            String str = sdf.format(date);
            for (ChannelSftp.LsEntry oListItem : list) {

                if (!oListItem.getAttrs().isDir()) {
                   
                   
                    try {
                        if (!".".equals(oListItem.getFilename()) || "..".equals(oListItem.getFilename())) {
                            sftpChannel.get(oListItem.getFilename(), desFolder + oListItem.getFilename());
                            try{
                                File file = new File(desFolder + oListItem.getFilename());
                            file.setExecutable(true,false);
                            file.setReadable(true,false);
                            file.setWritable(true,false);
                            }catch(Exception e){
                                _logger.info("Exception while setting file permission");
                                e.printStackTrace();
                            }
                            
                        } else {
                            _logger.info("This is not a file " + oListItem.getFilename());
                        }
                    } catch (Exception ex) {
                        _logger.info("Unable to process  " + oListItem.getFilename());
                        _logger.info("Exception occured" + ex.getMessage());
                       
                    }

                } else {
                    //logger.warning("Don't create sub directory please");
                }
            }
           

           
            // Delete files once transfer is successfull
            try {

                Vector< ChannelSftp.LsEntry> entries = sftpChannel.ls(".");
                for (ChannelSftp.LsEntry entry : entries) {
                    if (entry.getFilename() != null) {
                        sftpChannel.rm(entry.getFilename());
                        
                        
                    }

                }

               // _logger.info("Successfully deleted all the files from location: " + sourceFolder);
            } catch (Exception e) {
                
                _logger.info("Error occured while deleting files from folder: " + sourceFolder+" and exception is "+e.getMessage());
               
            }

            /*  */
            //sftpChannel.get("BIG_MACHINE_MATERIAL_2092_11_20170525-150152-483.txt", "local.txt");
            //_logger.info("Able to get the file successfully from SAP inbound server..");
//            sftpChannel.exit();
//
//            session.disconnect();
        } catch (JSchException e) {

            e.printStackTrace();

        } catch (SftpException ex) {
            //Logger.getLogger(ReadFileFromServer.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (channel != null) {
                channel.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }

        }
    }


}

