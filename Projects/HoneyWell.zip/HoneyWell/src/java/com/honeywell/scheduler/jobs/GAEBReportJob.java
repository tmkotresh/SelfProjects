/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.scheduler.jobs;


import com.honeywell.gaeb.JAXBClient;
import java.text.SimpleDateFormat;

import java.util.Date;
import org.apache.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author devadred
 */
@DisallowConcurrentExecution
public class GAEBReportJob implements Job {

    static {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }
    private static final Logger _logger = Logger.getLogger(GAEBReportJob.class.getName());

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        System.out.println("inside gaeb job");
        
        try
        {
            _logger.info("Started Processing GAEB Report for date ");
            new JAXBClient().InitializeGAEBReport();
            _logger.info("Successfully completed processing HAEB Report");
        }
        catch(Exception e)
                {
                    _logger.info("Exception occured processing GAEB report"+e);
                }
    }

}
