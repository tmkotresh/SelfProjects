/**
 * TxtToXMLCommon holds the common code related to Material and Customer .txt to .xml file conversion.
 * 
 * @author kmatada
 */
package com.honeywell.toppic;


import com.honeywell.utils.Constants;
import java.io.File;
import java.io.FileInputStream;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;




public class TxtToXMLCommon {
    private static final Logger _logger = Logger.getLogger(TxtToXMLCommon.class.getName());
    
    Properties prop = new Properties();
    InputStream input = null;
    
    public TxtToXMLCommon(){
       
    }
    
    public static void main(String[] args) {
        new TxtToXMLCommon().salesOrgStatusAndType("2092");
    }
    public String[] salesOrgStatusAndType(String salesOrg) {

        try {
            
            input = new FileInputStream(Constants.ACTIVE_AND_INACTIVE_SALES_ORG_PROP);
            prop.load(input);
            String[] values = prop.getProperty(salesOrg).split("\t");
//            for(String s : values)
//            {
//                System.out.println("va;ues are "+s);
//            }
          
            System.out.println("is Active? "+values[4]);
            //System.out.println("is file needs to be processed for Material "+values[3]);
           if(values!=null){
               return values;
           }else{
               _logger.info("The Sales Org "+salesOrg+" is not available in config properties " );
           }
            
        } catch (FileNotFoundException ex) {
           _logger.info("Not able to find ActiveAndInactive properties config file"+ex.getMessage());
        } catch (IOException ex) {
           
            _logger.info("Exception  inside isActiveSalesOrg method ------"+ex.getMessage());
        }catch(Exception e){
            _logger.info("Exception while validating active or inactive sales org   "+e);
        }

        return null;
    }
    
    
    
//    public void moveProcessedFile(String fileName) {
//
//        try {
//            
//            String currentDate= this.getCurrentDate();
//            File f = new File(Constants.JCS_INPUT_FOLDER + fileName);
//            //directory where file will be copied
//            File f2 = new File(Constants.JCS_PROCESSED_FILES + currentDate + "/" + fileName);
//            
//            File folder = new File(Constants.JCS_PROCESSED_FILES + currentDate);
//            folder.setExecutable(true,false);
//            folder.setReadable(true, false);
//            folder.setWritable(true, false);
//            
//
//            FileUtils.copyFile(f, f2);
//            try{
//                f2.setExecutable(true, false);
//            f2.setReadable(true, false);
//            f2.setWritable(true, false);
//            }catch(Exception e){
//                _logger.info("Exception while setting file permission to processed files"+e);
//            }
//            
//            
//            
//
//        } catch (Exception ex) {
//            _logger.info("Exception while copying processed file"+fileName);
//        }
//
//    }
    
    public void deleteProcessedFile(String fileName){
        //System.out.println("Inside deleteProcessedFile method");
        try{
        File f = new File(Constants.JCS_INPUT_FOLDER + fileName);
        //FileUtils.forceDelete(f);
        if(f!=null){
            f.delete();
        }
        
            //System.out.println("Deleted file "+f);
        
        //f.delete();
    }catch(Exception ex){
        _logger.info("Exception while deleting processed file from source"+ex);
    }
    }
    
    public String  getCurrentDate(){
        Date date  = new Date();
        
        String formatedDate = new SimpleDateFormat("YYYYMMdd").format(date);
        
        //System.out.println("Current Date "+formatedDate);
        return formatedDate;
        
    }
    
    
    public String previousDate(int x){
        //Date currentDay = new Date();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -x); 
         String previousDay = new SimpleDateFormat("YYYYMMdd").format(cal.getTime());
         
         return previousDay;


    }
    
    
    
    
    
}
