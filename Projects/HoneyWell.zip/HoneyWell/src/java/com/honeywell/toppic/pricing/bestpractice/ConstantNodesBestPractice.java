package com.honeywell.toppic.pricing.bestpractice;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;

import com.honeywell.utils.Constants;
import org.apache.log4j.Logger;

public class ConstantNodesBestPractice {
    private static final Logger _logger = Logger.getLogger(ConstantNodesBestPractice.class.getName());
	
	
	static void constantTags(Document uploadXml, Element recoredListNode, String position, boolean isEmpty, String tableCode) {
		Element eachRecordNode = uploadXml.createElement("each_record");
		recoredListNode.appendChild(eachRecordNode);
		if (position.equalsIgnoreCase("header")) {
			
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "delete_all", "text");
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + ReadLineandGenerateMapping.salesOrg, "text");
		}
		else
		{
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + ReadLineandGenerateMapping.salesOrg, "text");
			createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, "DUMMY", "cdata");
			Element eachRecordNodeFooter = uploadXml.createElement("each_record");
			recoredListNode.appendChild(eachRecordNodeFooter);
			createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
			createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_ACTION, "deploy", "text");
			createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + ReadLineandGenerateMapping.salesOrg, "text");
		}
	}
	
	
	
	
	
	
	/*
	 * THIS METHOD APPENDS CHILD TAGS TO THE PARENT TAGS
	 */
	
	static void createXMLTags(Document staticXML, Element eachRecord, String tagName, String cdataContent, String type) {
		Element tags = staticXML.createElement(tagName);
		
		try
		{
			if (type.equalsIgnoreCase("text")) {
				tags.appendChild(staticXML.createTextNode(cdataContent));
			} else {
				if (cdataContent.isEmpty()) {
					tags.appendChild(staticXML.createTextNode(cdataContent));
				} else {
					tags.appendChild(staticXML.createCDATASection(cdataContent));
				}
			}
			eachRecord.appendChild(tags);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
