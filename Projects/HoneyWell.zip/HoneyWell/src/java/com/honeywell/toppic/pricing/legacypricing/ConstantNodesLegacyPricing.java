package com.honeywell.toppic.pricing.legacypricing;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;

import com.honeywell.utils.Constants;

/**
 * @author Deekshith
 *
 * Creates Header and Footer tags for pricing_legacy XML Files
 *
 */
public class ConstantNodesLegacyPricing {

    /*
	 * 
	 * header and footer tags generator for ZCSP,ZD00,ZD03,ZD04,ZD05,ZD06,ZD08 Table Codes
	 *    
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
    @param:position(Header or footer )
    @param:tableCode
	 * */
    ReadLineandGenerateMapping readLineandGenerateMapping = new ReadLineandGenerateMapping();

    void constantTags(Document uploadXml, Element recoredListNode, String position, boolean isEmpty, String tableCode) {
        //System.out.println("inside headers");
        Element eachRecordNode = uploadXml.createElement("each_record");
        recoredListNode.appendChild(eachRecordNode);
        if (position.equalsIgnoreCase("header")) {
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "delete_all", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
        } else {
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, "DUMMY", "cdata");
            Element eachRecordNodeFooter = uploadXml.createElement("each_record");
            recoredListNode.appendChild(eachRecordNodeFooter);
            createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_ACTION, "deploy", "text");
            createXMLTags(uploadXml, eachRecordNodeFooter, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
        }
    }

    /*
	 * 
	 * header and footer tags generator for ZP00 Table Codes
            @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
    @param:position(Header or footer )
    @param:tableCode
	 * 
	 * */
    void constantTagsZP00(Document uploadXml, Element recoredListNode, String position, boolean isEmpty, String tableCode) {
        Element eachRecordNode = uploadXml.createElement("each_record");
        recoredListNode.appendChild(eachRecordNode);
        if (position.equalsIgnoreCase("header")) {
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "delete_all", "text");
            createXMLTags(uploadXml, eachRecordNode, "id", "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, "", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, "", "text");
            Element eachRecordNodeSecondTag = uploadXml.createElement("each_record");
            recoredListNode.appendChild(eachRecordNodeSecondTag);
            createXMLTags(uploadXml, eachRecordNodeSecondTag, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNodeSecondTag, Constants.PRICING_XML_TAG_ACTION, "add", "text");
            createXMLTags(uploadXml, eachRecordNodeSecondTag, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
            createXMLTags(uploadXml, eachRecordNodeSecondTag, Constants.PRICING_XML_TAG_PARTNUMBER, "DUMMY", "CDATA");
        } else {
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "deploy", "text");
            createXMLTags(uploadXml, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + readLineandGenerateMapping.salesOrg, "text");
        }
    }

    /*
	 * THIS METHOD APPENDS CHILD TAGS TO THE PARENT TAGS
     */
    void createXMLTags(Document XML, Element eachRecord, String tagName, String cdataContent, String type) {

        Element tags = XML.createElement(tagName);

        try {
            if (type.equalsIgnoreCase("text")) {
                tags.appendChild(XML.createTextNode(cdataContent));

            } else if (cdataContent.isEmpty()) {
                tags.appendChild(XML.createTextNode(cdataContent));
            } else {
                tags.appendChild(XML.createCDATASection(cdataContent));
            }
            eachRecord.appendChild(tags);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
