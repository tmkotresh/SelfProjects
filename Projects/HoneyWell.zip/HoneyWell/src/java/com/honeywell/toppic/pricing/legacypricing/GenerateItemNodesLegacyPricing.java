package com.honeywell.toppic.pricing.legacypricing;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;

import com.honeywell.utils.Constants;

/**
 * @author Deekshith
 *
 * THIS CLASS WILL GENERATE LEGACY_PRICING ITEM TAGS
 *
 */
public class GenerateItemNodesLegacyPricing {

    String[] attributeValuesLegacyPricing = new String[50];


    /*
	 * THIS METHOD CREATES ZCSP_ITEM_LEGACY_PRICING ITEM TAGS
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    void createElementsZCSP(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable) {
        for (String s : temp) {

            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {
                // Document uploadXml = uploadXml_ZCSP;
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZCSP_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();

                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        String o = preProcessor.substring(0, preProcessor.indexOf("."));
                        String m = preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length());
                        finalValue = o + "." + m;
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }

                }

                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty()) ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SalesOffice, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VKBUR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VKBUR")].trim().replaceAll("-", ""), "CDATA");

            }
        }
    }

    /*
	 * THIS METHOD CREATES ZD00_ITEM_LEGACY_PRICING ITEM TAGS
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    void createElementsZD00(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable) {
        for (int i = 0; i < temp.size(); i++) {
            String s = new String();
            s = temp.get(i);
            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZD00_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? "DUMMY" : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_LOB, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();

                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        String o = preProcessor.substring(0, preProcessor.indexOf("."));
                        String m = preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length());
                        finalValue = o + "." + m;
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }

                }

                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty()) ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProdH2to5,
                        ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5")].trim()),
                        " ");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Brand, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MVGR1") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MVGR1")].trim().replaceAll("-", ""), "CDATA");

            }
        }
    }

    /*
	 * 
	 * THIS METHOD CREATES ITEM_LEGACY_PRICING ITEM TAGS FOR ZD03,ZD04,ZD0S
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    void createElementsZD03_ZD04_ZD05(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable, String tableCode) {
        for (int i = 0; i < temp.size(); i++) {
            String s = new String();
            s = temp.get(i);
            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {

                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? "DUMMY" : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_LOB, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();

                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        String o = preProcessor.substring(0, preProcessor.indexOf("."));
                        String m = preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length());
                        finalValue = o + "." + m;
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }

                }

                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty()) ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
                if (tableCode.equalsIgnoreCase("ZD03")) {

                    createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProdH2to5,
                            ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim())
                            + "|"
                            + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3")].trim())
                            + "|"
                            + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4")].trim())
                            + "|"
                            + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5")].trim()),
                            " ");
                }

            }
        }
    }

    /*
	 * 
	 * THIS METHOD CREATES ZD06_ITEM_LEGACY_PRICING ITEM TAGS
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    void createElementsZD06(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable, String tableCode) {
        for (int i = 0; i < temp.size(); i++) {
            String s = new String();
            s = temp.get(i);
            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZD06_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? "DUMMY" : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_LOB, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                String scale = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();

                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        finalValue = (preProcessor.substring(0, preProcessor.indexOf("."))) + "." + (preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()));
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }

                }
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ScaleValue, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : (attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty() ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProdH2to5,
                        ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH3")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH4")].trim())
                        + "|"
                        + ((ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH5")].trim()),
                        " ");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Brand, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MVGR1") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MVGR1")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ShipTo, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNWE") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNWE")].trim().replaceAll("-", ""), "CDATA");
            }
        }
    }

    /*
	 * 
	 * THIS METHOD CREATES ZD08_ITEM_LEGACY_PRICING ITEM TAGS
        @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
    
     */
    void createElementsZD08(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable, String tableCode) {
        for (int i = 0; i < temp.size(); i++) {
            String s = new String();
            s = temp.get(i);
            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZD08_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? "DUMMY" : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_LOB, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("ZZPRODH2")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();
                    //  System.out.println("preprocessor is "+preProcessor);
                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        finalValue = (preProcessor.substring(0, preProcessor.indexOf("."))) + "." + (preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()));
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }
                    //  System.out.println("final value is "+finalValue);
                }

                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty()) ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
            }
        }
    }

    /*
	 * 
	 * THIS METHOD CREATES ZP00_ITEM_LEGACY_PRICING ITEM TAGS
        @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    void createElementsZP00(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable, String tableCode) {
        //  System.out.println("zp00 temp size is "+temp.size());
        for (int i = 0; i < temp.size(); i++) {
            String s = new String();
            s = temp.get(i);
            attributeValuesLegacyPricing = s.split("\t");
            if (!attributeValuesLegacyPricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZP00_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesLegacyPricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR") == null) ? "DUMMY" : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("PLTYP")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONDA")].trim().replaceAll("-", ""), "CDATA");

                String preProcessor;
                String finalValue = "";
                if ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim() != null) && (!attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty())) {
                    preProcessor = attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim();
                    // System.out.println("preprocessor is "+preProcessor);
                    if (Integer.parseInt((preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()))) > 0) {
                        finalValue = (preProcessor.substring(0, preProcessor.indexOf("."))) + "." + (preProcessor.substring(preProcessor.indexOf(".") + 1, preProcessor.length()));
                    } else {
                        finalValue = preProcessor.substring(0, preProcessor.indexOf("."));
                    }
                    // System.out.println("final value is "+finalValue);
                }

                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM") == null) ? "0" : ((attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KSTBM")].trim().isEmpty()) ? "0" : finalValue.replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA") == null) ? " " : attributeValuesLegacyPricing[ReadLineandGenerateMapping.mappingForPricingLegacy.get("KONWA")].trim().replaceAll("-", ""), "CDATA");
            }
        }
    }

    /*
	 * THIS METHOD APPENDS CHILD TAGS TO THE PARENT TAGS
     */
    void createXMLTags(Document XML, Element eachRecord, String tagName, String cdataContent, String type) {
        Element tags = XML.createElement(tagName);

        if (type.equalsIgnoreCase("text")) {
            tags.appendChild(XML.createTextNode(cdataContent));

        } else if (cdataContent.isEmpty()) {

            tags.appendChild(XML.createTextNode("\n"));

            tags.appendChild(XML.createTextNode(cdataContent));
            tags.appendChild(XML.createTextNode("\n"));

        } else {

            tags.appendChild(XML.createTextNode("\n"));

            tags.appendChild(XML.createCDATASection(cdataContent));
            tags.appendChild(XML.createTextNode("\n"));

        }
        eachRecord.appendChild(tags);
    }
}
