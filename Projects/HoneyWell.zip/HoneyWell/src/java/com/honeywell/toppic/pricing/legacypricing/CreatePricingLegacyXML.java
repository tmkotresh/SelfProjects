package com.honeywell.toppic.pricing.legacypricing;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;
import com.honeywell.utils.FoldertoZipConverter;

import com.honeywell.utils.Constants;
import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * @author Deekshith
 *
 * This Class will create empty XML Files,Initializes the creation of tags and
 * pushes the XML files to Disk
 *
 */
public class CreatePricingLegacyXML {

    Document uploadXml_ZCSP;
    Document uploadXml_ZD00;
    Document uploadXml_ZD03;
    Document uploadXml_ZD04;
    Document uploadXml_ZD05;
    Document uploadXml_ZD06;
    Document uploadXml_ZD08;
    Document uploadXml_ZP00;
    Element nodeForProcessing_ZCSP;
    Element nodeForProcessing_ZD00;
    Element nodeForProcessing_ZD03;
    Element nodeForProcessing_ZD04;
    Element nodeForProcessing_ZD05;
    Element nodeForProcessing_ZD06;
    Element nodeForProcessing_ZD08;
    Element nodeForProcessing_ZP00;
    public ArrayList<String> entries_ZCSP = new ArrayList<String>();
    public ArrayList<String> entries_ZD00 = new ArrayList<String>();
    public ArrayList<String> entries_ZD03 = new ArrayList<String>();
    public ArrayList<String> entries_ZD04 = new ArrayList<String>();
    public ArrayList<String> entries_ZD05 = new ArrayList<String>();
    public ArrayList<String> entries_ZD06 = new ArrayList<String>();
    public ArrayList<String> entries_ZD08 = new ArrayList<String>();
    public ArrayList<String> entries_ZP00 = new ArrayList<String>();
    public ArrayList<ArrayList<String>> tableCodesArrayLegacyPricing = new ArrayList<ArrayList<String>>();
  //  public ArrayList<ArrayList<String>> tableCodesArrayLegacyPricing = new ArrayList<ArrayList<String>>();
    public HashMap<String, String> deltaLoadTablesStatus = new HashMap<String, String>();
    ReadLineandGenerateMapping readLineandGenerateMapping = new ReadLineandGenerateMapping();
    ConstantNodesLegacyPricing constantNodesLegacyPricing = new ConstantNodesLegacyPricing();
    GenerateItemNodesLegacyPricing generateItemNodesLegacyPricing = new GenerateItemNodesLegacyPricing();

    /*
    Method creates new xml file and the constant tags based on the table code recieved
    @param:tableCode
    
    */
    public void createNewXml(String code, String loadType) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        switch (code) {
            case "ZCSP":
                uploadXml_ZCSP = documentBuilder.newDocument();
                nodeForProcessing_ZCSP = uploadXml_ZCSP.createElement("record_list");
               
                uploadXml_ZCSP.appendChild(nodeForProcessing_ZCSP);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZCSP, nodeForProcessing_ZCSP, "header", false, code);
                }
                break;
            case "ZD00":
                uploadXml_ZD00 = documentBuilder.newDocument();
                nodeForProcessing_ZD00 = uploadXml_ZD00.createElement("record_list");
                uploadXml_ZD00.appendChild(nodeForProcessing_ZD00);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD00, nodeForProcessing_ZD00, "header", false, code);
                }
                break;
            case "ZD03":
                uploadXml_ZD03 = documentBuilder.newDocument();
                nodeForProcessing_ZD03 = uploadXml_ZD03.createElement("record_list");
                uploadXml_ZD03.appendChild(nodeForProcessing_ZD03);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD03, nodeForProcessing_ZD03, "header", false, code);
                }
                break;
            case "ZD04":
                uploadXml_ZD04 = documentBuilder.newDocument();
                nodeForProcessing_ZD04 = uploadXml_ZD04.createElement("record_list");
                uploadXml_ZD04.appendChild(nodeForProcessing_ZD04);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD04, nodeForProcessing_ZD04, "header", false, code);
                }
                break;
            case "ZD05":
                uploadXml_ZD05 = documentBuilder.newDocument();
                nodeForProcessing_ZD05 = uploadXml_ZD05.createElement("record_list");
                uploadXml_ZD05.appendChild(nodeForProcessing_ZD05);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD05, nodeForProcessing_ZD05, "header", false, code);
                }
                break;
            case "ZD06":
                uploadXml_ZD06 = documentBuilder.newDocument();
                nodeForProcessing_ZD06 = uploadXml_ZD06.createElement("record_list");
                uploadXml_ZD06.appendChild(nodeForProcessing_ZD06);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD06, nodeForProcessing_ZD06, "header", false, code);
                }
                break;
            case "ZD08":
                uploadXml_ZD08 = documentBuilder.newDocument();
                nodeForProcessing_ZD08 = uploadXml_ZD08.createElement("record_list");
                uploadXml_ZD08.appendChild(nodeForProcessing_ZD08);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTags(uploadXml_ZD08, nodeForProcessing_ZD08, "header", false, code);
                }
                break;
            case "ZP00":
                uploadXml_ZP00 = documentBuilder.newDocument();
                nodeForProcessing_ZP00 = uploadXml_ZP00.createElement("record_list");
                uploadXml_ZP00.appendChild(nodeForProcessing_ZP00);
                if (!loadType.equalsIgnoreCase("delta")) {
                    constantNodesLegacyPricing.constantTagsZP00(uploadXml_ZP00, nodeForProcessing_ZP00, "header", false, code);
                }
                break;
        }
    }

    /*
    Method stores attributes in the arraylist based on the table code recieved
    @param:tableCode
    @param:Attributes 
    
    */
    public void storeAttributes(String tableCode, String attributes, String runCount) {
        if (runCount.equalsIgnoreCase("first")) {
            switch (tableCode) {
                case "ZCSP":
                    entries_ZCSP.add(attributes);
                    break;
                case "ZD00":
                    entries_ZD00.add(attributes);
                    break;

            }
        } else if (runCount.equalsIgnoreCase("second")) {
            switch (tableCode) {
                case "ZD03":
                    entries_ZD03.add(attributes);
                    break;
                case "ZD04":
                    entries_ZD04.add(attributes);
                    break;
            }
        } else if (runCount.equalsIgnoreCase("third")) {
            switch (tableCode) {
                case "ZD05":
                    entries_ZD05.add(attributes);
                    break;
                case "ZD06":
                    entries_ZD06.add(attributes);
                    break;
            }
        } else if (runCount.equalsIgnoreCase("fourth")) {
            switch (tableCode) {

                case "ZD08":
                    entries_ZD08.add(attributes);
                    break;
                case "ZP00":
                    entries_ZP00.add(attributes);
                    break;
            }
        }

    }

    public void storeAttributeArray(String runCount) {
        adAttributes(runCount);
        CreateXML(runCount);
        clearAttributes(runCount);
    }

    /*
    Method invokes the createTags methoid based on the runcount recieved
    
    @param:runCount
    
    */
    void CreateXML(String runCount) {
         for (int i = 0; i < tableCodesArrayLegacyPricing.size(); i++) {
        if (runCount.equalsIgnoreCase("first")) {
           
                ArrayList<String> temp = tableCodesArrayLegacyPricing.get(i);
                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZCSP":
                            createTags(uploadXml_ZCSP, nodeForProcessing_ZCSP, false, "ZCSP", temp);
                            break;
                        case "ZD00":
                            createTags(uploadXml_ZD00, nodeForProcessing_ZD00, false, "ZD00", temp);
                            break;

                    }
                
            }
        } else if (runCount.equalsIgnoreCase("second")) {
           
                ArrayList<String> temp = tableCodesArrayLegacyPricing.get(i);
                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {

                        case "ZD03":
                            createTags(uploadXml_ZD03, nodeForProcessing_ZD03, false, "ZD03", temp);
                            break;
                        case "ZD04":
                            createTags(uploadXml_ZD04, nodeForProcessing_ZD04, false, "ZD04", temp);
                            break;

                    }
                
            }
        } else if (runCount.equalsIgnoreCase("third")) {
           
                ArrayList<String> temp = tableCodesArrayLegacyPricing.get(i);
              
                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {

                        case "ZD05":
                            createTags(uploadXml_ZD05, nodeForProcessing_ZD05, false, "ZD05", temp);
                            break;
                        case "ZD06":
                            createTags(uploadXml_ZD06, nodeForProcessing_ZD06, false, "ZD06", temp);
                            break;

                    }
                
            }
        } else if (runCount.equalsIgnoreCase("fourth")) {
           
                ArrayList<String> temp = tableCodesArrayLegacyPricing.get(i);
          
                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZD08":
                            createTags(uploadXml_ZD08, nodeForProcessing_ZD08, false, "ZD08", temp);
                            break;
                        case "ZP00":
                            createTags(uploadXml_ZP00, nodeForProcessing_ZP00, false, "ZP00", temp);
                            break;
                    }
                }
            
        }
         }
    }

    /*
    Method generates the item nodes in the xml files
    @param:XMLFile for processing
    @param:tableCode
    @param:attributes list
    */
    void createTags(Document uploadXml, Element recoredListNode, boolean isEmpty, String tableCode, ArrayList<String> attributeValues) {
        switch (tableCode) {
            case "ZCSP":
                generateItemNodesLegacyPricing.createElementsZCSP(attributeValues, uploadXml, recoredListNode);
                break;
            case "ZD00":
                generateItemNodesLegacyPricing.createElementsZD00(attributeValues, uploadXml, recoredListNode);
                break;
            case "ZD03":
                generateItemNodesLegacyPricing.createElementsZD03_ZD04_ZD05(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
            case "ZD04":
                generateItemNodesLegacyPricing.createElementsZD03_ZD04_ZD05(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
            case "ZD05":
                generateItemNodesLegacyPricing.createElementsZD03_ZD04_ZD05(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
            case "ZD06":
                generateItemNodesLegacyPricing.createElementsZD06(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
            case "ZD08":
                generateItemNodesLegacyPricing.createElementsZD08(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
            case "ZP00":
                generateItemNodesLegacyPricing.createElementsZP00(attributeValues, uploadXml, recoredListNode, tableCode);
                break;
        }
    }

    /*
    This methoid creates the footer tags in the xmlm file 
    @param:tableCode
    @param:LoadType
    */
    public void createfooterTags(String tableCode, String loadType) {
        switch (tableCode) {
            case "ZCSP":
                constantNodesLegacyPricing.constantTags(uploadXml_ZCSP, nodeForProcessing_ZCSP, "footer", false, tableCode);
                break;
            case "ZD00":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD00, nodeForProcessing_ZD00, "footer", false, tableCode);
                break;
            case "ZD03":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD03, nodeForProcessing_ZD03, "footer", false, tableCode);
                break;
            case "ZD05":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD05, nodeForProcessing_ZD05, "footer", false, tableCode);
                break;
            case "ZD04":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD04, nodeForProcessing_ZD04, "footer", false, tableCode);
                break;
            case "ZD06":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD06, nodeForProcessing_ZD06, "footer", false, tableCode);
                break;
            case "ZD08":
                constantNodesLegacyPricing.constantTags(uploadXml_ZD08, nodeForProcessing_ZD08, "footer", false, tableCode);
                break;
            case "ZP00":
                constantNodesLegacyPricing.constantTagsZP00(uploadXml_ZP00, nodeForProcessing_ZP00, "footer", false, tableCode);
                break;
        }
    }

    /*
    Methid moves the xml files to disk based on the table code received.
    @param:salesOrg
    @param:loadTyoe
    @param:runCount
    */
    public void movaAllFilestoDisk(String salesOrg, String loadType, String runCount) throws SftpException, FileNotFoundException {
        if (runCount.equalsIgnoreCase("first")) {
            for (String str : Constants.table_Codes_legacy) {
                switch (str) {
                    case "ZCSP":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZCSP, "ZCSP" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZCSP, "ZCSP" + "_" + salesOrg);
                        }

                    case "ZD00":
                    //    System.out.println("zd00 status " + deltaLoadTablesStatus.get(str));
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD00, "ZD00" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD00, "ZD00" + "_" + salesOrg);
                        }
                        break;

                }
            }
        } else if (runCount.equals("second")) {
            for (String str : Constants.table_Codes_legacy) {
                switch (str) {

                    case "ZD04":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD04, "ZD04" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD04, "ZD04" + "_" + salesOrg);
                        }
                        break;

                    case "ZD03":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD03, "ZD03" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD03, "ZD03" + "_" + salesOrg);
                        }
                        break;
                }
            }
        } else if (runCount.equals("third")) {
            for (String str : Constants.table_Codes_legacy) {
                switch (str) {

                    case "ZD05":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD05, "ZD05" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD05, "ZD05" + "_" + salesOrg);
                        }
                        break;
                    case "ZD06":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD06, "ZD06" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD06, "ZD06" + "_" + salesOrg);
                        }
                        break;

                }
            }
        } else if (runCount.equals("fourth")) {
            for (String str : Constants.table_Codes_legacy) {
                switch (str) {

                    case "ZP00":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZP00, "ZP00" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZP00, "ZP00" + "_" + salesOrg);
                        }
                        break;

                    case "ZD08":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZD08, "ZD08" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZD08, "ZD08" + "_" + salesOrg);
                        }
                        break;

                }
            }
        }

    }

    /*
    
    This method will set the required properties to the xml file before flushing it to the Disk
    @param:XMLFile
    @param:fileName
    
    */
    void moveXMLtoDisk(Document finalXML, String fileName) throws SftpException, FileNotFoundException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = null;
        try {
            transformer = transformerFactory.newTransformer();
         //   transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
         finalXML.setXmlStandalone(true);
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            DOMSource xmlSource = new DOMSource(finalXML);
            StreamResult uploadXMLFile = new StreamResult(Constants.JCS_OUTPUT_FOLDER + fileName + "_" + ReadLineandGenerateMapping.dateToAppend + ".xml");
            transformer.transform(xmlSource, uploadXMLFile);

                        File f = new File(Constants.JCS_OUTPUT_FOLDER + fileName + "_" + ReadLineandGenerateMapping.dateToAppend + ".xml");
                        f.setExecutable(true, false);
            f.setReadable(true, false);
            f.setWritable(true, false);
            FoldertoZipConverter foldertoZipConverter = new FoldertoZipConverter();
            foldertoZipConverter.createZip(fileName + "_" + ReadLineandGenerateMapping.dateToAppend +".xml");
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }

    public void initializeLoadFilesDeltaMap() {
        for (String str : Constants.table_Codes_legacy) {
            deltaLoadTablesStatus.put(str, "N");
        }
    }

    /*
    Method adds the arraylist of attributes to another arraylist which holds the data from all the input files
    
    @param:runCount
    */
    public void adAttributes(String runCount) {

        if (runCount.equalsIgnoreCase("first")) {
            tableCodesArrayLegacyPricing.clear();
            tableCodesArrayLegacyPricing.add(entries_ZCSP);
            tableCodesArrayLegacyPricing.add(entries_ZD00);

        } else if (runCount.equalsIgnoreCase("second")) {
            tableCodesArrayLegacyPricing.clear();
            tableCodesArrayLegacyPricing.add(entries_ZD03);
            tableCodesArrayLegacyPricing.add(entries_ZD04);
        } else if (runCount.equalsIgnoreCase("third")) {
            tableCodesArrayLegacyPricing.clear();
            tableCodesArrayLegacyPricing.add(entries_ZD05);
            tableCodesArrayLegacyPricing.add(entries_ZD06);
        } else if (runCount.equals("fourth")) {
            tableCodesArrayLegacyPricing.clear();

            tableCodesArrayLegacyPricing.add(entries_ZD08);
            tableCodesArrayLegacyPricing.add(entries_ZP00);
            
        }

    }

    /*
    Method clears entries in the array List based on the table codes and runCount
    @param:runCount
    */
    public void clearAttributes(String runCount) {
        if (runCount.equalsIgnoreCase("first")) {
            entries_ZCSP.clear();
            entries_ZD00.clear();

        } else if (runCount.equalsIgnoreCase("second")) {
            entries_ZD03.clear();
            entries_ZD04.clear();
        } else if (runCount.equalsIgnoreCase("third")) {
            entries_ZD05.clear();
            entries_ZD06.clear();
        } else if (runCount.equalsIgnoreCase("fourth")) {

            entries_ZD08.clear();
            entries_ZP00.clear();
        }

    }
}
