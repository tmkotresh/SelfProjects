package com.honeywell.toppic.pricing.bestpractice;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.utils.Constants;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;
import com.honeywell.utils.FoldertoZipConverter;
import java.io.File;

/**
 * @author Deekshith
 *
 * This Class will create empty XML Files,Initializes the creation of tags and
 * pushes the XML files to Disk
 *
 */
public class CreateBestPracticeXML {

    Document uploadXml_ZOEM;
    Document uploadXml_ZX02;
    Document uploadXml_ZX04;
    Document uploadXml_ZX06;
    Document uploadXml_ZX07;
    Document uploadXml_ZX09;
    Document uploadXml_ZX12;
    Document uploadXml_ZXMO;
    Document uploadXml_ZXNP;
    Document uploadXml_ZXPR;
    Element nodeForProcessing_ZOEM;
    Element nodeForProcessing_ZX02;
    Element nodeForProcessing_ZX04;
    Element nodeForProcessing_ZX06;
    Element nodeForProcessing_ZX07;
    Element nodeForProcessing_ZX09;
    Element nodeForProcessing_ZX12;
    Element nodeForProcessing_ZXMO;
    Element nodeForProcessing_ZXNP;
    Element nodeForProcessing_ZXPR;
    ArrayList<String> entries_ZOEM = new ArrayList<String>();
    ArrayList<String> entries_ZX02 = new ArrayList<String>();
    ArrayList<String> entries_ZX04 = new ArrayList<String>();
    ArrayList<String> entries_ZX06 = new ArrayList<String>();
    ArrayList<String> entries_ZX07 = new ArrayList<String>();
    ArrayList<String> entries_ZX09 = new ArrayList<String>();
    ArrayList<String> entries_ZX12 = new ArrayList<String>();
    ArrayList<String> entries_ZXMO = new ArrayList<String>();
    ArrayList<String> entries_ZXNP = new ArrayList<String>();
    ArrayList<String> entries_ZXPR = new ArrayList<String>();
    ArrayList<ArrayList<String>> tableCodesArrayBestPracticePricing = new ArrayList<ArrayList<String>>();
    public HashMap<String, String> deltaLoadBestPracticeTablesStatus = new HashMap<String, String>();

   
   
    ReadLineandGenerateMapping readLineandGenerateMapping = new ReadLineandGenerateMapping();

    public void initializeBestPracticeLoadFilesDeltaMap() {
        for (String str : Constants.table_Codes_Bestpractice) {
            deltaLoadBestPracticeTablesStatus.put(str, "N");
        }
    }

      /*
    Method creates new xml file and the constant tags based on the table code recieved
    @param:tableCode
    
    */
    public void createNewXml(String code, String loadType) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        switch (code) {
            case "ZOEM":
                uploadXml_ZOEM = documentBuilder.newDocument();
                nodeForProcessing_ZOEM = uploadXml_ZOEM.createElement("record_list");
                uploadXml_ZOEM.appendChild(nodeForProcessing_ZOEM);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZOEM, nodeForProcessing_ZOEM, "header", false, code);
                }
                break;
            case "ZX02":
                uploadXml_ZX02 = documentBuilder.newDocument();
                nodeForProcessing_ZX02 = uploadXml_ZX02.createElement("record_list");
                uploadXml_ZX02.appendChild(nodeForProcessing_ZX02);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX02, nodeForProcessing_ZX02, "header", false, code);
                }
                break;
            case "ZX04":
                uploadXml_ZX04 = documentBuilder.newDocument();
                nodeForProcessing_ZX04 = uploadXml_ZX04.createElement("record_list");
                uploadXml_ZX04.appendChild(nodeForProcessing_ZX04);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX04, nodeForProcessing_ZX04, "header", false, code);
                }
                break;
            case "ZX06":
                uploadXml_ZX06 = documentBuilder.newDocument();
                nodeForProcessing_ZX06 = uploadXml_ZX06.createElement("record_list");
                uploadXml_ZX06.appendChild(nodeForProcessing_ZX06);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX06, nodeForProcessing_ZX06, "header", false, code);
                }
                break;
            case "ZX07":
                uploadXml_ZX07 = documentBuilder.newDocument();
                nodeForProcessing_ZX07 = uploadXml_ZX07.createElement("record_list");
                uploadXml_ZX07.appendChild(nodeForProcessing_ZX07);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX07, nodeForProcessing_ZX07, "header", false, code);
                }
                break;
            case "ZX09":
                uploadXml_ZX09 = documentBuilder.newDocument();
                nodeForProcessing_ZX09 = uploadXml_ZX09.createElement("record_list");
                uploadXml_ZX09.appendChild(nodeForProcessing_ZX09);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX09, nodeForProcessing_ZX09, "header", false, code);
                }
                break;
            case "ZX12":
                uploadXml_ZX12 = documentBuilder.newDocument();
                nodeForProcessing_ZX12 = uploadXml_ZX12.createElement("record_list");
                uploadXml_ZX12.appendChild(nodeForProcessing_ZX12);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZX12, nodeForProcessing_ZX12, "header", false, code);
                }
                break;
            case "ZXMO":
                uploadXml_ZXMO = documentBuilder.newDocument();
                nodeForProcessing_ZXMO = uploadXml_ZXMO.createElement("record_list");
                uploadXml_ZXMO.appendChild(nodeForProcessing_ZXMO);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZXMO, nodeForProcessing_ZXMO, "header", false, code);
                }
                break;
            case "ZXNP":
                uploadXml_ZXNP = documentBuilder.newDocument();
                nodeForProcessing_ZXNP = uploadXml_ZXNP.createElement("record_list");
                uploadXml_ZXNP.appendChild(nodeForProcessing_ZXNP);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZXNP, nodeForProcessing_ZXNP, "header", false, code);
                }
                break;
            case "ZXPR":
                uploadXml_ZXPR = documentBuilder.newDocument();
                uploadXml_ZXPR.setXmlStandalone(true);
                nodeForProcessing_ZXPR = uploadXml_ZXPR.createElement("record_list");
                uploadXml_ZXPR.appendChild(nodeForProcessing_ZXPR);
                if (!loadType.equalsIgnoreCase("delta")) {
                    ConstantNodesBestPractice.constantTags(uploadXml_ZXPR, nodeForProcessing_ZXPR, "header", false, code);
                }
                break;
        }
    }

      /*
    Method stores attributes in the arraylist based on the table code recieved
    @param:tableCode
    @param:Attributes 
    
    */
    public void storeAttributes(String tableCode, String attributes, String runCount) {
  
        if (runCount.equalsIgnoreCase("first")) {
        
            switch (tableCode) {
                case "ZOEM":
                    entries_ZOEM.add(attributes);
                    break;
                case "ZX02":
                    entries_ZX02.add(attributes);
                    break;
                case "ZX04":
                
                    entries_ZX04.add(attributes);
                    break;
            }
        } else if (runCount.equalsIgnoreCase("second")) {
            switch (tableCode) {
                case "ZX06":
                    entries_ZX06.add(attributes);
                    break;
                case "ZX07":
                    entries_ZX07.add(attributes);
                    break;
                case "ZX09":
                    entries_ZX09.add(attributes);
                    break;
            }
        } else if (runCount.equalsIgnoreCase("third")) {
            switch (tableCode) {
                case "ZX12":
                    entries_ZX12.add(attributes);
                    break;
                case "ZXMO":
                    entries_ZXMO.add(attributes);
                    break;
            }
        } else if (runCount.equalsIgnoreCase("fourth")) {
            switch (tableCode) {

                case "ZXNP":
                    entries_ZXNP.add(attributes);
                    break;
                case "ZXPR":
                    entries_ZXPR.add(attributes);
                    break;
            }

        }

    }



    public void storeAttributeArray(String runCount) {
        adAttributes(runCount);
    
        CreateXML(runCount);
        clearAttributes(runCount);
    }

      /*
    Method invokes the createTags methoid based on the runcount recieved
    
    @param:runCount
    
    */
    public void CreateXML(String runCount) {
        for (int i = 0; i < tableCodesArrayBestPracticePricing.size(); i++) {

            ArrayList<String> temp = tableCodesArrayBestPracticePricing.get(i);
            if (runCount.equalsIgnoreCase("first")) {

                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZOEM":
                            createTags(uploadXml_ZOEM, nodeForProcessing_ZOEM, false, "ZOEM", temp);
                            break;
                        case "ZX02":
                            createTags(uploadXml_ZX02, nodeForProcessing_ZX02, false, "ZX02", temp);
                            break;
                        case "ZX04":
                            createTags(uploadXml_ZX04, nodeForProcessing_ZX04, false, "ZX04", temp);
                            break;
                    }
                }
            } else if (runCount.equalsIgnoreCase("second")) {

                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZX06":
                            createTags(uploadXml_ZX06, nodeForProcessing_ZX06, false, "ZX06", temp);
                            break;
                        case "ZX07":
                            createTags(uploadXml_ZX07, nodeForProcessing_ZX07, false, "ZX07", temp);
                            break;
                        case "ZX09":
                            createTags(uploadXml_ZX09, nodeForProcessing_ZX09, false, "ZX09", temp);
                            break;
                    }
                }
            } else if (runCount.equalsIgnoreCase("third")) {

                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZX12":
                            createTags(uploadXml_ZX12, nodeForProcessing_ZX12, false, "ZX12", temp);
                            break;
                        case "ZXMO":
                            createTags(uploadXml_ZXMO, nodeForProcessing_ZXMO, false, "ZXMO", temp);
                            break;
                    }
                }
            } else if (runCount.equalsIgnoreCase("fourth")) {

                if (temp.size() > 0) {
                    switch (temp.get(0).split("\t")[3]) {
                        case "ZXNP":
                            createTags(uploadXml_ZXNP, nodeForProcessing_ZXNP, false, "ZXNP", temp);
                            break;
                        case "ZXPR":
                            createTags(uploadXml_ZXPR, nodeForProcessing_ZXPR, false, "ZXPR", temp);
                            break;
                    }

                }
            }

        }
    }

       /*
    Method generates the item nodes in the xml files
    @param:XMLFile for processing
    @param:tableCode
    @param:attributes list
    */
    void createTags(Document uploadXml, Element recoredListNode, boolean isEmpty, String tableCode, ArrayList<String> attributeValues) {
        if (tableCode.equalsIgnoreCase("ZOEM")) {
            GenerateItemNodesBestPractice.createElementsZOEM(attributeValues, uploadXml, recoredListNode);
        } else {
            GenerateItemNodesBestPractice.createElementsCommon(attributeValues, uploadXml, recoredListNode, tableCode);
        }
    }

    /*
    This methoid creates the footer tags in the xmlm file 
    @param:tableCode
   
    */
    public void createfooterTags(String tableCode) {
        switch (tableCode) {
            case "ZOEM":
              //  System.out.println("inside zoem footer tags");
                ConstantNodesBestPractice.constantTags(uploadXml_ZOEM, nodeForProcessing_ZOEM, "footer", false, tableCode);
                break;
            case "ZX02":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX02, nodeForProcessing_ZX02, "footer", false, tableCode);
                break;
            case "ZX04":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX04, nodeForProcessing_ZX04, "footer", false, tableCode);
                break;
            case "ZX06":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX06, nodeForProcessing_ZX06, "footer", false, tableCode);
                break;
            case "ZX07":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX07, nodeForProcessing_ZX07, "footer", false, tableCode);
                break;
            case "ZX09":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX09, nodeForProcessing_ZX09, "footer", false, tableCode);
                break;
            case "ZX12":
                ConstantNodesBestPractice.constantTags(uploadXml_ZX12, nodeForProcessing_ZX12, "footer", false, tableCode);
                break;
            case "ZXMO":
             //   System.out.println("ZXMO STATUS CODE IS" + tableCode);
                ConstantNodesBestPractice.constantTags(uploadXml_ZXMO, nodeForProcessing_ZXMO, "footer", false, "ZXMO");
                break;
            case "ZXNP":
                ConstantNodesBestPractice.constantTags(uploadXml_ZXNP, nodeForProcessing_ZXNP, "footer", false, tableCode);
                break;
            case "ZXPR":
                ConstantNodesBestPractice.constantTags(uploadXml_ZXPR, nodeForProcessing_ZXPR, "footer", false, tableCode);
                break;
        }
    }

     /*
    Methid moves the xml files to disk based on the table code received.
    @param:salesOrg
    @param:loadTyoe
    @param:runCount
    */
    public void movaAllFilestoDisk(String salesOrg, String loadType, String runCount) {
        for (String str : Constants.table_Codes_Bestpractice) {
            if (runCount.equalsIgnoreCase("first")) {
                switch (str) {
                    case "ZOEM":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZOEM, "ZOEM" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZOEM, "ZOEM" + "_" + salesOrg);
                        }
                        break;
                    case "ZX02":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX02, "ZX02" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX02, "ZX02" + "_" + salesOrg);
                        }
                        break;
                    case "ZX04":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX04, "ZX04" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX04, "ZX04" + "_" + salesOrg);
                        }
                        break;
                }
            } else if (runCount.equalsIgnoreCase("second")) {
                switch (str) {
                    case "ZX06":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX06, "ZX06" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX06, "ZX06" + "_" + salesOrg);
                        }
                        break;
                    case "ZX07":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX07, "ZX07" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX07, "ZX07" + "_" + salesOrg);
                        }
                        break;
                    case "ZX09":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX09, "ZX09" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX09, "ZX09" + "_" + salesOrg);
                        }
                        break;
                }
            } else if (runCount.equalsIgnoreCase("third")) {
                switch (str) {
                    case "ZX12":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZX12, "ZX12" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZX12, "ZX12" + "_" + salesOrg);
                        }
                        break;
                    case "ZXMO":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZXMO, "ZXMO" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZXMO, "ZXMO" + "_" + salesOrg);
                        }
                        break;
                }
            } else if (runCount.equalsIgnoreCase("fourth")) {
                switch (str) {

                    case "ZXNP":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZXNP, "ZXNP" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZXNP, "ZXNP" + "_" + salesOrg);
                        }
                        break;
                    case "ZXPR":
                        if (loadType.equalsIgnoreCase("delta")) {
                            if (deltaLoadBestPracticeTablesStatus.get(str).equalsIgnoreCase("Y")) {
                                moveXMLtoDisk(uploadXml_ZXPR, "ZXPR" + "_" + salesOrg);
                            }
                        } else {
                            moveXMLtoDisk(uploadXml_ZXPR, "ZXPR" + "_" + salesOrg);
                        }
                        break;
                }
            }

        }
    }

      /*
    
    This method will set the required properties to the xml file before flushing it to the Disk
    @param:XMLFile
    @param:fileName
    
    */
    void moveXMLtoDisk(Document finalXML, String fileName) {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = null;
        try {
            transformer = transformerFactory.newTransformer();
             finalXML.setXmlStandalone(true);
            DOMSource xmlSource = new DOMSource(finalXML);
            StreamResult uploadXMLFile = new StreamResult(Constants.JCS_OUTPUT_FOLDER + fileName + "_" + ReadLineandGenerateMapping.dateToAppend + ".xml");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.transform(xmlSource, uploadXMLFile);
            
               File f = new File(Constants.JCS_OUTPUT_FOLDER + fileName + "_" + ReadLineandGenerateMapping.dateToAppend + ".xml");
                        f.setExecutable(true, false);
            f.setReadable(true, false);
            f.setWritable(true, false);
            FoldertoZipConverter foldertoZipConverter = new FoldertoZipConverter();
            foldertoZipConverter.createZip(fileName + "_" + ReadLineandGenerateMapping.dateToAppend +".xml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

     /*
    Method adds the arraylist of attributes to another arraylist which holds the data from all the input files
    
    @param:runCount
    */
    public void adAttributes(String runCount) {

        switch (runCount) {

            case ("first"):
                tableCodesArrayBestPracticePricing.clear();
                tableCodesArrayBestPracticePricing.add(entries_ZOEM);
                tableCodesArrayBestPracticePricing.add(entries_ZX02);
                tableCodesArrayBestPracticePricing.add(entries_ZX04);
                
             //   System.out.println("zx04 is "+ entries_ZX04);
                break;

            case ("second"):
                tableCodesArrayBestPracticePricing.clear();
                tableCodesArrayBestPracticePricing.add(entries_ZX06);
                tableCodesArrayBestPracticePricing.add(entries_ZX07);
                tableCodesArrayBestPracticePricing.add(entries_ZX09);
                break;
            case ("third"):
                tableCodesArrayBestPracticePricing.clear();
                tableCodesArrayBestPracticePricing.add(entries_ZX12);
                tableCodesArrayBestPracticePricing.add(entries_ZXMO);
                break;
            case ("fourth"):
                tableCodesArrayBestPracticePricing.clear();
                tableCodesArrayBestPracticePricing.add(entries_ZXNP);
                tableCodesArrayBestPracticePricing.add(entries_ZXPR);
                break;

        }
    }

       /*
    Method clears entries in the array List based on the table codes and runCount
    @param:runCount
    */
    public void clearAttributes(String runCount) {
        switch (runCount) {
            case ("first"):
                entries_ZOEM.clear();
                entries_ZX02.clear();
                entries_ZX04.clear();
                break;
            case ("second"):
                entries_ZX06.clear();
                entries_ZX07.clear();
                entries_ZX09.clear();
                break;
            case ("third"):
                entries_ZX12.clear();
                entries_ZXMO.clear();
                break;
            case ("fourth"):
                entries_ZXNP.clear();
                entries_ZXPR.clear();
                break;

        }

    }
}
