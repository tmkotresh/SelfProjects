/**
 * MaterialTxtToXML class converts .txt files related to Material to .xml format
 * SAX parser is used to convert .txt file to .xml
 *
 * @author kmatada
 */
package com.honeywell.toppic.material;

import com.honeywell.toppic.TxtToXMLCommon;

import com.honeywell.utils.Constants;
import com.honeywell.utils.DatabaseUtility;
import com.honeywell.utils.FileListGenerator;
import com.honeywell.utils.FoldertoZipConverter;
import com.honeywell.utils.MoveProcessedFiles;
import com.jcraft.jsch.SftpException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import org.apache.log4j.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

//import org.apache.commons.lang3.StringUtils;
import org.xml.sax.SAXException;

//import com.oracle.hwwebmethods.csutomer.MaterialGeneratorTransformerHandler;
public class MaterialTxtToXML {

    BufferedReader in;
    StreamResult out;
    TransformerHandler th;

    String[] values = null;
    String tableName = null;

    String type = null;
    //int lineCount = 0;

    Map<String, Integer> mapFile = new HashMap<String, Integer>();
    Map<String, Integer> mapAccess = new HashMap<String, Integer>();
    

    private static final Logger _logger = Logger.getLogger(MaterialTxtToXML.class.getName());
    public static HashMap<Integer, ArrayList<File>> filestoProcess = new HashMap<>();
    
      int noOfFile = 0;
        String file, file1 = "";
        int first = -1, second = -1;
         File destinationFolder = new File(Constants.JCS_OUTPUT_FOLDER);

    public MaterialTxtToXML() {

    }

    public static void main(String[] args) {
        try {
            new MaterialTxtToXML().generateXML("2247");
        } catch (ParseException ex) {
            java.util.logging.Logger.getLogger(MaterialTxtToXML.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    TxtToXMLCommon txtToCommon = new TxtToXMLCommon();
    String currentDate = new TxtToXMLCommon().getCurrentDate();

    public void generateXML(String salesOrg) throws ParseException {

      

        filestoProcess = new FileListGenerator().fetchFilesToProcess(salesOrg, "MATERIAL");
         type = new DatabaseUtility().fetchMaterialType(salesOrg);

        if (filestoProcess == null) {
            _logger.info("*** No (Material) files present for SalesOrg " + salesOrg);

            return;
        }
       

        File[] files = null;
        ArrayList<File> filesList = new ArrayList<>();
        for (Map.Entry<Integer, ArrayList<File>> entry : filestoProcess.entrySet()) {
           
            filesList.addAll(entry.getValue());
        }

        files = filesList.toArray(new File[filesList.size()]);

        if (files.length == 0) {
            _logger.info("***No files present to process***");
            return;
        }
        
        //Check if files belong to same sales org
        
        checkIfFilesBelongToSameSalesOrg(files);

        //processing files
        _logger.info("Converting Material Data for SalesOrg "+salesOrg );
        
        processFiles(files);
        
        
       //Move processed files to a processed folder
        try {
            
            new MoveProcessedFiles().moveFiles(filesList, salesOrg);
        } catch (Exception e) {
            _logger.info("Exception while deleting processed customer files " + e);
        }
      

       
        _logger.info("**************************************************");
    }
    
    
    public void checkIfFilesBelongToSameSalesOrg(File[] files){
        
        
        
      
        //logic to count no of file with same Org(Material_2092,2092,2093,2093,2092) like Material_2092 have 2 file so output of 2092 merge in one file 
        for (int j = 0; j < files.length; j++) {

            file = files[j].getName().trim();
           
                file = getFileName(file);
                if (mapFile.containsKey(file)) {
                    noOfFile = mapFile.get(file);

                    

                    mapFile.put(file, ++noOfFile);

                } else {
                    mapFile.put(file, 1);

                }
                

           
        }
        
    }
    
    public void processFiles(File[] files){
        
        int proccFileCount = 0;
       
        _logger.info("Processing files");
        for (int i = 0; i < files.length; i++) {
           

            tableName = files[i].getName().substring(12, 20);
            
            tableName = tableName.substring(0,1).toUpperCase() + tableName.substring(1).toLowerCase();
            tableName = tableName.concat("_").concat(files[i].getName().substring(21, 25));
           
            
            int _len = tableName.indexOf("_");
            String fileName1 = tableName.substring(0, _len);
           
          
                _logger.info("" + files[i].getName());

              
                file = files[i].getName().trim();
                
                proccFileCount++;
                file = getFileName(file);
                if (mapAccess.get(file) == null) {
                   

                    startTag(destinationFolder, files[i].getName(), type);
                    noOfFile = mapFile.get(file);
                    mapFile.put(file, --noOfFile);

                    mapAccess.put(file, 1);
                } else {
                    //if Material_2092 1 time processed so next time not oppening StreamResult
                    noOfFile = mapFile.get(file);
                    mapFile.put(file, --noOfFile);
                }
                try {

                    
                   
                    in = new BufferedReader(new FileReader(files[i]));

                    // TO POPULATE FIRST RECORD
                    String str;
                    //for (int k = 0; k < files.length; k++) {

                    //_logger.info("\t" + files[k]);
                    // TO SKIP FIRST ROW
                    in.readLine();

                    while ((str = in.readLine()) != null) {

                        values = str.split("\t");

                        if (type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG)) {
                            populateAttributes(Constants.MATERIAL_SALES_ORG);
                        } else if (type.equalsIgnoreCase(Constants.MATERIAL_LIST)) {
                            populateAttributes(Constants.MATERIAL_LIST);
                        }

                        //lineCount++;
                    }
                    //}

                } catch (Exception e) {
                    _logger.info("Error occured while processing file " + files[i].getName() + " and exception is " + e);
                    _logger.info("Stack trace " + e);
                   

                }

               
                //if all file are processed with same org like Org(Material_2092,2092,2093,2093,2092) then call fixed attribute
                file = files[i].getName().trim();
                file = getFileName(file);
               
                noOfFile = mapFile.get(file);
                if (noOfFile == 0) {
                    //checking 
                    // TO POPULATE LAST RECORD
                    try {

                        new MaterialGeneratorTransformerHandler(th).fixedAttributes(tableName, "END", type);
                        th.endDocument();
                        in.close();
                        closeXml();

                        //Passing generated file name to file zip creation
                        String name = files[i].getName();
                       
                        String fName = null;
                        
                         String fileName = name.substring(12, 20);
             fileName = fileName.substring(0,1).toUpperCase() + fileName.substring(1).toLowerCase();
             fileName = fileName.concat("_").concat(name.substring(21, 25));
            
             
             
             /*
             
             
             tableName = files[i].getName().substring(12, 20);
            
            tableName = tableName.substring(0,1).toUpperCase() + tableName.substring(1).toLowerCase();
            tableName = tableName.concat("_").concat(files[i].getName().substring(21, 25));
            System.out.println("Table Name "+ tableName);
             */
                        //name.substring(12, 25).concat("_").concat(name.substring(29, 37).concat(name.substring(name.indexOf(".")).replace(".txt", ".xml")));

                        if (type.equalsIgnoreCase(Constants.MATERIAL_LIST)) {
                            fName = Constants.MATERIAL_LIST.concat("_").concat(currentDate)
                                    .concat(name.substring(name.indexOf(".")).replace(".txt", ".xml"));
                        } else if (type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG)) {
                            fName = fileName.concat("_").concat(currentDate
                                    .concat(name.substring(name.indexOf(".")).replace(".txt", ".xml")));
                        }
                        try {
                            FoldertoZipConverter foldertoZipConverter = new FoldertoZipConverter();
                            foldertoZipConverter.createZip(fName);

                            

                        } catch (SftpException ex) {
                            _logger.info("Exception while passing file name to FolderToZipConverter" + ex.getMessage());
                        }

                        
                    } catch (SAXException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException ex) {
                        //Logger.getLogger(MaterialTxtToXML.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

               
           // }

        }
          _logger.info("Total Material file processed " + proccFileCount);
        
    }

    public void populateAttributes(String type)
            throws ParserConfigurationException, TransformerConfigurationException, SAXException {

        new MaterialGeneratorTransformerHandler(th).generate(tableName, values, type);

    }

    public void closeXml() throws SAXException {
        th.endElement(null, null, "record_list");
         th.endDocument();
    }

    public TransformerHandler getOutFilename(File destinationFolder, String fileName, String type) {
        SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
        try {
            th = tf.newTransformerHandler();
        } catch (TransformerConfigurationException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }

        Transformer serializer = th.getTransformer();
        //serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        serializer.setOutputProperty(OutputKeys.INDENT, "yes");
        //serializer.put(OutputKeys.OMIT_XML_DECLARATION, "no");
        serializer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
        serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
         String name = fileName.substring(12, 20);
             name = name.substring(0,1).toUpperCase() + name.substring(1).toLowerCase();
//             System.out.println("File Name "+ name);
              //String fileName = name.substring(12, 20);
            // fileName = fileName.substring(0,1).toUpperCase() + fileName.substring(1).toLowerCase();
             
        try {
           
            if (type.equalsIgnoreCase(Constants.MATERIAL_LIST)) {
                out = new StreamResult(
                        new FileOutputStream(new File(destinationFolder, Constants.MATERIAL_LIST.concat("_").concat(currentDate)
                                .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml"))), true));
            } else if (type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG)) {
                out = new StreamResult(
                        new FileOutputStream(new File(destinationFolder, name.concat("_").concat(fileName.substring(21,25)).concat("_").concat(currentDate)
                                .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml"))), true));
            }

            //setting file permission
            File f = null;
            try {
                if (type.equalsIgnoreCase(Constants.MATERIAL_LIST)) {
                    f = new File(destinationFolder, Constants.MATERIAL_LIST.concat("_").concat(currentDate)
                            .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml")));
                } else if (type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG)) {
                    f = new File(destinationFolder, name.concat("_").concat(fileName.substring(21,25)).concat("_").concat(currentDate)
                            .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml")));
                }

                f.setExecutable(true, false);
                f.setReadable(true, false);
                f.setWritable(true, false);
            } catch (Exception e) {
                _logger.info("Exception while setting permission for o/p xml file " + e.getMessage());

            }
        } catch (FileNotFoundException e1) {
            _logger.info("Exception while writing o/p xml file to destination folder " + e1.getMessage());
        }

        th.setResult(out);
        return th;

    }

    public void startTag(File destinationFolder, String fileName, String type) {
        try {
            th = getOutFilename(destinationFolder, fileName, type);
            th.startDocument();
            th.startElement(null, null, "record_list", null);
            new MaterialGeneratorTransformerHandler(th).fixedAttributes(tableName, "START", type);
        } catch (SAXException e) {

            _logger.info("Exception in startTag method " + e);
        }
    }

    private String getFileName(String file) {
        int noOfFile = 0;
        String file1 = "";
        int first = -1, second = -1;
        first = file.indexOf('_');
        second = file.lastIndexOf('_');
        file1 = file.substring(first + 1, second);
        second = file1.lastIndexOf('_');
        file = file1.substring(0, second);
        return file;

    }

}
