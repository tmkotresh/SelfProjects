package com.honeywell.toppic.pricing.bestpractice;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.honeywell.toppic.pricing.ReadLineandGenerateMapping;

import com.honeywell.utils.Constants;

/**
 * @author Deekshith
 *
 * THIS CLASS WILL GENERATE BEST PRACTICE ITEM TAGS
 *
 */

public class GenerateItemNodesBestPractice {

    static String[] attributeValuesBestPracticePricing;

     /*
	 * THIS METHOD CREATES ZOEM_ITEM_BEST PRACTICE_PRICING ITEM TAGS
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    public static void createElementsZOEM(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable) {
        for (String s : temp) {
            attributeValuesBestPracticePricing = s.split("\t");
            if (!attributeValuesBestPracticePricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, "ZOEM_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesBestPracticePricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATAB") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATAB")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATBI") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATBI")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNNR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("MATNR") == null) ? "DUMMY" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("MATNR")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM") == null) ? "0" : ((attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM")].trim().isEmpty()) ? "0" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM")].trim().replaceAll("-", "")), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("VTWEG") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("VTWEG")].trim().replaceAll("-", ""), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SalesCat3, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZSLSGRP3") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZSLSGRP3")].trim().replaceAll("-", ""), "CDATA");
            }
        }
    }

     /*
	 * THIS METHOD CREATES COMMON BEST PRACTICE_PRICING ITEM TAGS
    @param:arraylist of attributes
    @param:XML Document
    @param:recordListNode Element(Tags will be added to this as child elements)
     */
    public static void createElementsCommon(ArrayList<String> temp, Document uploadXmlVariable, Element recoredListNodeVariable, String tableCode) {
        for (String s : temp) {
            attributeValuesBestPracticePricing = s.split("\t");
            if (!attributeValuesBestPracticePricing[0].equalsIgnoreCase("H")) {
                Element eachRecordNode = uploadXmlVariable.createElement("each_record");
                recoredListNodeVariable.appendChild(eachRecordNode);
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CATEGORY, "bm_script_data", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ACTION, "add", "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLE_NAME, tableCode + "_" + ReadLineandGenerateMapping.salesOrg, "text");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_TABLECODE, attributeValuesBestPracticePricing[1].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_FROMDATE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATAB") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATAB")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ENDDATE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATBI") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("DATBI")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CURRENCY, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONWA") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONWA")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_CUSTOMERNUMBER, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNNR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNNR")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICELISTTYPE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("PLTYP") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("PLTYP")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PARTNUMBER, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("MATNR") == null) ? "DUMMY" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("MATNR")].trim(), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SCALEQUANTITY, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM") == null) ? "0" : ((attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM")].trim().isEmpty()) ? "0" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KSTBM")].trim()), "CDATA");
                createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_DISTRCHANNEL, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("VTWEG") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("VTWEG")].trim(), "CDATA");

                switch (tableCode) {

                    case "ZX02":
                        
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                        break;
                    case "ZX04":
                        //  System.out.println("inside zx04 tags");
                        // System.out.println(ReadLineandGenerateMapping.mappingForPricingBestPractice);

                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDA") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDA")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                       
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_SalesCat3, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZSLSGRP3") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZSLSGRP3")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                        break;

                    case "ZX06":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                        
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ShipTo, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE")].trim().replaceAll("-", ""), "CDATA");
                        break;

                    case "ZX07":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICEGROUP, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDA") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDA")].trim().replaceAll("-", ""), "CDATA");
                      
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                        break;

                    case "ZX09":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProductGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                         
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ShipTo, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE")].trim().replaceAll("-", ""), "CDATA");
                        break;

                    case "ZX12":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_MaterialPricingGroup, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KONDM")].trim().replaceAll("-", ""), "CDATA");
                        
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_Discount, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        prodH2to5Node(uploadXmlVariable, eachRecordNode);
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ShipTo, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE")].trim().replaceAll("-", ""), "CDATA");
                        break;

                    case "ZXMO":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("(\\d+.\\d+|\\d+)-", "-$1"), "CDATA");
                        break;

                    case "ZXNP":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ShipTo, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KUNWE")].trim().replaceAll("-", ""), "CDATA");
                        break;

                    case "ZXPR":
                        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_PRICE, (ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR") == null) ? " " : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("KBETR")].trim().replaceAll("-", ""), "CDATA");
                        break;

                }

            }
        }
    }

    /*
    Method for processing prodh2to5node 
    @param:xmlDocument
    @param:EachecordNode
    */
    static void prodH2to5Node(Document uploadXmlVariable, Element eachRecordNode) {
        createXMLTags(uploadXmlVariable, eachRecordNode, Constants.PRICING_XML_TAG_ProdH2to5,
                ((ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH2") == null) ? "" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH2")].trim().replaceAll("-", ""))
                + "|"
                + ((ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH3") == null) ? "" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH3")].trim().replaceAll("-", ""))
                + "|"
                + ((ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH4") == null) ? "" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH4")].trim().replaceAll("-", ""))
                + "|"
                + ((ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH5") == null) ? "" : attributeValuesBestPracticePricing[ReadLineandGenerateMapping.mappingForPricingBestPractice.get("ZZPRODH5")].trim().replaceAll("-", "")),
                "");
    }

    /*
	 * THIS METHOD APPENDS CHILD TAGS TO THE PARENT TAGS
     */
    static void createXMLTags(Document XML, Element eachRecord, String tagName, String cdataContent, String type) {
        Element tags = XML.createElement(tagName);
        if (type.equalsIgnoreCase("text")) {
            tags.appendChild(XML.createTextNode(cdataContent));
        } else if (cdataContent.isEmpty()) {
            tags.appendChild(XML.createTextNode("\n"));
            tags.appendChild(XML.createTextNode(cdataContent));
            tags.appendChild(XML.createTextNode("\n"));
        } else {
            tags.appendChild(XML.createTextNode("\n"));
            tags.appendChild(XML.createCDATASection(cdataContent));
            tags.appendChild(XML.createTextNode("\n"));
        }
        eachRecord.appendChild(tags);
    }

}
