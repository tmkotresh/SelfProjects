/**
 * MaterialGeneratorTransformerHandler class converts .txt files related to Customer to .xml format
 * This class holds the logic to add attributes to xml file
 * SAX parser is used to convert .txt file to .xml 
 * 
 * 
 * @author kmatada
 */
package com.honeywell.toppic.material;

/**
 *
 * @author kmatada
 */
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.sax.TransformerHandler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;
import com.honeywell.utils.Constants;

/**
 *
 * @author kmatada
 */
public class MaterialGeneratorTransformerHandler {
    
 

    private final static Attributes EMPTY_ATTRS = new AttributesImpl();

    static {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }

    private TransformerHandler handler;

    public MaterialGeneratorTransformerHandler(TransformerHandler handler) {
        this.handler = handler;
    }

    /*
	 * To populate first and last record in the o/p xml file
     */
    public void fixedAttributes(String tableName, String position,String type) throws SAXException {

        handler.startElement("", Constants.EACH_RECORD, Constants.EACH_RECORD, EMPTY_ATTRS);

        addElement(Constants.CATEGORY, "bm_script_data");
        if (position.equalsIgnoreCase("START")) {
            addElement(Constants.ACTION, Constants.FIRST_ELE_ACTION);
            if(type.equalsIgnoreCase(Constants.MATERIAL_LIST)){
                addElement(Constants.TABLE_NAME, Constants.MATERIAL_LIST);
            }else if(type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG))
            addElement(Constants.TABLE_NAME, tableName);

        handler.endElement("", Constants.EACH_RECORD, Constants.EACH_RECORD);
        } else {
            addElement(Constants.ACTION, Constants.LAST_ELE_ACTION);
            if(type.equalsIgnoreCase(Constants.MATERIAL_LIST)){
                addElement(Constants.TABLE_NAME, Constants.MATERIAL_LIST);
            }else if(type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG))
            addElement(Constants.TABLE_NAME, tableName);

        handler.endElement("", Constants.EACH_RECORD, Constants.EACH_RECORD);
        //handler.endElement("", Constants.RECORD_LIST, Constants.RECORD_LIST);
        }
        
    }

    public void generate(String tableName, String[] values, String type) throws SAXException {
        // handler.startDocument();

        // for (int i = 0; i < lineCount; i++) {
        
       
        handler.startElement("", Constants.EACH_RECORD, Constants.EACH_RECORD, EMPTY_ATTRS);
        
        if(type.equalsIgnoreCase(Constants.MATERIAL_SALES_ORG)){
           addElement(Constants.CATEGORY, "bm_script_data");
        addElement(Constants.ACTION, Constants.ELE_ACTION_VALUE);
        addElement(Constants.TABLE_NAME, tableName);
        addElement(Constants.PART_NUMBER, values[0].trim());
        addElement(Constants.MIN_ORDER_QTY, values[34].trim());
        addElement(Constants.DELIVERY_QTY, values[32].trim());
        addElement(Constants.LEAD_TIME, values[52].trim());
        addElement(Constants.MATERIAL_PRICING_GROUP, values[36].trim());
        addElement(Constants.DISTR_CHANNEL, values[2].trim());
        addElement(Constants.BRAND, values[37].trim());
        addElement(Constants.LOB, values[5].substring(1, 3).trim());
        addElement(Constants.PRODUCT_HIERACRCHY, values[5].trim());
        addElement(Constants.PROD_H2TO5, values[5].substring(1, 14).trim());
        addElement(Constants.LBM, values[46].trim());
        addElement(Constants.UOM, values[6].trim()); 
        }else if(type.equalsIgnoreCase(Constants.MATERIAL_LIST)){
            addElement(Constants.CATEGORY, "bm_script_data");
        addElement(Constants.ACTION, Constants.ELE_ACTION_VALUE);
        addElement(Constants.TABLE_NAME, Constants.MATERIAL_LIST);
        addElement(Constants.PART_NUMBER, values[0].trim());
        addElement(Constants.LOB, values[5].substring(1, 3).trim());
        addElement(Constants.PRODUCT_HIERACRCHY, values[5].trim());
        addElement(Constants.PROD_H2TO5, values[5].substring(1, 14).trim());
        addElement(Constants.LBM, values[46].trim());
        addElement(Constants.UOM, values[6].trim()); 
        }

        

        handler.endElement("", Constants.EACH_RECORD, Constants.EACH_RECORD);

        // }
        // handler.endDocument();
    }

    private void addElement(String element, String name) throws SAXException {

        handler.startElement("", element, element, null);

        if ((element.equalsIgnoreCase(Constants.TABLE_NAME)) || (element.equalsIgnoreCase(Constants.PART_NUMBER))
                || (element.equalsIgnoreCase(Constants.MIN_ORDER_QTY))
                || (element.equalsIgnoreCase(Constants.DELIVERY_QTY)) || (element.equalsIgnoreCase(Constants.LEAD_TIME))
                || (element.equalsIgnoreCase(Constants.MATERIAL_PRICING_GROUP))
                || (element.equalsIgnoreCase(Constants.DISTR_CHANNEL)) || (element.equalsIgnoreCase(Constants.BRAND))
                || (element.equalsIgnoreCase(Constants.LOB)) || (element.equalsIgnoreCase(Constants.PRODUCT_HIERACRCHY))
                || (element.equalsIgnoreCase(Constants.PROD_H2TO5)) || (element.equalsIgnoreCase(Constants.LBM))
                || (element.equalsIgnoreCase(Constants.UOM))) {

            handler.startCDATA();
            if (name != null) {
                if (name.isEmpty()) {
                    name = " ";
                }

                handler.characters(name.toCharArray(), 0, name.length());
            } else {
                handler.characters("".toCharArray(), 0, 0);
            }

            handler.endCDATA();
        } else {
            handler.characters(name.toCharArray(), 0, name.length());
        }
        handler.endElement("", element, element);
    }

}
