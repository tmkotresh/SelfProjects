package com.honeywell.toppic.pricing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import com.honeywell.toppic.pricing.bestpractice.CreateBestPracticeXML;
import com.honeywell.toppic.pricing.legacypricing.CreatePricingLegacyXML;

import com.honeywell.utils.Constants;
import com.honeywell.utils.FileListGenerator;
import com.honeywell.utils.MoveProcessedFiles;

import com.jcraft.jsch.SftpException;
import java.text.ParseException;
import java.util.Map;
import org.apache.log4j.Logger;

/**
 * @author devadred
 * 
 *         THIS CLASS READS THE PRICING TEXT FILES INITIALIZES THE CONVERSION TO
 *         XML FILES BY CHECKING THE LOAD TYPES AND PRICING TYPES I.E LEGACY OR
 *         BEST PRACTICE
 *
 */
public class ReadLineandGenerateMapping {

    public static HashMap<String, Integer> mappingForPricingLegacy = new HashMap<String, Integer>();
    public static HashMap<String, Integer> mappingForPricingBestPractice = new HashMap<String, Integer>();
    public static String dateToAppend;
    public static ArrayList<File> loadFiles = new ArrayList<File>();
    public static ArrayList<File> legacyFullloadFiles = new ArrayList<File>();
    public static ArrayList<File> legacydeltaloadFiles = new ArrayList<File>();
    public static ArrayList<File> bestPracticeFullloadFiles = new ArrayList<File>();
    public static ArrayList<File> bestPracticeDeltaloadFiles = new ArrayList<File>();
    public static ArrayList<String> entries_zcsp;
    public static ArrayList<String> entries_zd00;
    public static ArrayList<String> entries_zd03;
    public static ArrayList<String> entries_zd04;
    public static ArrayList<String> entries_zd05;
    public static ArrayList<String> entries_zd06;
    public static ArrayList<String> entries_zd08;
    public static ArrayList<String> entries_zp00;
    public static HashMap<Integer, ArrayList<File>> filestoProcess = new HashMap<>();
    public static ArrayList<File> files = new ArrayList<>();
    public static ArrayList<File> filesListFromGenerator = new ArrayList<>();
    final Logger LOGGER = Logger.getLogger(ReadLineandGenerateMapping.class.getName());
    CreatePricingLegacyXML createPricingLegacyXML;
    CreateBestPracticeXML createBestPracticeXML;

    BufferedReader in;

    public ReadLineandGenerateMapping() {

    }

    String[] attributeValuesLegacy;
    String[] attributeValuesBestPractice;
    String filetoRead = null;
    HashMap<String, String> xmlCreatedCount = new HashMap<>();
    String[] table_Codes_legacy = {"ZCSP", "ZD00", "ZD03", "ZD04", "ZD05", "ZD06", "ZD08", "ZP00"};
    public static String salesOrg;
    ArrayList<File> filesToProcess = new ArrayList<>();
    File folder = new File("D:\\outputfiles");
    ArrayList<File> fullLoadFiles = new ArrayList<File>();
    ArrayList<File> deltaLoadFiles = new ArrayList<File>();

    
     /*
          This method checks the type of pricing files need to be processed for i.e legacy or best practice
          @Param:Sales Org
          @Param:List Of Files
          @Param:File load type(Mixed or full load or delta load)
          
          */
    
    public void checkPricingTypes(String salesOrg, ArrayList<File> loadFileTypes, String type, String runCount) throws FileNotFoundException, SftpException {
        this.salesOrg = salesOrg;
        if (Arrays.asList(Constants.legacyTypes).contains(this.salesOrg)) {
            processLegacyTypePricing(this.salesOrg, loadFileTypes, type, runCount);
        } else {
            processBestPracticeTypePricing(this.salesOrg, loadFileTypes, type, runCount);
        }
    }

    /*
        Method processes the files for legacy types
        @Param:Sales Org
        @Param:List of files for processing
        @Param:type of processing Full load or delta load
        
        */
    
    public void processLegacyTypePricing(String salesOrg, ArrayList<File> loadFileTypes, String type, String runCount) throws FileNotFoundException, SftpException {

        if (runCount.equalsIgnoreCase("first")) {
         //   LOGGER.info("Converting Legacy Pricing Data for SalesOrg " + salesOrg);
        }

        /*
		 * Delta Starts Here
         */
        if (type.equalsIgnoreCase("delta")) {

            createPricingLegacyXML.initializeLoadFilesDeltaMap();
           
            legacydeltaloadFiles = loadFileTypes;
          
            for (String tableCode : Constants.table_Codes_legacy) {
                createPricingLegacyXML.createNewXml(tableCode, "delta");
            }
            try {
                if (runCount.equalsIgnoreCase("first")) {
                  //  LOGGER.info("Processing files as delta pricing data");
                  //  LOGGER.info("processing files");
                }
                for (File f : legacydeltaloadFiles) {
                  
                    if (runCount.equalsIgnoreCase("first")) {
                     //   LOGGER.info("\t" + f.getName());
                    }
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesLegacy = str.split("\t");
                        if (attributeValuesLegacy[0].equalsIgnoreCase("H")) {
                            if (lineNumber != 2) {
                                createPricingLegacyXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingLegacy.clear();
                            for (int i = 0; i < attributeValuesLegacy.length; i++) {
                                mappingForPricingLegacy.put(attributeValuesLegacy[i], i);
                            }
                          
                        } else if (Arrays.asList(Constants.table_Codes_legacy).contains(attributeValuesLegacy[3])) {
                            createPricingLegacyXML.storeAttributes(attributeValuesLegacy[3], str, runCount);
                            createPricingLegacyXML.deltaLoadTablesStatus.put(attributeValuesLegacy[3], "Y");
                            
                        }
                    }
                    createPricingLegacyXML.storeAttributeArray(runCount);
                   
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            for (String code : Constants.table_Codes_legacy) {
                createPricingLegacyXML.createfooterTags(code, "DELTA");
            }
            createPricingLegacyXML.movaAllFilestoDisk(salesOrg, "delta", runCount);
        } /*
		 * Delta Ends Here
         */ /*
		 * Mixed Starts Here
         */ else if (type.equalsIgnoreCase("mixed")) {
            legacyFullloadFiles.clear();
            legacydeltaloadFiles.clear();
            // LOGGER.info("insied mixed legacy");
            for (File f : loadFileTypes) {
                if (f.getName().contains("_F.txt")) {
                    legacyFullloadFiles.add(f);
                } else {
                    legacydeltaloadFiles.add(f);
                }
            }
            for (String tableCode : Constants.table_Codes_legacy) {
                createPricingLegacyXML.createNewXml(tableCode, "mixed");
            }
            try {
                if (runCount.equalsIgnoreCase("first")) {
                  //  LOGGER.info("Processing files as full load pricing data");
                  //  LOGGER.info("processing files");
                }
                for (File f : legacyFullloadFiles) {
//                    LOGGER.info("processing the fileeeeeeeee " + f.getName());
                    if (runCount.equalsIgnoreCase("first")) {
                    //    LOGGER.info("\t" + f.getName());
                    }
               
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesLegacy = str.split("\t");
                        if (attributeValuesLegacy[0].equalsIgnoreCase("H")) {
                            if (lineNumber != 2) {
                                createPricingLegacyXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingLegacy.clear();
                            for (int i = 0; i < attributeValuesLegacy.length; i++) {
                                mappingForPricingLegacy.put(attributeValuesLegacy[i], i);
                            }
                           
                        } else if (Arrays.asList(Constants.table_Codes_legacy).contains(attributeValuesLegacy[3])) {
                            createPricingLegacyXML.storeAttributes(attributeValuesLegacy[3], str, runCount);
                        }

                        createPricingLegacyXML.storeAttributeArray(runCount);
                    }
                }
                createPricingLegacyXML.storeAttributeArray(runCount);
                for (File f : legacydeltaloadFiles) {
                   
                    if (runCount.equalsIgnoreCase("first")) {
                    //    LOGGER.info("\t" + f.getName());
                    }
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesLegacy = str.split("\t");
                        if (attributeValuesLegacy[0].equalsIgnoreCase("H")) {
                            
                            if (lineNumber != 2) {
                                createPricingLegacyXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingLegacy.clear();
                            for (int i = 0; i < attributeValuesLegacy.length; i++) {
                                mappingForPricingLegacy.put(attributeValuesLegacy[i], i);
                            }
                            
                        } else if (Arrays.asList(Constants.table_Codes_legacy).contains(attributeValuesLegacy[3])) {
                            createPricingLegacyXML.storeAttributes(attributeValuesLegacy[3], str, runCount);
                        }
                        createPricingLegacyXML.storeAttributeArray(runCount);
                    }
                    createPricingLegacyXML.storeAttributeArray(runCount);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            for (String code : Constants.table_Codes_legacy) {
                createPricingLegacyXML.createfooterTags(code, "mixed");
            }
            createPricingLegacyXML.movaAllFilestoDisk(salesOrg, "mixed", runCount);
        }
    }

     /*
        Method processes the files for Best Practice types
        @Param:Sales Org
        @Param:List of files for processing
        @Param:type of processing Full load or delta load
        
        */
    
    public void processBestPracticeTypePricing(String salesOrg, ArrayList<File> loadFileTypes, String type, String runCount) {
        if (runCount.equalsIgnoreCase("first")) {
         //   LOGGER.info("Converting Best Practice Pricing Data for SalesOrg " + salesOrg);
        }
        if (type.equalsIgnoreCase("delta")) {
            
            createBestPracticeXML.initializeBestPracticeLoadFilesDeltaMap();
           
            bestPracticeDeltaloadFiles = loadFileTypes;
          
            for (String tableCode : Constants.table_Codes_Bestpractice) {
                createBestPracticeXML.createNewXml(tableCode, "delta");
            }
            try {
                if (runCount.equalsIgnoreCase("first")) {
                //    LOGGER.info("Processing files as delta load pricing data");
                //    LOGGER.info("processing files");
                }
                for (File f : bestPracticeDeltaloadFiles) {
                  
                    if (runCount.equalsIgnoreCase("first")) {
                  //      LOGGER.info("\t" + f.getName());
                    }
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesBestPractice = str.split("\t");
                        if (attributeValuesBestPractice[0].equalsIgnoreCase("H")) {
                            if (lineNumber != 2) {
                                createBestPracticeXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingBestPractice.clear();
                            for (int i = 0; i < attributeValuesBestPractice.length; i++) {
                                mappingForPricingBestPractice.put(attributeValuesBestPractice[i], i);
                            }
                           
                        } else if (Arrays.asList(Constants.table_Codes_Bestpractice).contains(attributeValuesBestPractice[3])) {
                            createBestPracticeXML.storeAttributes(attributeValuesBestPractice[3], str, runCount);
                            createBestPracticeXML.deltaLoadBestPracticeTablesStatus.put(attributeValuesBestPractice[3], "Y");
                        }
                        createBestPracticeXML.storeAttributeArray(runCount);
                    }
                    createBestPracticeXML.storeAttributeArray(runCount);
                   
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            for (String code : Constants.table_Codes_Bestpractice) {
                createBestPracticeXML.createfooterTags(code);
            }
            createBestPracticeXML.movaAllFilestoDisk(salesOrg, "delta", runCount);
        } else if (type.equalsIgnoreCase("mixed")) {
           
            for (File f : loadFileTypes) {
                if (f.getName().contains("_F.txt")) {
                    bestPracticeFullloadFiles.add(f);
                } else {
                    bestPracticeDeltaloadFiles.add(f);
                }
            }
            for (String tableCode : Constants.table_Codes_Bestpractice) {
                createBestPracticeXML.createNewXml(tableCode, "mixed");
            }
            if (runCount.equalsIgnoreCase("first")) {
              //  LOGGER.info("Processing files as full load pricing data");
              //  LOGGER.info("processing files");
            }
            try {
                for (File f : bestPracticeFullloadFiles) {
                    if (runCount.equalsIgnoreCase("first")) {
                 //       LOGGER.info("\t" + f.getName());
                    }
                    
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesBestPractice = str.split("\t");
                        if (attributeValuesBestPractice[0].equalsIgnoreCase("H")) {
                            if (lineNumber != 2) {
                                createBestPracticeXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingBestPractice.clear();
                            for (int i = 0; i < attributeValuesBestPractice.length; i++) {
                                mappingForPricingBestPractice.put(attributeValuesBestPractice[i], i);
                            }
                           
                        } else if (Arrays.asList(Constants.table_Codes_Bestpractice).contains(attributeValuesBestPractice[3])) {
                            createBestPracticeXML.storeAttributes(attributeValuesBestPractice[3], str, runCount);
                        }
                        createBestPracticeXML.storeAttributeArray(runCount);
                    }
                }
                createBestPracticeXML.storeAttributeArray(runCount);
                for (File f : bestPracticeDeltaloadFiles) {
                    if (runCount.equalsIgnoreCase("first")) {
                //        LOGGER.info("\t" + f.getName());
                    }
                  
                    int lineNumber = 0;
                    in = new BufferedReader(new FileReader(f.getAbsolutePath()));
                    in.readLine();
                    lineNumber++;
                    String str;
                    while ((str = in.readLine()) != null) {
                        lineNumber++;
                        attributeValuesBestPractice = str.split("\t");
                        if (attributeValuesBestPractice[0].equalsIgnoreCase("H")) {
                          
                            if (lineNumber != 2) {
                                createBestPracticeXML.storeAttributeArray(runCount);
                            }
                            mappingForPricingBestPractice.clear();
                            for (int i = 0; i < attributeValuesBestPractice.length; i++) {
                                mappingForPricingBestPractice.put(attributeValuesBestPractice[i], i);
                            }
                           
                        } else if (Arrays.asList(Constants.table_Codes_Bestpractice).contains(attributeValuesBestPractice[3])) {
                            createBestPracticeXML.storeAttributes(attributeValuesBestPractice[3], str, runCount);
                        }
                        createBestPracticeXML.storeAttributeArray(runCount);
                    }
                    createBestPracticeXML.storeAttributeArray(runCount);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            for (String code : Constants.table_Codes_Bestpractice) {
                createBestPracticeXML.createfooterTags(code);
            }
            createBestPracticeXML.movaAllFilestoDisk(salesOrg, "mixed", runCount);
        }
    }

    public static void main(String[] args) throws FileNotFoundException, SftpException, ParseException {
      
    new ReadLineandGenerateMapping().initializeProcessingPricingFiles("584E");
    }

    /*
    Method is entry point of execution 
    @param:Sales org to process
    
    */
    public void initializeProcessingPricingFiles(String salesOrg) throws FileNotFoundException, SftpException, ParseException {
        Date date = new Date();
        String sysDate = new SimpleDateFormat("YYYYMMdd").format(date);
        dateToAppend = sysDate;
        filestoProcess = new FileListGenerator().fetchFilesToProcess(salesOrg, "Pricing");
        if (filestoProcess == null) {
            LOGGER.info("*** No (Pricing) files present for SalesOrg " + salesOrg);

            return;
        }
        
        for (Map.Entry<Integer, ArrayList<File>> entry : filestoProcess.entrySet()) {
            
            filesListFromGenerator.addAll(entry.getValue());
        }

        ReadLineandGenerateMapping readLineandGenerateMapping = new ReadLineandGenerateMapping();
        readLineandGenerateMapping.createPricingLegacyXML = new CreatePricingLegacyXML();
        readLineandGenerateMapping.createBestPracticeXML = new CreateBestPracticeXML();

        if (filesListFromGenerator != null) {
            
             LOGGER.info("Processing Files");
             
            for(File f :filesListFromGenerator)
            {
               
                LOGGER.info(f.getName());
            }
            readLineandGenerateMapping.checkLoadingTypes(salesOrg, "first");
            readLineandGenerateMapping.checkLoadingTypes(salesOrg, "second");
            readLineandGenerateMapping.checkLoadingTypes(salesOrg, "third");
            readLineandGenerateMapping.checkLoadingTypes(salesOrg, "fourth");
        }

        try {

            new MoveProcessedFiles().moveFiles(filesListFromGenerator, salesOrg);
            files.clear();
            filesListFromGenerator.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    /*
    Method loads files in to respective arrayLists based on full load or delta loads
    @param: Salesorg for processing
    */
    public void checkLoadingTypes(String salesOrg, String runCount) throws FileNotFoundException, SftpException {
        loadFiles.clear();
        legacyFullloadFiles.clear();
        deltaLoadFiles.clear();
        bestPracticeFullloadFiles.clear();
        bestPracticeDeltaloadFiles.clear();

        for (File f : filesListFromGenerator) {
            if (f.getName().contains("_F.txt")) {
                fullLoadFiles.add(f);
            } else {
                deltaLoadFiles.add(f);
            }
        }
        if (deltaLoadFiles.size() == 0 && fullLoadFiles.size() > 0 || deltaLoadFiles.size() > 0 && fullLoadFiles.size() > 0) {
            checkPricingTypes(salesOrg, filesListFromGenerator, "mixed", runCount);
        } else {
            checkPricingTypes(salesOrg, deltaLoadFiles, "delta", runCount);

        }

    }
}
