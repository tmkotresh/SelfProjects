/**
 * CustomerTxtToXML class converts .txt files related to Customer to .xml format
 * SAX parser is used to convert .txt file to .xml
 *
 * @author kmatada
 */
package com.honeywell.toppic.customer;

import com.honeywell.toppic.TxtToXMLCommon;

import com.honeywell.utils.Constants;
import com.honeywell.utils.FileListGenerator;
import com.honeywell.utils.FoldertoZipConverter;
import com.honeywell.utils.MoveProcessedFiles;
import com.jcraft.jsch.SftpException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stream.StreamResult;

//import org.apache.commons.lang3.StringUtils;
import org.xml.sax.SAXException;

//import com.oracle.hwwebmethods.material.Constants;
public class CustomerTxtToXML {

    BufferedReader in;
    StreamResult out;
    TransformerHandler th;

    String[] values = null;
    String tableName = null;
    int lineCount = 0;
    int noOfFile = 0;
    String file, file1 = "";
    int first = -1, second = -1;
    public static HashMap<Integer, ArrayList<File>> filestoProcess = new HashMap<>();
    File destinationFolder = new File(Constants.JCS_OUTPUT_FOLDER);

    private static final Logger _logger = Logger.getLogger(CustomerTxtToXML.class.getName());

    public CustomerTxtToXML() {

    }

    public static void main(String[] args) {
try {
            new CustomerTxtToXML().generateXML("2538");
        } catch (ParseException ex) {
            //java.util.logging.Logger.getLogger(MaterialTxtToXML.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    String currentDate = new TxtToXMLCommon().getCurrentDate();
    Map<String, Integer> mapFile = new HashMap<String, Integer>();
    Map<String, Integer> mapAccess = new HashMap<String, Integer>();

    public void generateXML(String salesOrg) throws ParseException {
       

//        Calendar cal = Calendar.getInstance();
//        _logger.info("Start Customer Data Transfer at   " + cal.getTime());
        filestoProcess = new FileListGenerator().fetchFilesToProcess(salesOrg, "Customer");

        if (filestoProcess == null) {
            _logger.info("*** No (Customer) files present for SalesOrg " + salesOrg);

            return;
        }

        //File folder = new File(Constants.JCS_INPUT_FOLDER);
        File[] files = null;
        ArrayList<File> filesList = new ArrayList<>();
        for (Map.Entry<Integer, ArrayList<File>> entry : filestoProcess.entrySet()) {
            
            filesList.addAll(entry.getValue());
        }

        files = filesList.toArray(new File[filesList.size()]);
        if (files.length == 0) {
            // _logger.info("***No files present to process*** for sales org " + salesOrg);
            return;
        }

        //Check if files belong to same sales org
        checkIfFilesBelongToSameSalesOrg(files);

        //processing files
         _logger.info("Converting Customer Data for SalesOrg "+salesOrg);
        processFiles(files);

        // _logger.info("Converting Customer Data for Sales org " + fileName.substring(20, 24));
        //BIGMACHINE_Customer_2092_10_20170330-162826-113.txt
        //Customer_2092_10_20170330
        //logic to count no of file with same Org(Customer_2092,2092,2093,2093,2092) like Customer_2092 have 2 file so output of 2092 merge in one file 
        try {

            new MoveProcessedFiles().moveFiles(filesList, salesOrg);
        } catch (Exception e) {
            _logger.info("Exception while moving processed customer files " + e);
        }

        _logger.info("**************************************************");

    }

    public void checkIfFilesBelongToSameSalesOrg(File[] files) {
        for (int j = 0; j < files.length; j++) {

            file = files[j].getName().trim();

            file = getFileName(file);
            if (mapFile.containsKey(file)) {
                noOfFile = mapFile.get(file);
                mapFile.put(file, ++noOfFile);

            } else {
                mapFile.put(file, 1);

            }

        }
    }

    public void processFiles(File[] files) {
        int proccFileCount = 0;
       
        _logger.info("Processing files");
        for (int i = 0; i < files.length; i++) {

            tableName = files[i].getName().substring(11, 24);
            //if(StringUtils.containsIgnoreCase(tableName,"Customer")){

            _logger.info("" + files[i].getName());

            
            file = files[i].getName().trim();

            proccFileCount++;
            file = getFileName(file);
            if (mapAccess.get(file) == null) {
                //logic to  checking which file is started to processing if "Customer_2092" file is 3 time in this case only get StreamResult only 1 time

                startTag(destinationFolder, files[i].getName());
                noOfFile = mapFile.get(file);
                mapFile.put(file, --noOfFile);
                mapAccess.put(file, 1);
            } else {
                //if Customer_2092 1 time processed so next time not oppening StreamResult
                noOfFile = mapFile.get(file);
                mapFile.put(file, --noOfFile);
            }
            try {

                

                in = new BufferedReader(new FileReader(files[i]));

                // TO POPULATE FIRST RECORD
                //getOutFilename(destinationFolder, files[i].getName());
                //startTag(destinationFolder,files[i].getName());
                String str;

                //_logger.info("\t" + files[k]);
                // TO SKIP FIRST ROW
                in.readLine();

                while ((str = in.readLine()) != null) {

                    values = str.split("\t");
                    populateAttributes();
                    lineCount++;

                }
                //}

            } catch (Exception e) {
                _logger.info("Error occured while processing file " + files[i].getName());
                _logger.info("Stack trace " + e);

            }
            //if all file are processed with same org like Org(Customer_2092,2092,2093,2093,2092) then call fixed attribute
            file = files[i].getName().trim();
            first = file.indexOf('_');
            second = file.lastIndexOf('_');
            file1 = file.substring(first + 1, second);
            second = file1.lastIndexOf('_');
            file = file1.substring(0, second);
            noOfFile = mapFile.get(file);
            if (noOfFile == 0) {
                //checking 
                // TO POPULATE LAST RECORD
                try {
                    new CustomerGeneratorTransformerHandler(th).fixedAttributes(tableName, "END");
                    th.endDocument();
                    in.close();
                    closeXml();

                    //Passing generated file name to file zip creation
                    String name = files[i].getName();
                    String fName = name.substring(11, 24).concat("_").concat(currentDate.concat(name.substring(name.indexOf(".")).replace(".txt", ".xml")));

                    FoldertoZipConverter foldertoZipConverter = new FoldertoZipConverter();
                    try {
                        foldertoZipConverter.createZip(fName);
                    } catch (SftpException ex) {
                        _logger.info(" Sending file name to folder to zip converter  " + ex);
                    } catch (FileNotFoundException ex) {
                        _logger.info(" Sending file name to folder to zip converter " + ex);
                    }

                    
                } catch (SAXException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            //}
        }
        _logger.info("Total customer file processed " + proccFileCount);

    }

    public void populateAttributes()
            throws ParserConfigurationException, TransformerConfigurationException, SAXException {

        new CustomerGeneratorTransformerHandler(th).generate(tableName, values, lineCount);

    }

    public void closeXml() throws SAXException {
       
        th.endElement(null, null, "record_list");
        th.endDocument();

    }

   

    public TransformerHandler getOutFilename(File destinationFolder, String fileName) {
        SAXTransformerFactory tf = (SAXTransformerFactory) SAXTransformerFactory.newInstance();
        try {
            th = tf.newTransformerHandler();
        } catch (TransformerConfigurationException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }

        Transformer serializer = th.getTransformer();
        //serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        serializer.setOutputProperty(OutputKeys.INDENT, "yes");
        serializer.setOutputProperty(OutputKeys.CDATA_SECTION_ELEMENTS, " YES");
        serializer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
        

        try {

            out = new StreamResult(
                    new FileOutputStream(new File(destinationFolder, fileName.substring(11, 24).concat("_").concat(currentDate)
                            .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml"))), true));
            

            try {
                File f = new File(destinationFolder, fileName.substring(11, 24).concat("_").concat(currentDate)
                        .concat(fileName.substring(fileName.indexOf(".")).replace(".txt", ".xml")));
                f.setExecutable(true, false);
                f.setReadable(true, false);
                f.setWritable(true, false);
            } catch (Exception e) {
                _logger.info("Exception while setting permission for o/p xml file " + e.getMessage());

            }
        } catch (FileNotFoundException e1) {
            _logger.info("Exception while writing file to destination folder  " + e1.getMessage());
        }

        th.setResult(out);

        return th;

    }

    public void startTag(File destinationFolder, String fileName) {
        try {
            th = getOutFilename(destinationFolder, fileName);
            th.startDocument();
            th.startElement(null, null, "record_list", null);
            new CustomerGeneratorTransformerHandler(th).fixedAttributes(tableName, "START");
        } catch (SAXException e1) {

            e1.printStackTrace();
        }
    }

    /**
     *
     * This method take input as "Customer_2092_20160419" and returning
     * "Customer_2092"
     *
     * @param files
     * @return
     */
    private String getFileName(String files) {
        int noOfFile = 0;
        String file, file1 = "";
        int first = -1, second = -1;
        file = files.trim();
        first = file.indexOf('_');
        second = file.lastIndexOf('_');
        file1 = file.substring(first + 1, second);
        second = file1.lastIndexOf('_');
        file = file1.substring(0, second);
        return file;

    }
}
