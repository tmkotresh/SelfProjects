/**
 * CustomerGeneratorTransformerHandler class converts .txt files related to Customer to .xml format
 * This class holds the logic to add attributes to xml file
 * SAX parser is used to convert .txt file to .xml 
 * 
 * 
 * @author kmatada
 */
package com.honeywell.toppic.customer;


import com.honeywell.utils.Constants;
import javax.xml.transform.sax.TransformerHandler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

public class CustomerGeneratorTransformerHandler {

    private final static Attributes EMPTY_ATTRS = new AttributesImpl();

    private TransformerHandler handler;

    public CustomerGeneratorTransformerHandler(TransformerHandler handler) {
        this.handler = handler;
    }

    /*
	 * To populate first and last record in the o/p xml file
     */
    public void fixedAttributes(String tableName, String position) throws SAXException {

        handler.startElement("", Constants.EACH_RECORD, Constants.EACH_RECORD, EMPTY_ATTRS);

        addElement(Constants.CATEGORY, "bm_script_data");
        if (position.equalsIgnoreCase("START")) {
            addElement(Constants.ACTION, Constants.FIRST_ELE_ACTION);
            addElement(Constants.TABLE_NAME, tableName);

        } else {
            addElement(Constants.ACTION, Constants.LAST_ELE_ACTION);
            addElement(Constants.TABLE_NAME, tableName);

        }
        handler.endElement("", Constants.EACH_RECORD, Constants.EACH_RECORD);
    }

    public void generate(String tableName, String[] values, int lineCount) throws SAXException {
        // handler.startDocument();

        
        handler.startElement("", Constants.EACH_RECORD, Constants.EACH_RECORD, EMPTY_ATTRS);
        addElement(Constants.CATEGORY, "bm_script_data");
        addElement(Constants.ACTION, Constants.ELE_ACTION_VALUE);
        addElement(Constants.TABLE_NAME, tableName);
        addElement(Constants.CUSTOMER_NUMBER, values[0]);
        addElement(Constants.DISTR_CHANNEL, values[2]);
        addElement(Constants.RINGNAME, values[5]);
        addElement(Constants.RINGTYPE, values[6]);
        addElement(Constants.CUSTOMER_GROUP, values[64]);
        addElement(Constants.PRICELIST_TYPE, values[47]);
        addElement(Constants.PRICE_GROUP, values[45]);
        addElement(Constants.SALES_OFFICE, values[40]);

        /*addElement(Constants.SALES_ORG, values[1]);
		addElement(Constants.INCOTERMS, values[55]);
		addElement(Constants.INCOTERMS2, values[56]);
		addElement(Constants.PAYMENT_TERMS, values[57]);*/
        addElement(Constants.CURRENCY, values[44]);

        handler.endElement("", Constants.EACH_RECORD, Constants.EACH_RECORD);

        // }
        // handler.endDocument();
    }

    //
    private void addElement(String element, String name) throws SAXException {

        handler.startElement("", element, element, null);

        if ((element.equalsIgnoreCase(Constants.TABLE_NAME)) || (element.equalsIgnoreCase(Constants.CUSTOMER_NUMBER))
                || (element.equalsIgnoreCase(Constants.DISTR_CHANNEL))
                || (element.equalsIgnoreCase(Constants.RINGNAME))
                || (element.equalsIgnoreCase(Constants.CUSTOMER_GROUP))
                || (element.equalsIgnoreCase(Constants.PRICELIST_TYPE))
                || (element.equalsIgnoreCase(Constants.PRICE_GROUP))
                || (element.equalsIgnoreCase(Constants.SALES_OFFICE))
                || (element.equalsIgnoreCase(Constants.CURRENCY))
                || (element.equalsIgnoreCase(Constants.RINGTYPE))
                || (element.equalsIgnoreCase(Constants.RINGNAME))
                || (element.equalsIgnoreCase(Constants.CUSTOMER_GROUP))
                || (element.equalsIgnoreCase(Constants.PRICELIST_TYPE))) {

            handler.startCDATA();
            if (name != null) {
                if (name.isEmpty()) {
                    name = " ";
                    try {
                        handler.ignorableWhitespace(name.toCharArray(), 0, name.length());
                    } catch (NullPointerException e) {
                        System.out.println(e);
                    }
                } else {
                    handler.characters(name.toCharArray(), 0, name.length());
                }

            } else {
                handler.characters("".toCharArray(), 0, 0);
            }

            handler.endCDATA();
        } else {
            handler.characters(name.toCharArray(), 0, name.length());
        }
        handler.endElement("", element, element);
    }

}
