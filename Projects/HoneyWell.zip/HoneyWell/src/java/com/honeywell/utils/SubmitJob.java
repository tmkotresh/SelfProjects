/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import com.honeywell.scheduler.jobs.GAEBReportJob;
import com.honeywell.scheduler.jobs.SFTPJob;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.ScheduleBuilder;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

/**
 *
 * @author kmatada
 */
public class SubmitJob extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ButtonClick</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ButtonClick at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            if (request.getParameter("onDemand") != null) {
                
               
                  
                Calendar calendar = Calendar.getInstance(); 
                String expression = request.getParameter("expression");
                   System.out.println("Entered expression value onDemand is " + expression);
                Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(expression);
                calendar.setTime(date);
                calendar.add(Calendar.HOUR, -2);
                String dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
                Date dateToPass = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dt);
                 String cronExpression =  generateCronExpression(dateToPass);
                 System.out.println("cron expression is "+cronExpression);
                SchedulerFactory schfa = new StdSchedulerFactory();
                Scheduler sch = schfa.getScheduler();
                // sch.deleteJob(SFTPJob);
                JobDetail jobdetail = JobBuilder.newJob(SFTPJob.class).withIdentity("SFTPJob", sch.DEFAULT_GROUP).build();

                //JobDetail jobdetail = 
                CronTrigger crontrigger = (CronTrigger) TriggerBuilder.newTrigger().withIdentity("cron-trigger", sch.DEFAULT_GROUP).withSchedule(createSchedule(cronExpression)).build();
                sch.scheduleJob(jobdetail, crontrigger);
                //response.sendRedirect("/success.jsp");

                //RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
                //rd.forward(request, response);
            }

            if (request.getParameter("runNow") != null) {
                System.out.println("inside runNow");
                Calendar calendar = Calendar.getInstance(); // gets a calendar using the default time zone and locale.
              //  calendar.add(Calendar.s, -2);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dt = dateFormat.format(calendar.getTime());
                 Date dateToPass = dateFormat.parse(dt);
               String cronExpression =  generateCronExpression(dateToPass);
                System.out.println("expression from run now is "+cronExpression);
                
                 SchedulerFactory schfa = new StdSchedulerFactory();
                Scheduler sch = schfa.getScheduler();
                // sch.deleteJob(SFTPJob);
             
                JobDetail jobdetail = JobBuilder.newJob(SFTPJob.class).withIdentity("SFTPJob", sch.DEFAULT_GROUP).build();
                  // JobKey key = jobdetail.getKey(); 
                   
            //sch.deleteJob(key);
            
                //JobDetail jobdetail = 
                CronTrigger crontrigger = (CronTrigger) TriggerBuilder.newTrigger().withIdentity("cron-trigger", sch.DEFAULT_GROUP).withSchedule(createSchedule(cronExpression)).build();
                sch.scheduleJob(jobdetail, crontrigger);
                //response.sendRedirect("/success.jsp");
                 
                 //HttpSession sess = request.getSession(true);
                 //sess.setAttribute("status", "Job Started..& it is Inprogress");
                 request.setAttribute("status", "Job Started..& it is in Inprogress status");
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);

                
                
            }

        } catch (SchedulerException ex) {
            Logger.getLogger(SubmitJob.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(SubmitJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static ScheduleBuilder createSchedule(String cronExpression) {
        CronScheduleBuilder builder = CronScheduleBuilder.cronSchedule(cronExpression);
        return builder;
    }
    
   

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    public String generateCronExpression(Date date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dt = dateFormat.format(date);

        Date cronDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dt);

        CronUtil calHelper = new CronUtil(cronDate);
        String cron = calHelper.getSeconds() + " "
                + calHelper.getMins() + " "
                + calHelper.getHours() + " "
                + calHelper.getDaysOfMonth() + " "
                + calHelper.getMonths() + " "
                + calHelper.getDaysOfWeek() + " "
                + calHelper.getYears();
        System.out.println("cron expression is " + cron);
        return cron.toString();
    }

}
