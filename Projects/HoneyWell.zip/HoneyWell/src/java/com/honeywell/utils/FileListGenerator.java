package com.honeywell.utils;

import com.honeywell.scheduler.jobs.SFTPJob;
import java.io.File;
import static java.lang.String.format;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.log4j.Logger;

/*
Author : Deekshith

This class will implement the back logic which is used for going to the previous datre when full DC's are not available

for a particular date for a particular class.

This class will be invoked seperately by each module(pricing,material and customer) for getting the required files to process.

 */
public class FileListGenerator {

    private final Logger _logger = Logger.getLogger(FileListGenerator.class.getName());
    public HashMap<Integer, ArrayList<File>> fullDC;
    public String salesOrg = null;
    public int dc;
    public int filesCountRequired;
    public String sysDate = null;
    public String moduleForChecking = null;
    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    public HashMap<Integer, ArrayList<File>> deltaFiles;
    Date d1 = null;
    Date d2 = null;
    boolean checkProcessedFolder;
    boolean delatFilesPresent;

    public static void main(String[] args) throws ParseException {

        HashMap<Integer, ArrayList<File>> temp = new HashMap<Integer, ArrayList<File>>();
        HashMap<Integer, ArrayList<File>> temp2 = new HashMap<Integer, ArrayList<File>>();
        temp = new FileListGenerator().fetchFilesToProcess("2538", "Pricing");

        System.out.println(temp);
       

    }

    /*
        entry point to the program
        @param: salesOrg 
        @param: module which is calling this utility
        This method will initially check for the files in the input folder if it does not find the files in the input folder
        it processeds to check the processed folders and fetch the files
     */
    public HashMap<Integer, ArrayList<File>> fetchFilesToProcess(String salesOrgForProcessing, String module) throws ParseException {
        fullDC = new HashMap<Integer, ArrayList<File>>();
        Date date = new Date();
        moduleForChecking = module;
        boolean founDeltaFiles = false;
        sysDate = new SimpleDateFormat("YYYYMMdd").format(date);

        // _logger.info("sys date is "+sysDate);
        salesOrg = salesOrgForProcessing;
        DatabaseUtility databaseUtility = new DatabaseUtility();
        HashMap<Integer, Integer> receivedValues = new HashMap<Integer, Integer>();
        switch (module) {
            case "Pricing":

             receivedValues = databaseUtility.fetchPricingData(salesOrgForProcessing);
          //  receivedValues.put(11, 1);
                break;
            case "MATERIAL":
               receivedValues = databaseUtility.fetchMaterialData(salesOrgForProcessing);
              
              
                break;
            case "Customer":
                receivedValues = databaseUtility.fetchCustomerData(salesOrgForProcessing);
              
          
                break;
        }
        
          checkFullLoadDC(salesOrg,receivedValues,module);
          
          for(Entry<Integer, ArrayList<File>> entry :fullDC.entrySet())
          {
              if(!entry.getValue().isEmpty())
                      {
                          checkProcessedFolder  =true;
                      }
          }
          if(checkProcessedFolder)
          {
              initializeCheckingProcessedFolder(receivedValues);
          }
         
         
         if(module.equalsIgnoreCase("Pricing"))
         {
             checkForDeltaLoadFiles(salesOrg,receivedValues);
        
        for(Entry<Integer, ArrayList<File>> entry : deltaFiles.entrySet())
        {
            fullDC.get(entry.getKey()).addAll(entry.getValue());
        }
        }



     for(Entry<Integer, ArrayList<File>> entry:fullDC.entrySet())
                {
                    if(entry.getValue().isEmpty())
                    {
                        if(delatFilesPresent)
                        {
                            fullDC  = deltaFiles;
                        }
                        
                    }
                }
     
        System.out.println(module + fullDC);
        return fullDC;

    }

    /*
        This method will initialize the checking of the processing folder if the required files are not obtained from the input folder
        @param:HashMap which contains the info for which DC has to contain how many files
     */
    public void initializeCheckingProcessedFolder(HashMap<Integer, Integer> receivedValues) throws ParseException {
         
        String processingDate = String.valueOf(Integer.parseInt(sysDate) - 1);
        d1 = format.parse(sysDate);
        d2 = format.parse(processingDate);
        
         Calendar cal = Calendar.getInstance();
         Calendar cal2 = Calendar.getInstance();
         cal.add(Calendar.DATE, -1);
        cal2.add(Calendar.DATE, -46);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
        while (cal.getTime().after(cal2.getTime())) {
          //  System.out.println("while loop cal get time "+sdf.format(cal.getTime()));
            for (Entry<Integer, ArrayList<File>> entry : fullDC.entrySet()) {

                if (entry.getValue().isEmpty()) {
                    /*
					 * Check for processed folder
					 * */
                    dc = entry.getKey();
                    filesCountRequired = receivedValues.get(entry.getKey());

                    fullDC.put(entry.getKey(), dcCheckProcessedFolder(sdf.format(cal.getTime()),dc));
                }
            }
            for (Entry<Integer, ArrayList<File>> entry : fullDC.entrySet()) {
                if (entry.getValue().isEmpty()) {
                    
                        entry.setValue(new ArrayList<File>());
                   

                }
            }
            boolean emptyDC = false;
              for (Entry<Integer, ArrayList<File>> entry : fullDC.entrySet()) {
                   if (entry.getValue().isEmpty()) {
                        emptyDC = true;
                   }
                  
              }
              if(!emptyDC)
              {
                   break;
              }
              else
              {
               cal.add(Calendar.DATE, -1);  
              }
//            if (!(fullDC.entrySet().iterator().next().getValue()).isEmpty()) {
//                break;
//            }
          
            
        }
       
    }



    /*
        This method will check the processed files in the required files are not availble in the input folder
        @param:HashMap which contains the info for which DC has to contain how many files
        
     */
    public ArrayList<File> dcCheckProcessedFolder(String processingDate,int dc) throws ParseException {

        boolean fileFound = false;
        ArrayList<File> fileFoundInProcessedFolder = new ArrayList<File>();
       // System.out.println("processingDate "+processingDate);
        
        while (fileFound == false) {
            File folder = new File(Constants.JCS_PROCESSED_FILES + processingDate.replaceAll("-", ""));

            int fileCount = 0;
            if (folder.exists()) {
                
                        for (File f : folder.listFiles()) {
                            if ((!f.getName().contains("_C.txt")) && f.getName().contains(moduleForChecking) && f.getName().contains("_" + String.valueOf(dc) + "_") && f.getName().contains(processingDate.replaceAll("-", "")) && f.getName().contains(salesOrg)) {
                                fileFoundInProcessedFolder.add(f);
                                fileCount++;
                      
                    }

                   
                }

            }
            
             if (fileCount == filesCountRequired) {
                        fileFound = true;
                        return fileFoundInProcessedFolder;
                    } else {
                        fileFoundInProcessedFolder.clear();

                    }
             
            break;

        }
        return fileFoundInProcessedFolder;
    }


    /*
        This method checks for the files on the current date and returns wether files are available for the processing date or not
        @param:HashMap which contains the info for which DC has to contain how many files
        @param:Module for pricing
        @param:salesOrg
        
     */
    public boolean checkFullLoadDC(String salesOrg, HashMap<Integer, Integer> distributionChannelsFileRequired, String module) {
     
        Integer distributionChannel;
        int fileCount;
        File folder = new File(Constants.JCS_INPUT_FOLDER);

        HashMap<Integer, Integer> distributionChannelsFileobtained = new HashMap<Integer, Integer>();

        boolean condition = false;

          Calendar cal = Calendar.getInstance();
         Calendar cal2 = Calendar.getInstance();
         cal.add(Calendar.DATE, -1);
        cal2.add(Calendar.DATE, -3);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
        Date date = new Date();
        
        for (cal.getTime();cal.getTime().after(cal2.getTime());cal.add(Calendar.DATE, -1)) {
          
               for (Entry<Integer, Integer> entry : distributionChannelsFileRequired.entrySet()) {

            distributionChannel = entry.getKey();
            fileCount = entry.getValue();
 date = cal.getTime();
            int countToday = 1;

          
            for (File f : folder.listFiles()) {
                if (module.equalsIgnoreCase("pricing")) {
                    condition = (f.getName().contains(sdf.format(date).replaceAll("-", "")) && f.getName().contains(salesOrg) && f.getName().contains(moduleForChecking) && f.getName().contains("_" + distributionChannel + "_") && f.getName().contains("_F"));
                } else {
                    condition = (f.getName().contains(sdf.format(date).replaceAll("-", "")) && f.getName().contains(salesOrg) && f.getName().contains(moduleForChecking) && f.getName().contains("_" + distributionChannel + "_"));
                }

                if (condition) {

                    distributionChannelsFileobtained.put(distributionChannel, countToday);
                    countToday++;
                }

            }

        }

        for (Entry<Integer, Integer> entry : distributionChannelsFileRequired.entrySet()) {

            distributionChannel = entry.getKey();
            fileCount = entry.getValue();

            if (distributionChannelsFileobtained.containsKey(distributionChannel) && distributionChannelsFileobtained.get(distributionChannel) == fileCount) {
                ArrayList<File> filesToProcess = new ArrayList<File>();

                for (File f : folder.listFiles()) {
                    if (module.equalsIgnoreCase("pricing")) {
                        condition = (f.getName().contains(sdf.format(date).replaceAll("-", "")) && f.getName().contains(salesOrg) && f.getName().contains(moduleForChecking) && f.getName().contains("_" + distributionChannel + "_") && f.getName().contains("_F"));
                    } else {
                        condition = (f.getName().contains(sdf.format(date).replaceAll("-", "")) && f.getName().contains(salesOrg) && f.getName().contains(moduleForChecking) && f.getName().contains("_" + distributionChannel + "_"));
                    }
                    if (condition) {
                        filesToProcess.add(f);
                        //	 // _logger.info("filesToProcess "+filesToProcess);

                    }

                }
                if(fullDC.isEmpty()||fullDC.get(distributionChannel)==null)
                {
                     fullDC.put(distributionChannel, filesToProcess);
                }
                else if(fullDC.get(distributionChannel).isEmpty())
                {
                    fullDC.put(distributionChannel, filesToProcess);
                }
                

            } else {

                fullDC.put(distributionChannel, new ArrayList<File>());
            }

        } 
        }
        
        return false;
    }

    /*
        Method checks for the pricing files which are of delta load and then processeds for further processing
        @param:HashMap which contains the info for which DC has to contain how many files
        @param:salesOrg
        
     */
    public void checkForDeltaLoadFiles(String salesOrg, HashMap<Integer, Integer> receivedValues) {

      
        String processingDate = String.valueOf(Integer.parseInt(sysDate));
        deltaFiles = new HashMap<Integer, ArrayList<File>>();
        deltaFiles.clear();

        File folder = new File(Constants.JCS_INPUT_FOLDER);
         Calendar cal = Calendar.getInstance();
         Calendar cal2 = Calendar.getInstance();
       
        cal2.add(Calendar.DATE, -4);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
        Date date = new Date();
        for (cal.getTime();cal.getTime().after(cal2.getTime());cal.add(Calendar.DATE, -1)) {
            date = cal.getTime();
        //    System.out.println("in for loop");
          //  System.out.println(date);
        
       

            for (File f : folder.listFiles()) {
             //   System.out.println("date string is "+sdf.format(date));
                if (f.getName().contains(sdf.format(date).replaceAll("-", "")) && f.getName().contains(salesOrg) && f.getName().contains("_C.txt")) {
                     ArrayList<File> deltafilesToProcess = new ArrayList<File>();
                    //System.out.println("dc    sisisis");
                    String dc = (f.getName().substring(f.getName().indexOf("_" + salesOrg) + 6, f.getName().indexOf("_" + salesOrg) + 8));
                    // System.out.println("dc is "+dc);
                    deltafilesToProcess.add(f);
                    if(deltaFiles.get(Integer.parseInt(dc))!=null&&deltaFiles.get(Integer.parseInt(dc)).isEmpty())
                    {
                      deltaFiles.put(Integer.parseInt(dc), deltafilesToProcess);  
                    }
                    else
                    {
                        if(deltaFiles.get(Integer.parseInt(dc))!=null)
                        {
                            deltaFiles.get(Integer.parseInt(dc)).addAll(deltafilesToProcess);
                        }
                        else
                        {
                           deltaFiles.put(Integer.parseInt(dc), deltafilesToProcess);  
                           delatFilesPresent = true;
                        }
                        
                        
                    }
                   
                   

                }
            }
        
}
        
       //  System.out.println(deltaFiles);
    }
}
