
package com.honeywell.utils;

//import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.sql.*;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import oracle.jdbc.OracleConnection;

/**
 * @author kmatada
 *
 * The Database Utility class interacts with Oracle DBCS(Database table) and
 * fetches record
 */
public class DatabaseUtility {

    HashMap<Integer, Integer> materialMap = new HashMap<Integer, Integer>();
    HashMap<Integer, Integer> customerMap = new HashMap<Integer, Integer>();
    HashMap<Integer, Integer> pricingMap = new HashMap<Integer, Integer>();
    ArrayList<String> salesOrgList = new ArrayList<String>();

    //OracleConnection dbConnection=null;
    Connection dbConnection = null;
    PreparedStatement preparedStatement = null;

    private static final Logger _logger = Logger.getLogger(DatabaseUtility.class.getName());

    public DatabaseUtility() {

    }

    public static void main(String[] args) {

    }

    /*
    This method fetches material template - Material_SalesOrg or MaterialList
    @Param Sales Org
     */
    public String fetchMaterialType(String salesOrg) {
        String materialTemplate = null;
        try {
            dbConnection = (OracleConnection) getDBConnection();
            preparedStatement = dbConnection.prepareStatement(Constants.MATERIAL_TYPE);
            preparedStatement.setString(1, salesOrg);
            ResultSet materialType = preparedStatement.executeQuery();

            while (materialType.next()) {
                materialTemplate = materialType.getString("MATERIAL_TYPE");
            }

            System.out.println("Material Template " + materialTemplate);

        } catch (Exception e) {
            _logger.info("Exception while fetching material template from data base " + e);
        } finally {
            closeConnection();
        }
        return materialTemplate;

    }
   
    
     /*
    This method fetches Distribution channel  with respect to SalesOrg of Material 
    @Param Sales Org
     */
    public HashMap<Integer, Integer> fetchMaterialData(String salesOrg) {

        try {
            dbConnection = (OracleConnection) getDBConnection();
            preparedStatement = dbConnection.prepareStatement(Constants.MATERIAL_QUERY);
            //preparedStatement.setInt(1, Integer.parseInt(salesOrg));

            preparedStatement.setString(1, salesOrg);
            ResultSet materialRs = preparedStatement.executeQuery();

            while (materialRs.next()) {
                materialMap.put(Integer.parseInt(materialRs.getString("DIST_CHANNEL")), Integer.parseInt(materialRs.getString("NO_OF_FILES")));
            }

        } catch (Exception e) {
            _logger.info("Exception while fetching Materail DC values from data base "+e);
        } finally {
            closeConnection();
        }

        return materialMap;

    }

    /*
    This method fetches Distribution channel  with respect to SalesOrg of Customer 
    @Param Sales Org
     */
    public HashMap<Integer, Integer> fetchCustomerData(String salesOrg) {

        try  {
            dbConnection = (OracleConnection) getDBConnection();
            preparedStatement = dbConnection.prepareStatement(Constants.CUSTOMER_QUERY);
            //preparedStatement.setInt(1, Integer.parseInt(salesOrg));

            preparedStatement.setString(1, salesOrg);
            ResultSet customerRs = preparedStatement.executeQuery();
            while (customerRs.next()) {
                customerMap.put(Integer.parseInt(customerRs.getString("DIST_CHANNEL")), Integer.parseInt(customerRs.getString("NO_OF_FILES")));
            }


        } catch (Exception e) {
            _logger.info("Exception while fetching customer files information from date base " + e);
        } finally {
            closeConnection();
        }

        return customerMap;

    }

    public String getCountry(String salesOrg) {
        String countryName = null;
        dbConnection = (OracleConnection) getDBConnection();

        try {
            preparedStatement = dbConnection.prepareStatement(Constants.COUNTRY_NAME);
            preparedStatement.setString(1, salesOrg);
            ResultSet countryNameRs = preparedStatement.executeQuery();
            while (countryNameRs.next()) {
                countryName = countryNameRs.getString("NAME");
                //System.out.println("Country for sales org "+salesOrg+" is "+countryName);
            }
        } catch (SQLException ex) {
            _logger.info("SQLException inside getCountry method " + ex);
        } finally {
            closeConnection();
        }

        return countryName;
    }

    /**
     * Returns list of sales org which needs to be processed
     * @return 
     */
    public ArrayList<String> getAllSalesOrgs() {
        dbConnection = (OracleConnection) getDBConnection();
        try {
            preparedStatement = dbConnection.prepareStatement(Constants.GETSALESORG_LIST);
            ResultSet salesOrgList = preparedStatement.executeQuery();
            while (salesOrgList.next()) {
                this.salesOrgList.add(salesOrgList.getString("SALES_ORG"));
            }
        } catch (SQLException ex) {
            _logger.info("SQLException inside getAllSalesOrgs() method " + ex);
        } finally {
            closeConnection();
        }
        return salesOrgList;
    }

     /*
    This method fetches Distribution channel  with respect to SalesOrg of Pricing
    @Param Sales Org
     */
    public HashMap<Integer, Integer> fetchPricingData(String salesOrg) {

        try {
            dbConnection = (OracleConnection) getDBConnection();
            preparedStatement = dbConnection.prepareStatement(Constants.PRICING_QUERY);
            //preparedStatement.setInt(1, Integer.parseInt(salesOrg));

            preparedStatement.setString(1, salesOrg);
            ResultSet pricingRs = preparedStatement.executeQuery();
            while (pricingRs.next()) {
                pricingMap.put(Integer.parseInt(pricingRs.getString("DIST_CHANNEL")), Integer.parseInt(pricingRs.getString("NO_OF_FILES")));
            }


        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            closeConnection();
        }

        return pricingMap;

    }

    //Getting pricing type for specified sales org
    public String getPricingType(String salesOrg) {
        String pricingType = null;

        try {
            dbConnection = (OracleConnection) getDBConnection();
            preparedStatement = dbConnection.prepareStatement(Constants.PRICING_TYPE);
            preparedStatement.setString(1, salesOrg);
            ResultSet pricingTypeRs = preparedStatement.executeQuery();

            while (pricingTypeRs.next()) {
                pricingType = pricingTypeRs.getNString("PRICING_TYPE");
                System.out.println("Pricing type " + pricingType);
            }

        } catch (Exception e) {
            _logger.info("Exception while getting pricing type for the sales org");
        } finally {
            closeConnection();
        }

        return pricingType;
    }

    /* To test locally */
   public Connection getDBConnection(){
        try {           
            DriverManager.registerDriver (new oracle.jdbc.OracleDriver());
            //String connectionUrl = "jdbc:oracle:thin:weblogic/Honeywell#123@//HoneywellDB:1521/PDB1.a476074.oraclecloud.internal";
            String connectionUrl = "jdbc:oracle:thin:honeywell/Honeywell#123@//144.21.64.152:1521/PDB1.a476074.oraclecloud.internal";
            
            dbConnection = (OracleConnection)DriverManager.getConnection(connectionUrl);
            
            System.out.println("Connection object details : "+dbConnection);
            dbConnection.setAutoCommit(false);
 
 
          return dbConnection;
        } catch (Exception e) {
           e.printStackTrace();
           //DiagnosticUtil.printStackTrace(e);
           throw new RuntimeException(e.getMessage());
        }
    }
    
    /**
     * The method returns Database connection 
     * @return 
     */
  /*  public Connection getDBConnection() {
        System.out.println("Inside get DB Connection method in java***");

        InitialContext ctx;

        try {

            ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup("jdbc/honeywellDS");
            dbConnection = ds.getConnection();
            System.out.println("Connection object details : " + dbConnection);

            return dbConnection;
        } catch (NamingException e) {
           
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dbConnection;

    }*/

    //Closing the connection
    public void closeConnection() {

        try {
            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (dbConnection != null) {
                dbConnection.close();
            }
        } catch (SQLException e) {

        }

    }

}
 