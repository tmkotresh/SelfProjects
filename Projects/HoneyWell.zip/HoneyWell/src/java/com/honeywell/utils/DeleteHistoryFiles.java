/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.io.FileUtils;

/**
 *
 * @author devadred
 * 
 * This class deletes the history files i.e files older than 45 days
 * 
 * And also deletes the xml files generated after converting them to zip file and sending to the outbound server
 * 
 */
public class DeleteHistoryFiles {
    
    
    public static void main(String[] args) {
        new DeleteHistoryFiles().deleteProcessedHistoryFiles();
         new DeleteHistoryFiles().deleteOuputXMLFiles();
    }
    /*
    This method deletes the xml files from the output folder once the zip creation and transfer to outbound server is done
    
    */
    public void deleteOuputXMLFiles()
    {
        try {
            File directory = new File(Constants.JCS_OUTPUT_FOLDER); 
            FileUtils.cleanDirectory(directory);
        } catch (IOException ex) {
            Logger.getLogger(DeleteHistoryFiles.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /*
    This method deletes the files which are older than 45 days from the processed folder
    
    */
    public void deleteProcessedHistoryFiles()
    {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -45);
          SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
         
          File folderToDelete = new File(Constants.JCS_PROCESSED_FILES+sdf.format(cal.getTime())+"/");
          System.out.println(folderToDelete);
          if(folderToDelete.exists())
          {
              folderToDelete.delete();
          }
    }
    
}
