package com.honeywell.utils;

import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 *
 * @author: Deekshith
 *
 * Class converts the xml file in to zip file
 */
public class FoldertoZipConverter {

     String zipFileName = null;
    public void createZip(String filetoZip) throws SftpException, FileNotFoundException {
        File file = new File(Constants.XML_FILES_SOURCE_FOLDER_LOCATION);
        String[] names = file.list();
        /*
	 * this loop will iterate the folder and converts each file to zip
         */
//        for (String name : names) {
//            try {
//                convertFilesToZip(name);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
        
        convertFilesToZip(filetoZip);
        try
        {
          //  TransferZiptoOutboundServer transferZiptoOutboundServer = new TransferZiptoOutboundServer();
           // transferZiptoOutboundServer.pushFiles( zipFileName + ".zip");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }

    /*
	 * This method will create the zip files(this contains the actual zipping
	 * implimentation)
     */
    void convertFilesToZip(String name) {
       
        byte[] buffer = new byte[1024];
        try {
            if (name.contains(".xml")) {
                zipFileName = name.substring(0, name.indexOf(".xml"));
            }
            FileOutputStream fileOutputStream = new FileOutputStream(Constants.OUTPUT_ZIP_FILES_LOCATION + zipFileName + ".zip");
            ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);
            ZipEntry zipEntry = new ZipEntry(name);
            zipOutputStream.putNextEntry(zipEntry);
            FileInputStream in = new FileInputStream(Constants.XML_FILES_SOURCE_FOLDER_LOCATION + name);
            int len;
            while ((len = in.read(buffer)) > 0) {
                zipOutputStream.write(buffer, 0, len);
            }
            in.close();
            zipOutputStream.closeEntry();
            zipOutputStream.close();
            File f = new File(Constants.OUTPUT_ZIP_FILES_LOCATION + zipFileName + ".zip");
            f.setExecutable(true, false);
            f.setReadable(true, false);
            f.setWritable(true, false);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
