package com.honeywell.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

/*

@author : Deekshith

this class will generate the array of chunks which willl be written to the output file as the short and long descriptions
*/
public class DescriptorArrayGenerator {
    String preProcessor;
                String finalValue;
		ArrayList<String> stringsDescShort = new ArrayList<String>();
                ArrayList<String> typValues = new ArrayList<String>();
                 ArrayList<String> fabrikatValues = new ArrayList<String>();
		int indexShrtDesc = 0;
    public static void main(String[] args) {
        String str = "Honeywell Handgriff f UP-Ventil VA2410C ABS Kunststoff, verchromt für DN 15 - 25";
        new DescriptorArrayGenerator().createDescriptionArray(str);
    }
	
    /*
    Method breaks the string in to 40 charecter chunks and also breaks on the last space in the 40 charecter chunk
    
    */
	public ArrayList<String> createDescriptionArray(String str)
	{
		
	
		str = str.replace("\n", "").replace("\r", "");
		
	
	while ((indexShrtDesc+40) < str.length()) {
		
		
			 preProcessor = str.substring(indexShrtDesc, indexShrtDesc+40);
		
	

		if(Character.toString(preProcessor.charAt(0)).equalsIgnoreCase(" "))
		{
			preProcessor = str.substring(indexShrtDesc+1, indexShrtDesc+41);
			indexShrtDesc++;
		}
		
                if((str.length())>(indexShrtDesc+40))
                {
                  if(Character.toString(str.charAt(indexShrtDesc+40)).equalsIgnoreCase(" "))
		{
			 finalValue = preProcessor.substring(0, 40).trim();
			 indexShrtDesc += finalValue.length();
		}  
                  else
		{
			 finalValue = preProcessor.substring(0, preProcessor.lastIndexOf(" "));
			 indexShrtDesc += finalValue.length();
		}
               
                }
		
		else
                {
                    finalValue = preProcessor.substring(0, 40).trim();
                    indexShrtDesc += finalValue.length();
                }
		
                
                if(finalValue.contains("Typ:")&&finalValue.contains("Fabrikat:"))
                {
                    if(finalValue.indexOf("Fabrikat:")>finalValue.indexOf("Typ:"))
                    {
                      typValues =   checkForExceptionCaseTyp(str,"combined");
                  //     finalValue = typValues.get(0);
		//indexShrtDesc	 =  Integer.parseInt(typValues.get(1));
                    }
                    else
                    {
                         fabrikatValues = checkForExceptionCaseFabrikat(str,"combined");
                //   finalValue =    fabrikatValues.get(0);
		//	indexShrtDesc	 =  Integer.parseInt(fabrikatValues.get(1));
                    }
                }
                else if(finalValue.contains("Typ:")||finalValue.contains("Fabrikat:"))
                {
                    if(finalValue.contains("Typ:"))
		{
                   
                   typValues = checkForExceptionCaseTyp(str,"independent");
              //   finalValue = typValues.get(0);
		//indexShrtDesc	 =  Integer.parseInt(typValues.get(1));
			

		}
		else if(finalValue.contains("Fabrikat:"))
		{
                    fabrikatValues = checkForExceptionCaseFabrikat(str,"independent");
                //   finalValue =    fabrikatValues.get(0);
		//	indexShrtDesc	 =  Integer.parseInt(fabrikatValues.get(1));

		}
                }
		
		
		          System.out.println(finalValue);
			stringsDescShort.add(StringUtils.rightPad(finalValue.trim(), 40, ""));
		
		
		
	}
	
	preProcessor  =  str.substring(indexShrtDesc);
        
        if( preProcessor.trim().startsWith("Fabrikat:"))
                    {
                        
                      if(preProcessor.trim().indexOf(":", preProcessor.indexOf("Fabrikat:")+9)>0)
                      {
                         finalValue = preProcessor.substring(0, preProcessor.lastIndexOf(":")+1);
                           stringsDescShort.add(StringUtils.rightPad(finalValue.trim(), 40, ""));
                         
                         finalValue =   preProcessor.substring(finalValue.length()+1, preProcessor.length());
                      
                         stringsDescShort.add(StringUtils.rightPad(finalValue.trim(), 40, ""));
                      }
                      else
                      {
                          finalValue = preProcessor.substring(0, preProcessor.length());
                      }
                    }
	
	
        else if(preProcessor.trim().startsWith("Typ:"))
        {
            if(preProcessor.trim().indexOf(":", preProcessor.indexOf("Typ:")+4)>0)
                      {
                         
                          finalValue = preProcessor.substring(0, preProcessor.lastIndexOf(":")+1);
                           stringsDescShort.add(StringUtils.rightPad(finalValue.trim(), 40, ""));
                         
                         finalValue =   preProcessor.substring(finalValue.length()+1, preProcessor.length());
                      
                         stringsDescShort.add(StringUtils.rightPad(finalValue.trim(), 40, ""));
                          
                      }
                      else
                      {
                          finalValue = preProcessor.substring(0, preProcessor.length());
                      }
                        
        }
	
        else if(!(preProcessor.trim().isEmpty()))
        {
            stringsDescShort.add(StringUtils.rightPad(preProcessor.trim(), 40, ""));
        }
         

		return stringsDescShort;
	}
	
        /*
        This method checks for the exception keywords Fabrikat:
        
        Chunk has to be broken when we encounter the keyword Fabrikat
        
        */
          public ArrayList<String> checkForExceptionCaseFabrikat(String str,String combination)
          {
              ArrayList<String> values = new ArrayList<>();
              switch(combination){
                      case "combined":
                           if( finalValue.trim().startsWith("Fabrikat:"))
                    {
                        
                      if(finalValue.trim().indexOf(":", finalValue.indexOf("Fabrikat:")+9)>0)
                      {
                          indexShrtDesc =  indexShrtDesc-(finalValue.length()-finalValue.indexOf("Typ:"));
                          finalValue = finalValue.substring(0, finalValue.indexOf("Typ:"));
                          
                      }
                      else
                      {
                          finalValue = finalValue.substring(0, finalValue.indexOf("Typ:"));
                      }
                    }
                    else
                    {
                         indexShrtDesc =  str.indexOf("Fabrikat:", indexShrtDesc-finalValue.length());  
                      finalValue = finalValue.substring(0, finalValue.indexOf("Fabrikat:"));
			
                    }
               values.add(finalValue);
               values.add(String.valueOf(indexShrtDesc));
               
                          break;
                      case "independent":
                           if( finalValue.trim().startsWith("Fabrikat:"))
                    {
                        
                      if(finalValue.trim().indexOf(":", finalValue.indexOf("Fabrikat:")+9)>0)
                      {
                          indexShrtDesc =  indexShrtDesc-(finalValue.length()-finalValue.lastIndexOf(":")-1);
                          finalValue = finalValue.substring(0, finalValue.lastIndexOf(":")+1);
                          
                      }
                      else
                      {
                          finalValue = finalValue.substring(0, finalValue.length());
                      }
                    }
                    else
                    {
                         indexShrtDesc =  str.indexOf("Fabrikat:", indexShrtDesc-finalValue.length());  
                      finalValue = finalValue.substring(0, finalValue.indexOf("Fabrikat:"));
			
                    }
               values.add(finalValue);
               values.add(String.valueOf(indexShrtDesc));
                          break;
              }
              
               return values;
          }
          
          
         
        /*
        This method checks for the exception keywords Typ:
        
        Chunk has to be broken when we encounter the keyword Typ:
          
          so that the next line starts with Keyword
        
        */ 
        public ArrayList<String>  checkForExceptionCaseTyp(String str,String combination)
        {
             ArrayList<String> values = new ArrayList<>();
             if( finalValue.trim().startsWith("Typ:"))
                    {
                      
                      if(finalValue.trim().indexOf(":", finalValue.indexOf("Typ:")+4)>0)
                      {
                          indexShrtDesc =  indexShrtDesc-(finalValue.length()-finalValue.lastIndexOf(":")-1);
                          finalValue = finalValue.substring(0, finalValue.lastIndexOf(":")+1);
                          
                      }
                      else
                      {
                          finalValue = finalValue.substring(0, finalValue.length());
                      }
                        
                   
                    }
                    else
                    {
                        indexShrtDesc =  str.indexOf("Typ:", indexShrtDesc-finalValue.length());
                        finalValue = finalValue.substring(0, finalValue.indexOf("Typ:"));
                         
                    }
             values.add(finalValue);
               values.add(String.valueOf(indexShrtDesc));
               return values;
        }
}
