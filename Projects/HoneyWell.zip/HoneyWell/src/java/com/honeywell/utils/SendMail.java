/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;


/**
 *
 * @author kmatada
 */
public class SendMail {
    
    public SendMail(){
        
    }
    
    Connection connection = null;
        CallableStatement cs = null;
        Connection dbConnection = null;
        
        String fromEmailAddress="chetan.durg@oracle.com";
        String toEmailAddress="kotresh.matada@oracle.com";
        String subjectTemplate="This is test email from jcs";
        String bodyTemplate="This is test email sent from code";

    public static void main(String[] args) {
        
        new SendMail().sendMail();
                    
        
    }
    
    public void sendMail(){
        System.out.println("inside the sendMail method");
        dbConnection = new DatabaseUtility().getDBConnection();
        System.out.println("After DB Connection");
                    //if (connection != null) {
            try {
                  System.out.println("Inside try");
                cs = dbConnection.prepareCall("BEGIN SEND_EMAIL(?,?,?,?,?);COMMIT; END;");
                System.out.println("After prepare call");
                cs.registerOutParameter(5, Types.VARCHAR);
                cs.setObject(1, fromEmailAddress);
                // get the mail from mail id
                cs.setObject(2, toEmailAddress);
                cs.setObject(3, subjectTemplate);
                cs.setObject(4, bodyTemplate);
                cs.execute();
                dbConnection.commit();
                String emailSend = cs.getString(5);
                System.out.println("Email send "+emailSend);
            } catch (SQLException ex) {
                ex.printStackTrace();
                System.out.println("Exception "+ex);
            }

    //}
    }
}
