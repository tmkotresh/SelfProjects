package com.honeywell.utils;

import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;

import org.apache.log4j.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/*
@author : Deekshith

This class will read the zip files in the folder for that particular date and adds entries in to the upload list.xml file

*/
public class UploadListGenerator {

    public static void main(String[] args) {
new UploadListGenerator().generateXml();
    }

    /*
    Method will read the files and adds entries in to the xml file
    */
    public void generateXml() {
        
         Calendar cal = Calendar.getInstance();
          SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
          String dateCheck = sdf.format(cal.getTime());
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = null;
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        Document uploadXml = documentBuilder.newDocument();
        /*
         *           This Will create the Root Node in the xml.
         */
        Element parentNode = uploadXml.createElement("files");
        uploadXml.appendChild(parentNode);
        /*
         *           This loop will get the names of the zip files inside the folder
         */
        File file = new File(Constants.OUTPUT_ZIP_FILES_LOCATION);
        String[] names = file.list();

        for (String name : names) {
            if (!"upload_list.xml".equalsIgnoreCase(name)) {
                
                if(name.contains(dateCheck))
                {      
                /*
                 *     This will create the second note i.e file
                 */
                Element parentFileNode = uploadXml.createElement("file");
                parentNode.appendChild(parentFileNode);
                /*
		 *     This will create the final child tag and gives name to it
                 */
                Element childFilesNode = uploadXml.createElement("name");
                childFilesNode.appendChild(uploadXml.createCDATASection(name));
                parentFileNode.appendChild(childFilesNode);

            }
                  }
        }

        /*
         *              This section will flush the content in to an xml file
         */
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = null;
        try {
            transformer = transformerFactory.newTransformer();
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        }
        DOMSource xmlSource = new DOMSource(uploadXml);
        StreamResult uploadXMLFile = new StreamResult(Constants.UPLOAD_LIST_XML_LOCATION);
        try {
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.transform(xmlSource, uploadXMLFile);

            File f = new File(Constants.OUTPUT_ZIP_FILES_LOCATION + "upload_list.xml");
            f.setExecutable(true, false);
            f.setReadable(true, false);
            f.setWritable(true, false);

             TransferZiptoOutboundServer transferZiptoOutboundServer = new TransferZiptoOutboundServer();
            transferZiptoOutboundServer.pushFiles( "upload_list.xml");
            
        } 
     
        catch (TransformerException e) {

            e.printStackTrace();
        } catch (SftpException ex) {
            java.util.logging.Logger.getLogger(UploadListGenerator.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            java.util.logging.Logger.getLogger(UploadListGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
