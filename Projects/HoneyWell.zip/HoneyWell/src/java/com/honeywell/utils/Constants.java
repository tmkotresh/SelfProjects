/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

/**
 *
 * @author kmatada
 */
public class Constants {

    public static final String HOST_NAME = "mftp.honeywell.com";
    public static final String PASSWORD = "";
    public static final String USER_NAME = "sap_bigmachines";
    public static final String CHANNEL = "sftp";
    public static final int PORT = 22;

    public static final String IB_SFTP_SOURCE_FOLDER = "/JCS/";
    
    public static final String JCS_LOG_FILE_LOCATION="/u01/data/backup/honeywell/log";
    public static final String CONFIG_PROPERTY="/u01/data/backup/honeywell/honeywellconfig.properties";
    public static final String ACTIVE_AND_INACTIVE_SALES_ORG_PROP="/u01/honeywell/activeAndInactiveSalesOrg.properties";

    
  //public static final String JCS_INPUT_FOLDER = "/u01/data/backup/honeywell/input/";
  // public final static String JCS_OUTPUT_FOLDER = "/u01/data/backup/honeywell/output/";
    
 //public static final String JCS_PROCESSED_FILES="/u01/data/backup/honeywell/processedfiles/";
    
     public final static String XML_FILES_SOURCE_FOLDER_LOCATION = "/u01/data/backup/honeywell/output/";
    
  //  public final static String OUTPUT_ZIP_FILES_LOCATION = "/u01/data/backup/honeywell/zipfilesoutput/";
     
    public final static String UPLOAD_LIST_XML_LOCATION = "/u01/data/backup/honeywell/zipfilesoutput/upload_list.xml";
    

    
    /*For Local Testing */
    
  public static final String JCS_INPUT_FOLDER="D:\\Work\\HoneyWell\\Testing\\in\\";
 public final static String JCS_OUTPUT_FOLDER="D:\\Work\\HoneyWell\\Testing\\out\\";
//    public static final String ACTIVE_AND_INACTIVE_SALES_ORG_PROP="D:\\Work\\HoneyWell\\activeAndInactiveSalesOrg.properties";
//            public static final String CONFIG_PROPERTY="D:\\Work\\HoneyWell\\honeywellconfig.properties";
//            public static final String JCS_LOG_FILE_LOCATION="D:\\Work\\HoneyWell\\Testing\\log\\";
           public static final String JCS_PROCESSED_FILES="D:\\Work\\HoneyWell\\Testing\\processedFiles\\";
   //        public final static String XML_FILES_SOURCE_FOLDER_LOCATION = "D:\\Work\\HoneyWell\\Testing\\out\\";
          public final static String OUTPUT_ZIP_FILES_LOCATION = "D:\\Work\\HoneyWell\\Testing\\zipfilesoutput\\";
//            public final static String UPLOAD_LIST_XML_LOCATION = "D:\\Work\\HoneyWell\\Testing\\zipfilesoutput\\upload_list.xml";
//            public static final String JCS_INPUT="D:\\Work\\HoneyWell\\Testing\\input";
    
    /*  -------- */
    public final static String RECORD_LIST = "record_list";

    public final static String EACH_RECORD = "each_record";

    public final static String CATEGORY = "category";
    public final static String ACTION = "action";
    public final static String TABLE_NAME = "table_name";
    public final static String PART_NUMBER = "PartNumber";
    public final static String MIN_ORDER_QTY = "MinOrderQty";
    public final static String DELIVERY_QTY = "DeliveryQty";
    public final static String LEAD_TIME = "LeadTime";
    public final static String MATERIAL_PRICING_GROUP = "MaterialPricingGroup";
    public final static String DISTR_CHANNEL = "DistrChannel";
    public final static String BRAND = "Brand";
    public final static String LOB = "LOB";
    public final static String PRODUCT_HIERACRCHY = "ProductHierarchy";
    public final static String PROD_H2TO5 = "ProdH2to5";
    public final static String LBM = "LBM";
    public final static String UOM = "UoM";

    public final static String FIRST_ELE_ACTION = "delete_all";
    public final static String LAST_ELE_ACTION = "deploy";
    public final static String ELE_ACTION_VALUE = "add";
    
    public static final String MATERIAL_LIST="MaterialList";
    public static final String MATERIAL_SALES_ORG="Material_SalesOrg";

   
        /*
     * Constants added by deekshith for creating upload_list.xml
     * 
     * */

  
    public final static String SMTP_HOST_NAME = "smtp.gmail.com";
    public final static String SMTP_USERNAME = "deekshithdeva3496";
    public final static String SMTP_PASSWORD = "**********";
    public final static String SMTP_ATTACHMENT_LOCATION = "D:\\HoneyWell\\SampleZipFiles\\TestFileszip.zip";
    public final static String SMTP_MAIL_SUBJECT = "Test Email to check the sending of txt files as attachments";
    public final static String SMTP_MAIL_CONTENT = "Hello,\n\n PFA ";
    public final static int SMTP_PORT = 587;
    public static final String OUTPUT_LOG_LOCATION ="D:\\sampleLog.log";
    public static final String SMTP_MAIL_ATTACHMENT_NAME = "SAMPLE.ZIP";
    public static final String MAIL_RECEIPENTS = "deekshith.deva@gmail.com";
    
    
    /*
     * Constants added by deekshith for creating pricing full load xml files
     * */
    
    public final static String PRICING_XML_OUPUT_LOCATION = "D:\\HoneyWell\\PricingTesting\\output";
    public final static String PRICING_TXT_INPUT_LOCATION = "D:\\Tests\\Test2\\Input";
    public final static String PRICING_XML_TAG_CATEGORY = "category";
    public final static String PRICING_XML_TAG_ACTION = "action";
    public final static String PRICING_XML_TAG_TABLE_NAME = "table_name";
    public final static String PRICING_XML_TAG_TABLECODE = "TableCode";
    public final static String PRICING_XML_TAG_CUSTOMERNUMBER = "CustomerNumber";
    public final static String PRICING_XML_TAG_DISTRCHANNEL = "DistrChannel";
    public final static String PRICING_XML_TAG_PARTNUMBER = "PartNumber";
    public final static String PRICING_XML_TAG_PRICELISTTYPE = "PriceListType";
    public final static String PRICING_XML_TAG_FROMDATE = "FromDate";
    public final static String PRICING_XML_TAG_ENDDATE = "EndDate";
    public final static String PRICING_XML_TAG_PRICE = "Price";
    public final static String PRICING_XML_TAG_PRICEGROUP = "PriceGroup";
    public final static String PRICING_XML_TAG_SCALEQUANTITY = "ScaleQuantity";
    public final static String PRICING_XML_TAG_CURRENCY = "Currency";
    public final static String PRICING_XML_TAG_PRODUCT_GROUP = "ProductGroup";
    public final static String PRICING_XML_TAG_MaterialPricingGroup = "MaterialPricingGroup";
    public final static String PRICING_XML_TAG_SalesOffice = "SalesOffice";
    public final static String PRICING_XML_TAG_LOB = "LOB";
    public final static String PRICING_XML_TAG_Discount = "Discount";
    public final static String PRICING_XML_TAG_ProdH2to5 = "ProdH2to5";
    public final static String PRICING_XML_TAG_Brand = "Brand";
    public final static String PRICING_XML_TAG_ProductGroup = "ProductGroup";
    public final static String PRICING_XML_TAG_ShipTo = "ShipTo";
    public final static String PRICING_XML_TAG_SalesCat3 = "SalesCat3";
    public final static String PRICING_XML_TAG_ScaleValue = "ScaleValue";
    
    
    
    public static String[] table_Codes_legacy = { "ZCSP", "ZD00", "ZD03", "ZD04", "ZD05", "ZD06", "ZD08", "ZP00" };
    public static String[] table_Codes_Bestpractice = { "ZOEM", "ZX02", "ZX04", "ZX06", "ZX07", "ZX09", "ZX12", "ZXMO","ZXNP","ZXPR"};
	
	public static String[] legacyTypes={"2092","2093","2094","2203","2223","223X","249E","2538","2546","2567","517E","518E","616E","617E","618E","621E","660E","661E"};
	public static String[] bestPracticeTypes={"2247","2528","253T","2938","2959","2960","2961","507E","584E","604E","607E","619E","734E","786E"};
    /*
    Properties for pushing files to outbound sftp server Added By Deekshith
    */
    
    public static final String OUTBOUND_SFTP_PROXY_HOST = "www-proxy.uk.oracle.com";
    public static final int OUTBOUND_SFTP_PROXY_PORT = 80;
    public static final String OUTBOUND_SFTP_HOST = "ftp3.bigmachines.com";
    public static final int OUTBOUND_SFTP_PORT = 22;
    public static final String OUTBOUND_SFTP_USER_NAME = "testhoneywell";
    public static final String OUTBOUND_SFTP_PASSWORD = "testhone8171";
    public static final String OUTBOUND_SFTP_UPLOADFILES_LOCATION = "/upload_zip/automated/";
   public static final String TEST_OUTBOUND_SFTP_UPLOADFILES_LOCATION = "/data/testftp2/";
    
   // public static final String OUTBOUND_SFTP_UPLOADFILES_LOCATION = "D:\\Work\\HoneyWell\\Testing\\zipfilesoutput";
   // public static final String TEST_OUTBOUND_SFTP_UPLOADFILES_LOCATION = "D:\\Work\\HoneyWell\\Testing\\zipfilesoutput";
    

    
  //  public static final String OUTBOUND_SFTP_UPLOADFILES_LOCATION="/upload_zip/automated/";

    /* Constants for customer file processing */
    //public final static String EACH_RECORD = "each_record";
    //public final static String CATEGORY = "category";
    //public final static String TABLE_NAME = "table_name";*/
    public final static String CUSTOMER_NUMBER = "CustomerNumber";
    public final static String SALES_ORG = "SalesOrg";
    //public final static String DISTR_CHANNEL = "DistrChannel";
    public final static String RINGTYPE = "RingType";
    public final static String RINGNAME = "RingName";
    public final static String CUSTOMER_GROUP = "CustomerGroup";
    public final static String PRICELIST_TYPE = "PriceListType";
    public final static String PRICE_GROUP = "PriceGroup";
    public final static String INCOTERMS = "Incoterms2";
    public final static String INCOTERMS2 = "Incoterms2";
    public final static String PAYMENT_TERMS = "PaymentTerms";
    public final static String SALES_OFFICE = "SalesOffice";
    public final static String CURRENCY = "Currency";
    
      //Constants Added by Deekshith for GAEB Report
    
    public static final String GAEB_OUTPUT_TXT_FILES_LOCATION = "D:\\Tests\\01-GAEB\\Tests\\Test5\\output\\";
    public static final String GAEB_INPUT_XML_FILES_LOCATION = "D:\\Tests\\01-GAEB\\Tests\\Test5\\";
    
    
    // Database Query 
    
    public final static String MATERIAL_QUERY ="SELECT DIST_CHANNEL,NO_OF_FILES FROM SALES_ORG_DETAIL WHERE ACTIVE='Y' AND MATERIAL_TYPE IN('Y','Material_SalesOrg','MaterialList') AND SALES_ORG = ?";
    
    public final static String CUSTOMER_QUERY ="SELECT DIST_CHANNEL,NO_OF_FILES FROM SALES_ORG_DETAIL WHERE  ACTIVE='Y' AND CUSTOMER_TYPE='Y' AND SALES_ORG=?";
    
    public final static String PRICING_QUERY="SELECT DIST_CHANNEL,NO_OF_FILES FROM SALES_ORG_DETAIL WHERE ACTIVE='Y' AND PRICING_TYPE='Y' AND SALES_ORG=?";
    
    public static final String GETSALESORG_LIST = "SELECT DISTINCT SALES_ORG FROM SALES_ORG_DETAIL";
    
    public static final String MATERIAL_TYPE="SELECT DISTINCT MATERIAL_TYPE FROM SALES_ORG_DETAIL WHERE ACTIVE='Y' AND SALES_ORG=?";
    
    public static final String PRICING_TYPE="SELECT PRICING_TYPE FROM SALES_ORG_PRICING_TYPE WHERE SALES_ORG=?";
    
    public static final String COUNTRY_NAME = "SELECT DISTINCT NAME FROM SALES_ORG_DETAIL WHERE SALES_ORG=?";
}
