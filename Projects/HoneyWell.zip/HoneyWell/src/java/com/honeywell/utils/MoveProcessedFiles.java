package com.honeywell.utils;

import com.honeywell.toppic.TxtToXMLCommon;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

/*

@author Deekshith

This class moves the files to processed folders once they are processed by the system

*/
public class MoveProcessedFiles {
	
	 private static final Logger  _logger = Logger.getLogger(TxtToXMLCommon.class.getName());
	public static ArrayList<File> filesToMove  =new ArrayList<File>();
	public static ArrayList<File> filesToDelete  =new ArrayList<File>();

        /*
        Method reads the files and moves the files to respective folders in the processed folder
        @param:FiletoMove
        @salesorg
        */
	public  void moveFiles(ArrayList<File> filesToMove,String salesOrg) throws IOException
	{
            // _logger.info("coming from move processed folder"+filesToMove);
            
		for(File file: filesToMove)
		{
			
			if(file.getAbsolutePath().contains(Constants.JCS_INPUT_FOLDER))
			{
				//System.out.println(f.getName().substring(0, f.getName().indexOf("_"+salesOrg)));
				 // _logger.info("inside contains with name"+file);
				System.out.println(file.getName().substring(file.getName().indexOf("_"+salesOrg)+9, file.getName().indexOf("_"+salesOrg)+17));
				String foldertoMove = file.getName().substring(file.getName().indexOf("_"+salesOrg)+9, file.getName().indexOf("_"+salesOrg)+17);
				
				  File f = new File(Constants.JCS_INPUT_FOLDER + file.getName());
	            System.out.println("f path is "+f.getAbsolutePath());
				  File f2 = new File(Constants.JCS_PROCESSED_FILES + foldertoMove + "/" + file.getName());
				  System.out.println("f2 path is "+f2.getAbsolutePath());
	                File folder = new File(Constants.JCS_PROCESSED_FILES + foldertoMove);
	                folder.setExecutable(true, false);
	                folder.setReadable(true, false);
	                folder.setWritable(true, false);
	                FileUtils.copyFile(f, f2);
	                f2.setExecutable(true, false);
	                f2.setReadable(true, false);
	                f2.setWritable(true, false);
	                
	                filesToDelete.add(file);
			}
		}
		
		new MoveProcessedFiles().deleteFilesFromInputFolder(filesToDelete);
	}
	
        /*
        Method deletes the files from the input folder once they are copied from the input folder to processed folder
        */
	public void deleteFilesFromInputFolder(ArrayList<File> filesToDelete)
	{
		for(File f :filesToDelete)
		{
			f.delete();
		}
	}
}











