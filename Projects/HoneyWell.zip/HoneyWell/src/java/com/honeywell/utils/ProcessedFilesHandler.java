/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.commons.io.FileUtils;

/**
 * This Class will move the files to processed files folder once the text file
 * is processed and also deletes thefiles from input folder in JCS
 *
 * @author devadred
 */
public class ProcessedFilesHandler {
    
    public static void main(String[] args) throws IOException {
        deleteXMLFiles();
        moveZipFileToBackup();
        System.out.println("done");
    }

    public static String getCurrentDate() {
        Date date = new Date();

        String formatedDate = new SimpleDateFormat("YYYYMMdd").format(date);

        //System.out.println("Current Date "+formatedDate);
        return formatedDate;

    }
    private static String currentDate = ProcessedFilesHandler.getCurrentDate();

    public static void moveToProcessedFolder(ArrayList<File> filesToMove) {
       
        for (File file : filesToMove) {
            
            
            try {
                File f = new File(Constants.JCS_INPUT_FOLDER + file.getName());
                File f2 = new File(Constants.JCS_PROCESSED_FILES + currentDate + "/" + file.getName());

                File folder = new File(Constants.JCS_PROCESSED_FILES + currentDate);
              //  System.out.println("setting permissions for folder name "+folder.getName());
                folder.setExecutable(true, false);
                folder.setReadable(true, false);
                folder.setWritable(true, false);
               
                FileUtils.copyFile(f, f2);
             
                f2.setExecutable(true, false);
                f2.setReadable(true, false);
                f2.setWritable(true, false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
    
    public static void moveZipFileToBackup() throws IOException
    {
         File folder = new File(Constants.OUTPUT_ZIP_FILES_LOCATION );
         for(File f : folder.listFiles())
         {
          //   File backUpFolder = new File(Constants.JCS_PROCESSED_FILES + currentDate);
             File f2 = new File(Constants.JCS_PROCESSED_FILES + currentDate + "/" + f.getName());
              FileUtils.copyFile(f, f2);
               f2.setExecutable(true, false);
                f2.setReadable(true, false);
                f2.setWritable(true, false);
         }
    }
    public static void deleteProcessedFiles(ArrayList<File> filesToDelete) {

        for (File file : filesToDelete) {
            File f = new File(Constants.JCS_INPUT_FOLDER +  file.getName());

            f.delete();

        }
    }
    
    public static void deleteXMLFiles()
    {
         File folder = new File(Constants.XML_FILES_SOURCE_FOLDER_LOCATION );
          for (File file : folder.listFiles()) {
            File f = new File(Constants.XML_FILES_SOURCE_FOLDER_LOCATION +  file.getName());

            f.delete();

        }
    }

}
