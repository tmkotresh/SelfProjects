/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import com.honeywell.scheduler.jobs.SFTPJob;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

/**
 *
 * @author kmatada
 */
public class KillJob extends HttpServlet {
    
    public void killJob(){
        try {
            System.out.println("Inside kill Job");
            SchedulerFactory schfa = new StdSchedulerFactory();
            Scheduler sch = schfa.getScheduler();
            // sch.deleteJob(SFTPJob);
            JobDetail jobDetail = JobBuilder.newJob(SFTPJob.class).withIdentity("SFTPJob", sch.DEFAULT_GROUP).build();
            
            //JobDetail jobdetail =
            //CronTrigger crontrigger = (CronTrigger) TriggerBuilder.newTrigger().withIdentity("cron-trigger", sch.DEFAULT_GROUP).withSchedule(createSchedule(cronExpression)).build();
            //sch.scheduleJob(jobdetail, crontrigger);
            JobKey key = jobDetail.getKey(); 
            sch.deleteJob(key);
            sch.shutdown();
//             HttpSession sess = request.getSession(true);
//                sess.setAttribute("status", "Inprogress");

     

        } catch (SchedulerException ex) {
            Logger.getLogger(KillJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response){
        try {
            request.setAttribute("status", "Job Started..& it is completed");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        } catch (ServletException ex) {
            Logger.getLogger(KillJob.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(KillJob.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
