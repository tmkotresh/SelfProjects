/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.honeywell.utils;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Vector;
import org.apache.log4j.Logger;

/**
 *
 * @author devadred
 * 
 * This class will move the zip files to outbound server and set the required permissions to the files
 */
public class TransferZiptoOutboundServer {

    private static Properties prop = new Properties();
    private static InputStream input = null;
    private static final org.apache.log4j.Logger  _logger = org.apache.log4j.Logger.getLogger(TransferZiptoOutboundServer.class.getName());
   
    /*
    Method connects to the outbound server opens channel and session and pushes the files to outbound server
    
    */
    public void  pushFiles(String fileName) throws SftpException, FileNotFoundException
    {
        JSch jsch = new JSch();

        Session session = null;
        Channel channel = null;
         
        try {
            input = new FileInputStream(Constants.CONFIG_PROPERTY);
            
            prop.load(input);
        } catch (IOException ex) {
            _logger.info("Exception while reading config property");
        }

        try {
           // System.getProperties().put("http.proxyHost", prop.getProperty("OUTBOUND_SFTP_PROXY_HOST"));
            //System.getProperties().put("http.proxyPort",prop.getProperty("OUTBOUND_SFTP_PROXY_PORT"));
            session = jsch.getSession(prop.getProperty("OUTBOUND_SFTP_USER_NAME"), prop.getProperty("OUTBOUND_SFTP_HOST"), Integer.parseInt(prop.getProperty("OUTBOUND_SFTP_PORT")));
            //System.out.println("Getting the session: " + session.toString());

            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(prop.getProperty("OUTBOUND_SFTP_PASSWORD"));

           // session.setProxy(new ProxyHTTP(prop.getProperty("OUTBOUND_SFTP_PROXY_HOST") , Integer.parseInt(prop.getProperty("OUTBOUND_SFTP_PROXY_PORT") )));

            session.connect();
            channel = session.openChannel("sftp");

            channel.connect();

            ChannelSftp sftpChannel = (ChannelSftp) channel;
            sftpChannel.cd(Constants.OUTBOUND_SFTP_UPLOADFILES_LOCATION);
            
            
            File f = new File(Constants.OUTPUT_ZIP_FILES_LOCATION+fileName);
            
              
            
                sftpChannel.put(new FileInputStream(f), f.getName());
            
            
            
                _logger.info("Uploaded file"+Constants.OUTPUT_ZIP_FILES_LOCATION+fileName+" per ftp to honeywell at"+prop.getProperty("OUTBOUND_SFTP_HOST"));
            Vector<ChannelSftp.LsEntry> UploadFileslist = sftpChannel.ls(Constants.OUTBOUND_SFTP_UPLOADFILES_LOCATION);

            for (ChannelSftp.LsEntry oListItem : UploadFileslist) {

                if (!oListItem.getAttrs().isDir()) {
                    sftpChannel.chmod(Integer.parseInt("755", 8), Constants.OUTBOUND_SFTP_UPLOADFILES_LOCATION + oListItem.getFilename());
                }
            }

            channel.disconnect();
            session.disconnect();

        } catch (JSchException ex) {
            _logger.info("Exception while transfering files to ftp3.bigmachines.com "+ex);
        }
        
        
        //Sending output files to resources.bigmachines.com
        
        
         try {
           // System.getProperties().put("http.proxyHost", prop.getProperty("OUTBOUND_SFTP_PROXY_HOST"));
            //System.getProperties().put("http.proxyPort",prop.getProperty("OUTBOUND_SFTP_PROXY_PORT"));
            session = jsch.getSession(prop.getProperty("TEST_OUTBOUND_SFTP_USER_NAME"), prop.getProperty("TEST_OUTBOUND_SFTP_HOST"), Integer.parseInt(prop.getProperty("TEST_OUTBOUND_SFTP_PORT")));
            //System.out.println("Getting the session: " + session.toString());

            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(prop.getProperty("TEST_OUTBOUND_SFTP_PASSWORD"));

           // session.setProxy(new ProxyHTTP(prop.getProperty("OUTBOUND_SFTP_PROXY_HOST") , Integer.parseInt(prop.getProperty("OUTBOUND_SFTP_PROXY_PORT") )));

            session.connect();
            channel = session.openChannel("sftp");

            channel.connect();

            ChannelSftp sftpChannel = (ChannelSftp) channel;
            sftpChannel.cd(Constants.TEST_OUTBOUND_SFTP_UPLOADFILES_LOCATION);
            
            
            File f = new File(Constants.OUTPUT_ZIP_FILES_LOCATION+fileName);
            
              
                sftpChannel.put(new FileInputStream(f), f.getName());
            
            
            
                _logger.info("Uploaded file"+Constants.OUTPUT_ZIP_FILES_LOCATION+fileName+" per ftp to honeywell at"+prop.getProperty("TEST_OUTBOUND_SFTP_HOST"));
            Vector<ChannelSftp.LsEntry> UploadFileslist = sftpChannel.ls(Constants.TEST_OUTBOUND_SFTP_UPLOADFILES_LOCATION);

            for (ChannelSftp.LsEntry oListItem : UploadFileslist) {

                if (!oListItem.getAttrs().isDir()) {
                    sftpChannel.chmod(Integer.parseInt("755", 8), Constants.TEST_OUTBOUND_SFTP_UPLOADFILES_LOCATION + oListItem.getFilename());
                }
            }

            channel.disconnect();
            session.disconnect();

        } catch (JSchException ex) {
            _logger.info("Exception while transfering files to resources.bigmachines.com "+ex);
        }

    }
}

