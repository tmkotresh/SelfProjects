package com.honeywell.gaeb;

import com.honeywell.utils.DescriptorArrayGenerator;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

/*

@author :Deekshith

This class contains implimentation to genertae .81 file

*/
public class GenerateGaeb81File {

	public static int lineCount = 000001;

	static Writer out = GenerateTXTFile.out;

	/*
        Method to add Intriduction sentences
        @param:gaebXMLPojo
        */
	public void addIntroSentences(GAEBXMLPojo gaebXMLPojo) throws IOException {
		Date date = new Date();
		String sysDate = new SimpleDateFormat("dd.MM.YY").format(date);
		String timeStamp = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime());
		
		out.append("00" + "        81LVergabenr. HW             Vergabenr IB           122PPPP0090 " + String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "01" + "GAEB Export                             " + sysDate + sysDate + timeStamp + sysDate + "   " + String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "02" + "GAEB Export                                                             "+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "02" +"                                                                        "+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "03" +String.format("%-72s", gaebXMLPojo.accountName.get(0).replaceAll("\\p{P}","").replaceAll("\n", "").replaceAll("\t", ""))+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "08" +String.format("%-72s", "EUR   Euro")+ String.format("%06d", lineCount));lineCount++;

		
	}
	/*
        Method to add Module Header
        @param:Sub
        */
	public void addModuleHeader(Sub sub) throws IOException
	{
		out.append('\n' + "11" +String.format("%-72s",sub.los_name_gaeb+"        N    "+sub.los_name_gaeb)+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "12" +String.format("%-72s",sub.los_name_gaeb+" :")+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "12" +String.format("%-72s",sub.los_name_gaeb+" :")+ String.format("%06d", lineCount));lineCount++;
	}
	
        /*
        Method to add Group Header
        @param:Sub
        */
	public void addGroupHeader(Sub sub) throws IOException
	{
		
		out.append('\n' + "11" +String.format("%-72s",sub.los_nr_gaeb+"0"+sub.group_nr_gaeb+"        N    "+sub.group_name_gaeb)+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "12" +String.format("%-72s",sub.group_name_gaeb+" :")+ String.format("%06d", lineCount));lineCount++;
		out.append('\n' + "12" +String.format("%-72s",sub.group_name_gaeb+" :")+ String.format("%06d", lineCount));lineCount++;
		
		}
	
          /*
        Method to add Group Footer
      
        */
	public void addGroupFooter() throws IOException
	{
		out.append('\n' + StringUtils.right("31" +String.format("%-72s",GenerateTXTFile.module + "0" + GenerateTXTFile.group)+ String.format("%06d", lineCount), 80));lineCount++;
	}
	
            /*
        Method to add Module Footer
      
        */
	public void addModuleFooter() throws IOException
	{
		out.append('\n' + StringUtils.right("31" +String.format("%-72s",GenerateTXTFile.module)+ String.format("%06d", lineCount), 80));lineCount++;
	}
	
	public void addEndSection() throws IOException
	{
		
		
		out.append('\n' + "99" + StringUtils.leftPad(StringUtils.leftPad(String.valueOf(GenerateTXTFile.total_item), 5, "0"), 72, " ")+ String.format("%06d", lineCount));lineCount++;
	}
        
             /*
        Method to add Lone Item
      @param:gaebXMLPojo
        @param:Sub
        */
	public void addLineItem(GAEBXMLPojo gaebXMLPojo,Sub sub) throws IOException
	{
		ArrayList<String> stringsDescShort = new ArrayList<String>();
		ArrayList<String> stringsLongText = new ArrayList<String>();
		int indexShrtDesc = 0;
		int indexLongDesc = 0;
		
		String descriptionShort = (sub.descriptionShort).replaceAll("[\\t\\n\\r]+"," ");
		String longText = (sub.long_text).replaceAll("[\\t\\n\\r]+"," ");
		
		byte[] winCode = longText.getBytes( "ISO-8859-1" );
		
		
		HashMap<String, String> qunatity = new HashMap<String, String>();
		
		String temp  =sub.group_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
		String index_Object_Number = (sub.los_nr_gaeb+"0"+(temp.length()>3?StringUtils.right(temp, 3):StringUtils.rightPad(temp,3,"0"))+sub.group_part_nr_gaeb+"0").replaceAll("\n", "").replaceAll("\t", "");
		
		for(String str : gaebXMLPojo.quantity_gaeb.split("<>"))
		{
                    String  tempString = str.replaceAll("\n", "").replaceAll("\t", "");
                    if((!(tempString.isEmpty()))&&(!(tempString==null)))
                    {
                        qunatity.put(tempString.split("-")[0], tempString.split("-")[1]);
                    }
			
		}
		out.append('\n' + "21"+String.format("%-72s",index_Object_Number+"  NNN         "+StringUtils.leftPad(qunatity.get(index_Object_Number), 8,"0")+"000Stck")+String.format("%06d", lineCount));lineCount++;
	
		stringsDescShort = new DescriptorArrayGenerator().createDescriptionArray(descriptionShort);
		for(String str :stringsDescShort)
		{
			out.append('\n' + "25"+String.format("%-72s",str)+String.format("%06d", lineCount));lineCount++;
		}
		
		
		stringsLongText = new DescriptorArrayGenerator().createDescriptionArray(longText);
		for(String str :stringsLongText )
		{
		
			out.append('\n' + "26"+"   "+String.format("%-72s",str)+String.format("%06d", lineCount));lineCount++;
		}
		
		
	
	}
}
