package com.honeywell.gaeb;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/*
@author:Deekshith

POJO Class for Immediate child node to main parent element

*/
public class sub_documents {
	
	@XmlElement(name = "sub")
	List<Sub> sub;

	public sub_documents(List<Sub> sub) {
		super();
		this.sub = sub;
	}

	public sub_documents() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
