package com.honeywell.gaeb;

import java.util.List;

import javax.xml.bind.annotation.*;

/*
@author :Deekshith

POJO class to map xml nodes to java object

*/
@XmlRootElement(name = "main")
public class GAEBXMLPojo {
	List<String> accountName;
	private List<sub_documents> sub_documents;
	String quantity_gaeb;
	String single_price_part_gaeb;
	String total_price_part_gaeb;
	String group_price_gaeb;
	String los_price_gaeb;
	String pricing_subtotal_net_mapping;
	String netto_post_project_mapping;
	String gaeb_version;
	String email_empfanger_gaeb;
	String cc_gaeb;
	String bcc_gaeb;
	String email_sender_gaeb;
	String subject_gaeb;
	String email_body_gaeb;
	
        /*
        Below code contains Setters and getters for the fields
        
        */
	@XmlElement(name = "email_body_gaeb")
	public String getEmail_body_gaeb() {
		return email_body_gaeb;
	}

	public void setEmail_body_gaeb(String email_body_gaeb) {
		this.email_body_gaeb = email_body_gaeb;
	}

	@XmlElement(name = "subject_gaeb")
	public String getSubject_gaeb() {
		return subject_gaeb;
	}

	public void setSubject_gaeb(String subject_gaeb) {
		this.subject_gaeb = subject_gaeb;
	}

	@XmlElement(name = "email_sender_gaeb")
	public String getEmail_sender_gaeb() {
		return email_sender_gaeb;
	}

	public void setEmail_sender_gaeb(String email_sender_gaeb) {
		this.email_sender_gaeb = email_sender_gaeb;
	}

	@XmlElement(name = "bcc_gaeb")
	public String getBcc_gaeb() {
		return bcc_gaeb;
	}

	public void setBcc_gaeb(String bcc_gaeb) {
		this.bcc_gaeb = bcc_gaeb;
	}

	@XmlElement(name = "cc_gaeb")
	public String getCc_gaeb() {
		return cc_gaeb;
	}

	public void setCc_gaeb(String cc_gaeb) {
		this.cc_gaeb = cc_gaeb;
	}

	@XmlElement(name = "email_empfanger_gaeb")
	public String getEmail_empfanger_gaeb() {
		return email_empfanger_gaeb;
	}

        /*
        constructor generated from fields
        */
	public GAEBXMLPojo(String email_empfanger_gaeb, String cc_gaeb,String bcc_gaeb,String email_sender_gaeb,String subject_gaeb,String email_body_gaeb) {
		
		this.email_empfanger_gaeb = email_empfanger_gaeb;
		this.cc_gaeb = cc_gaeb;
		this.bcc_gaeb = bcc_gaeb;
		this.email_sender_gaeb=email_sender_gaeb;
		this.subject_gaeb = subject_gaeb;
		this.email_body_gaeb = email_body_gaeb;
	}

	public void setEmail_empfanger_gaeb(String email_empfanger_gaeb) {
		this.email_empfanger_gaeb = email_empfanger_gaeb;
	}

	@XmlElement(name = "gaeb_version")
	public String getGaeb_version() {
		return gaeb_version;
	}

	public void setGaeb_version(String gaeb_version) {
		this.gaeb_version = gaeb_version;
	}

	@XmlElement(name = "netto_post_project_mapping")
	public String getNetto_post_project_mapping() {
		return netto_post_project_mapping;
	}

	public void setNetto_post_project_mapping(String netto_post_project_mapping) {
		this.netto_post_project_mapping = netto_post_project_mapping;
	}

	@XmlElement(name = "pricing_subtotal_net_mapping")
	public String getPricing_subtotal_net_mapping() {
		return pricing_subtotal_net_mapping;
	}

	public void setPricing_subtotal_net_mapping(String pricing_subtotal_net_mapping) {
		this.pricing_subtotal_net_mapping = pricing_subtotal_net_mapping;
	}

	@XmlElement(name = "los_price_gaeb")
	public String getLos_price_gaeb() {
		return los_price_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setLos_price_gaeb(String los_price_gaeb) {
		this.los_price_gaeb = los_price_gaeb;
	}

	@XmlElement(name = "group_price_gaeb")
	public String getGroup_price_gaeb() {
		return group_price_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setGroup_price_gaeb(String group_price_gaeb) {
		this.group_price_gaeb = group_price_gaeb;
	}

	@XmlElement(name = "total_price_part_gaeb")
	public String getTotal_price_part_gaeb() {
		return total_price_part_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setTotal_price_part_gaeb(String total_price_part_gaeb) {
		this.total_price_part_gaeb = total_price_part_gaeb;
	}

	@XmlElement(name = "sub_documents")
	public List<sub_documents> getSub_documents() {
		return sub_documents;
	}

	public void setSub_documents(List<sub_documents> sub_documents) {
		this.sub_documents = sub_documents;
	}
	
	@XmlElement(name = "single_price_part_gaeb")
	public String getSingle_price_part_gaeb() {
		return single_price_part_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setSingle_price_part_gaeb(String single_price_part_gaeb) {
		this.single_price_part_gaeb = single_price_part_gaeb;
	}

	public GAEBXMLPojo() {
	}
	
	public GAEBXMLPojo(List<String> accountName,List<sub_documents> sub_documents, String gaeb_version, String netto_post_project_mapping,String quantity_gaeb,String single_price_part_gaeb,String pricing_subtotal_net_mapping,String total_price_part_gaeb, String group_price_gaeb,String los_price_gaeb) {
		super();
		this.accountName = accountName;
		this.sub_documents = sub_documents;
		this.quantity_gaeb  =quantity_gaeb;
		this.single_price_part_gaeb = single_price_part_gaeb;
		this.total_price_part_gaeb = total_price_part_gaeb;
		this.group_price_gaeb = group_price_gaeb;
		this.los_price_gaeb = los_price_gaeb;
		this.pricing_subtotal_net_mapping = pricing_subtotal_net_mapping;
		this.netto_post_project_mapping = netto_post_project_mapping;
		this.gaeb_version =gaeb_version;
		
	}

	

	@XmlElement(name = "accountName")
	public List<String> getAccountName() {
		return accountName;
	}

	public void setAccountName(List<String> accountName) {
		this.accountName = accountName;
	}
  

	
	@XmlElement(name = "quantity_gaeb")
	public String getQuantity_gaeb() {
		return quantity_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setQuantity_gaeb(String quantity_gaeb) {
		this.quantity_gaeb = quantity_gaeb;
	}
	
	
	

	

	
	
}