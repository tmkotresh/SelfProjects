package com.honeywell.gaeb;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.honeywell.utils.Constants;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;

public class GaebEmailSender {
	final Logger LOGGER = Logger.getLogger(GaebEmailSender.class.getName());
        
           private static Properties properties = new Properties();
    private static InputStream input = null;
     
	/*
	 * Constructor created from super class for initialising logger file
	 * */
	public GaebEmailSender() {
		
	}
	
	/*
	 * This method will set the required env. properties and send email
	 * */
	
	public  void sendEmail(GAEBXMLPojo  geabXMLPojo) throws IOException {
		
		try {
                    
                    File folder = new File(Constants.GAEB_OUTPUT_TXT_FILES_LOCATION);
                    
                    input = new FileInputStream(Constants.CONFIG_PROPERTY);
                    properties.load(input);
                    
                    
                    Properties props = new Properties();
                    props.put("mail.smtp.username", properties.getProperty("emailUserName"));
                    props.put("mail.smtp.password", properties.getProperty("emailPassWord"));
                    props.put("mail.smtp.protocol", "smtp");
                    props.put("mail.smtp.host", properties.getProperty("hostName"));
                    props.put("mail.smtp.port", properties.getProperty("portNumber"));
                    props.put("mail.smtp.starttls.enable","true");
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.socketFactory.port", properties.getProperty("portNumber"));
                    props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                    props.put("mail.smtp.socketFactory.fallback", "false");
                    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(properties.getProperty("emailUserName"), properties.getProperty("emailPassWord"));
                        }
                    });
                    try {
                        
                        Message message = new MimeMessage(session);
                        message.setFrom(new InternetAddress(geabXMLPojo.email_sender_gaeb));
                        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(geabXMLPojo.email_empfanger_gaeb.replace(";", ",")));
                        message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(geabXMLPojo.cc_gaeb.replace(";", ",")));
                        message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(geabXMLPojo.bcc_gaeb.replace(";", ",")));
                        message.setSubject(geabXMLPojo.subject_gaeb);
                        
                        MimeBodyPart textPart = new MimeBodyPart();
                        textPart.setContent(geabXMLPojo.email_body_gaeb, "text/html; charset=utf-8");
                        
                        Multipart multipart = new MimeMultipart("mixed");
                        multipart.addBodyPart(textPart);
                        
                        for(File f : folder.listFiles())
                        {
                            addAttachment(multipart,f.getAbsolutePath());
                            
                        }
                        
                        
                        message.setContent(multipart);
                        
                        
                        Transport.send(message);
                        
                        System.out.println("successfully sent email");
                        
                    } catch (MessagingException e) {
                        e.printStackTrace();
                        
                    }
                } catch (FileNotFoundException ex) {
			Logger.getLogger(GaebEmailSender.class.getName()).log(Level.SEVERE, null, ex);
			
		}
	}

	private  void addAttachment(Multipart multipart, String filename) throws MessagingException
	{
	    DataSource source = new FileDataSource(filename);
	    BodyPart messageBodyPart = new MimeBodyPart();        
	    messageBodyPart.setDataHandler(new DataHandler(source));
	    messageBodyPart.setFileName(filename);
	    multipart.addBodyPart(messageBodyPart);
	}
}