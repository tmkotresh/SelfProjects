package com.honeywell.gaeb;

import javax.xml.bind.annotation.XmlElement;

/*
@author:Deekshith

POJO Class to Map child nodes of sub to java object

*/
public class Sub {
	
	
	String los_name_gaeb;
	String los_nr_gaeb;
	String group_nr_gaeb;
	String group_name_gaeb;
	String group_part_nr_gaeb;
	String descriptionShort;
	String long_text;
	String single_price_part_gaeb;
	

	

	@XmlElement(name = "long_text")
	public String getLong_text() {
		return long_text.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setLong_text(String long_text) {
		this.long_text = long_text.replaceAll("\n", "").replaceAll("\t", "");
	}

	@XmlElement(name = "descriptionShort")
	public String getDescriptionShort() {
		return descriptionShort.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setDescriptionShort(String descriptionShort) {
		this.descriptionShort = descriptionShort.replaceAll("\n", "").replaceAll("\t", "");
	}

	@XmlElement(name = "group_part_nr_gaeb")
	public String getGroup_part_nr_gaeb() {
		return group_part_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setGroup_part_nr_gaeb(String group_part_nr_gaeb) {
		this.group_part_nr_gaeb = group_part_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	@XmlElement(name = "group_name_gaeb")
	public String getGroup_name_gaeb() {
		return group_name_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setGroup_name_gaeb(String group_name_gaeb) {
		this.group_name_gaeb = group_name_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	@XmlElement(name = "group_nr_gaeb")
	public String getGroup_nr_gaeb() {
		return group_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setGroup_nr_gaeb(String group_nr_gaeb) {
		this.group_nr_gaeb = group_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}
    
	@XmlElement(name = "los_nr_gaeb")
	public String getLos_nr_gaeb() {
		return los_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setLos_nr_gaeb(String los_nr_gaeb) {
		this.los_nr_gaeb = los_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	@XmlElement(name = "los_name_gaeb")
	public String getLos_name_gaeb() {
		return los_name_gaeb.replaceAll("\n", "").replaceAll("\t", "");
	}

	public void setLos_name_gaeb(String los_name_gaeb) {
		this.los_name_gaeb = los_name_gaeb.replaceAll("\n", "").replaceAll("\t", "");
		
	}

	public Sub() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sub(String los_name_gaeb,String los_nr_gaeb,String group_nr_gaeb,String group_name_gaeb,String group_part_nr_gaeb, String quantity_gaeb,String descriptionShort,String long_text) {
		super();
		this.los_name_gaeb = los_name_gaeb;
		this.los_nr_gaeb = los_nr_gaeb;
		this.group_nr_gaeb = group_nr_gaeb;
		this.group_name_gaeb = group_name_gaeb;
		this.group_part_nr_gaeb = group_part_nr_gaeb;
		this.descriptionShort= descriptionShort;
		this.long_text = long_text;
		
	}
}
