package com.honeywell.gaeb;

import com.honeywell.utils.Constants;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

/*

@author : Deekshith

Class cintains the logic for calling the different parts(Header,Footer,Lineitem) for different Types of files(.81,.84 and .85)
*/
public class GenerateTXTFile {

    public static int lineCount = 000001;
    static FileWriter fileWriter;
    static File fileDir;
    static Writer out;
    static int group;
    static int module;
    static int total_item;

    static String fileNameToAppend;

    static String dateTOAppend;

    public GenerateTXTFile() {
        Date date = new Date();

        dateTOAppend = new SimpleDateFormat("ddMMYYYY").format(date);
        // System.out.println(dateTOAppend);
        File xml = new File("D:\\Tests\\GAEB\\Test1\\Quote GE-52789-2.xml");
        fileNameToAppend = xml.getName().substring(6, xml.getName().indexOf(".xml"));

    }

    /*
	 * Below Code is used for generating .81 file
	 * 
	 * */
    public void Generate81File(GAEBXMLPojo gaebXMLPojo, File f) throws IOException {
        System.out.println("inside 81");
        fileNameToAppend = f.getName().substring(6, f.getName().indexOf(".xml"));
        Sub finalSub = null;
        String group_nr_gaeb_old = null;
        String group_nr_gaeb_new = null;
        String los_nr_gaeb_old = null;
        String los_nr_gaeb_new = null;
        total_item = 0;

        group = 0;
        module = 0;
        fileDir = new File(Constants.GAEB_OUTPUT_TXT_FILES_LOCATION + dateTOAppend + "-" + fileNameToAppend + ".d81");
        fileDir.setExecutable(true, false);

        fileDir.setReadable(true, false);
        fileDir.setWritable(true, false);
        out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileDir), "Cp850"));

        new GenerateGaeb81File().addIntroSentences(gaebXMLPojo);

        for (sub_documents subDoc : gaebXMLPojo.getSub_documents()) {
            int i = 0;
            int groupOldValue = 0;
            int groupNewValue;
            int moduleOldValue = 0;
            int moduleNewValue;

            group = 1;
            module = 1;
            total_item = 0;
            for (Sub sub : subDoc.sub) {
                if (i == 0) {
                    new GenerateGaeb81File().addModuleHeader(sub);
                    new GenerateGaeb81File().addGroupHeader(sub);
                }
                i++;

                group_nr_gaeb_new = sub.group_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");
                los_nr_gaeb_new = sub.los_nr_gaeb.replaceAll("\n", "").replaceAll("\t", "");

                if (i == 1) {
                    group = 1;
                    module = 1;
                    total_item = 0;
                    new GenerateGaeb81File().addLineItem(gaebXMLPojo, sub);
                    total_item++;
                }
                if (((group_nr_gaeb_new.equalsIgnoreCase(group_nr_gaeb_old)))) {
                    if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {

                        new GenerateGaeb81File().addGroupFooter();
                        group++;
                        new GenerateGaeb81File().addModuleFooter();
                        module++;
                        new GenerateGaeb81File().addModuleHeader(sub);
                        new GenerateGaeb81File().addGroupHeader(sub);
                        new GenerateGaeb81File().addLineItem(gaebXMLPojo, sub);
                        total_item++;
                    } else {
                        new GenerateGaeb81File().addLineItem(gaebXMLPojo, sub);
                        total_item++;
                    }

                } else if ((!(group_nr_gaeb_new.equalsIgnoreCase(group_nr_gaeb_old)) && i != 1)) {
                    new GenerateGaeb81File().addGroupFooter();
                    group++;
                    if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {
                        new GenerateGaeb81File().addModuleFooter();
                        module++;
                        new GenerateGaeb81File().addModuleHeader(sub);
                        new GenerateGaeb81File().addGroupHeader(sub);
                        break;
                    }
                } else if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {
                    new GenerateGaeb81File().addGroupFooter();
                    group++;
                    new GenerateGaeb81File().addModuleFooter();
                    module++;
                    new GenerateGaeb81File().addModuleHeader(sub);
                    new GenerateGaeb81File().addGroupHeader(sub);
                }

                group_nr_gaeb_old = group_nr_gaeb_new;
                los_nr_gaeb_old = los_nr_gaeb_new;

            }
            group_nr_gaeb_old = group_nr_gaeb_new;
            los_nr_gaeb_old = los_nr_gaeb_new;
            group = Integer.parseInt(group_nr_gaeb_new);
            new GenerateGaeb81File().addGroupFooter();
            module = Integer.parseInt(los_nr_gaeb_new);
            new GenerateGaeb81File().addModuleFooter();
        }

        new GenerateGaeb81File().addEndSection();
        out.flush();
        out.close();
    }

    /*
	 * 
	 * This Code is used for generating .85 file
	 * */
    public void Generate85File(GAEBXMLPojo gaebXMLPojo, File f) throws IOException {

        fileNameToAppend = f.getName().substring(6, f.getName().indexOf(".xml"));
        Sub finalSub = null;
        String group_nr_gaeb_old = null;
        String group_nr_gaeb_new = null;
        String los_nr_gaeb_old = null;
        String los_nr_gaeb_new = null;
        total_item = 0;

        group = 0;
        module = 0;
        fileDir = new File(Constants.GAEB_OUTPUT_TXT_FILES_LOCATION + dateTOAppend + "-" + fileNameToAppend + ".d85");
        fileDir.setExecutable(true, false);

        fileDir.setReadable(true, false);
        fileDir.setWritable(true, false);
        out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileDir), "Cp850"));

        new GenerateGaeb85File().addIntroSentences(gaebXMLPojo);

        for (sub_documents subDoc : gaebXMLPojo.getSub_documents()) {
            int i = 0;
            int groupOldValue = 0;
            int groupNewValue;
            int moduleOldValue = 0;
            int moduleNewValue;

            group = 1;
            module = 1;
            total_item = 0;
            for (Sub sub : subDoc.sub) {
                if (i == 0) {
                    new GenerateGaeb85File().addModuleHeader(sub);
                    new GenerateGaeb85File().addGroupHeader(sub);
                }
                i++;

                group_nr_gaeb_new = sub.group_nr_gaeb;
                los_nr_gaeb_new = sub.los_nr_gaeb;

                if (i == 1) {
                    group = 1;
                    module = 1;
                    total_item = 0;
                    new GenerateGaeb85File().addLineItem(gaebXMLPojo, sub);
                    total_item++;
                }
                if (((group_nr_gaeb_new.equalsIgnoreCase(group_nr_gaeb_old)))) {
                    if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {

                        new GenerateGaeb85File().addGroupFooter(gaebXMLPojo, finalSub, group_nr_gaeb_new);
                        group++;
                        new GenerateGaeb85File().addModuleFooter(gaebXMLPojo, group_nr_gaeb_new);
                        module++;
                        new GenerateGaeb85File().addModuleHeader(sub);
                        new GenerateGaeb85File().addGroupHeader(sub);
                        new GenerateGaeb85File().addLineItem(gaebXMLPojo, sub);
                        total_item++;
                    } else {
                        new GenerateGaeb85File().addLineItem(gaebXMLPojo, sub);
                        total_item++;
                    }

                } else if ((!(group_nr_gaeb_new.equalsIgnoreCase(group_nr_gaeb_old)) && i != 1)) {
                    new GenerateGaeb85File().addGroupFooter(gaebXMLPojo, finalSub, group_nr_gaeb_new);
                    group++;
                    if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {
                        new GenerateGaeb85File().addModuleFooter(gaebXMLPojo, group_nr_gaeb_new);
                        module++;
                        new GenerateGaeb85File().addModuleHeader(sub);
                        new GenerateGaeb85File().addGroupHeader(sub);
                        break;
                    }
                } else if ((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1)) {
                    new GenerateGaeb85File().addGroupFooter(gaebXMLPojo, finalSub, group_nr_gaeb_new);
                    group++;
                    new GenerateGaeb85File().addModuleFooter(gaebXMLPojo, group_nr_gaeb_new);
                    module++;
                    new GenerateGaeb85File().addModuleHeader(sub);
                    new GenerateGaeb85File().addGroupHeader(sub);
                }

                group_nr_gaeb_old = group_nr_gaeb_new;
                los_nr_gaeb_old = los_nr_gaeb_new;
                finalSub = sub;

            }
            group_nr_gaeb_old = group_nr_gaeb_new;
            los_nr_gaeb_old = los_nr_gaeb_new;
            group = Integer.parseInt(group_nr_gaeb_new);
            new GenerateGaeb85File().addGroupFooter(gaebXMLPojo, finalSub, group_nr_gaeb_new);
            module = Integer.parseInt(los_nr_gaeb_new);
            new GenerateGaeb85File().addModuleFooter(gaebXMLPojo, group_nr_gaeb_new);
        }

        new GenerateGaeb85File().addEndSection(gaebXMLPojo);
        out.flush();
        out.close();
    }

    /*
	 * 
	 * This Code is used for generating .84 file
	 * */
    public void Generate84File(GAEBXMLPojo gaebXMLPojo, File f) throws IOException {

        fileNameToAppend = f.getName().substring(6, f.getName().indexOf(".xml"));
        group = 0;
        module = 0;
        total_item = 0;
      Sub finalSub=null;
         String los_nr_gaeb_old = null;
        String los_nr_gaeb_new = null;
        fileDir = new File(Constants.GAEB_OUTPUT_TXT_FILES_LOCATION + dateTOAppend + "-" + fileNameToAppend + ".d84");
        fileDir.setExecutable(true, false);

        fileDir.setReadable(true, false);
        fileDir.setWritable(true, false);
        out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileDir), "Cp850"));
        new GenerateGaeb84File().addIntroSentences(gaebXMLPojo);

        for (sub_documents subDoc : gaebXMLPojo.getSub_documents()) {
              int i = 0 ;
          
          
            for (Sub sub : subDoc.sub) {
                  i++;
                    los_nr_gaeb_new = sub.los_nr_gaeb;
                   if (i == 1) {
                    group = 1;
                    module = 1;
                    total_item = 0;
                    new GenerateGaeb84File().addLineItem(gaebXMLPojo, sub);
                    total_item++;
                }
               
                 if(((los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1))
                 {
                        new GenerateGaeb84File().addLineItem(gaebXMLPojo, sub);
                         total_item++;
                 }
                 if((!(los_nr_gaeb_new.equalsIgnoreCase(los_nr_gaeb_old)) && i != 1))
                 {
                     
                      new GenerateGaeb84File().addGroupFooter(gaebXMLPojo,finalSub);
            new GenerateGaeb84File().addModuleFooter(gaebXMLPojo,finalSub);
             new GenerateGaeb84File().addLineItem(gaebXMLPojo, sub);
              total_item++;
                 }
             
                group++;
                module++;
               
                los_nr_gaeb_old = los_nr_gaeb_new;
                finalSub=sub;
            }
             new GenerateGaeb84File().addGroupFooter(gaebXMLPojo,finalSub);
            new GenerateGaeb84File().addModuleFooter(gaebXMLPojo,finalSub);
            
        }
        new GenerateGaeb84File().addEndSection(gaebXMLPojo);
        out.flush();
        out.close();
    }

}
