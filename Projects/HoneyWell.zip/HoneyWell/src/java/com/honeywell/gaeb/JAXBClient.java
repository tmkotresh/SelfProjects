package com.honeywell.gaeb;

import com.honeywell.utils.Constants;
import java.io.File;
import java.io.IOException;

import javax.xml.bind.*;

public class JAXBClient {

    static String fileNameToAppend;

    static String dateTOAppend;

    public static void main(String[] args) throws JAXBException, IOException {
        new JAXBClient().InitializeGAEBReport();
    }

    public void InitializeGAEBReport() throws JAXBException, IOException {
        JAXBContext jc = JAXBContext.newInstance(GAEBXMLPojo.class);
        GAEBXMLPojo gaebXMLPojo = null ;
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        File folder = new File(Constants.GAEB_INPUT_XML_FILES_LOCATION);

        for (File f : folder.listFiles()) {

             

            if (f.getName().contains(".xml")) {
                gaebXMLPojo = (GAEBXMLPojo) unmarshaller.unmarshal(f);
                for (String str : gaebXMLPojo.gaeb_version.split("\\~")) {
                    String temp = str.trim().replaceAll("\n", "").replaceAll("\t", "");
                    switch (temp) {
                        case "D81":
                            new GenerateTXTFile().Generate81File(gaebXMLPojo, f);
                            break;
                        case "D84":
                            new GenerateTXTFile().Generate84File(gaebXMLPojo, f);
                            break;
                        case "D85":
                            new GenerateTXTFile().Generate85File(gaebXMLPojo, f);
                            break;
                    }
                }

            }
        //    new GaebEmailSender().sendEmail(gaebXMLPojo);
        }

//        File outputFolder = new File(Constants.GAEB_OUTPUT_TXT_FILES_LOCATION);
//        try {
//            for (File f : outputFolder.listFiles()) {
//                f.setExecutable(true, false);
//                f.setReadable(true, false);
//                f.setWritable(true, false);
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//
//        }

        System.out.println("done");

    }

}
