package com.honeywell.gaeb;

import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

/*

@author :Deekshith

This class contains implimentation to genertae .84 file

*/

public class GenerateGaeb84File {

	static int lineCount = 000001;
	static Writer out = GenerateTXTFile.out;
	static HashMap<String, String> SINGLE_PRICE = new HashMap<String, String>();
	static HashMap<String, String> TOTAL_PRICE = new HashMap<String, String>();
	static HashMap<String, String> GROUP_PRICE = new HashMap<String, String>();
	static HashMap<String, String> LOS_PRICE = new HashMap<String, String>();
        
        /*
        Method to add Intriduction sentences
        @param:gaebXMLPojo
        */
	public void addIntroSentences(GAEBXMLPojo gaebXMLPojo) throws IOException
	{
		Date date = new Date();
		String sysDate = new SimpleDateFormat("dd.MM.YY").format(date);
		String timeStamp = new SimpleDateFormat("HH:mm").format(Calendar.getInstance().getTime());
		out.append("00" + "        84 Vergabenr. HW             Vergabenr IB           122PPPP0090 " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"01" + "GAEB Export                             " + sysDate + sysDate + timeStamp+ sysDate + "X  " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"02" + "GAEB Export                                                             " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"02" + "                                                                        " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"03" + "Honeywell                                                               " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"04" + "Ingenieurbüro                                                           " + String.format("%06d", lineCount));lineCount++;
		out.append("\n"+"08" + String.format("%-72s", "EUR   Euro") + String.format("%06d", lineCount));lineCount++;
	
	}
	
              /*
        Method to add Lone Item
      @param:gaebXMLPojo
        @param:Sub
        */
	public void addLineItem(GAEBXMLPojo gaebXMLPojo,Sub sub) throws IOException
	{
		
		String temp  =sub.group_nr_gaeb;
		String index_Object_Number = sub.los_nr_gaeb+"0"+(temp.length()>3?StringUtils.right(temp, 3):StringUtils.rightPad(temp,3,"0"))+sub.group_part_nr_gaeb+"0";
		for(String str : gaebXMLPojo.single_price_part_gaeb.split("<>"))
		{
                     String  tempString = str.replaceAll("\n", "").replaceAll("\t", "");
                    if((!(tempString.isEmpty()))&&(!(tempString==null)))
                    {
                        SINGLE_PRICE.put(tempString.split("-")[0], tempString.split("-")[1]);
                    }
                    
			
		}
		
		for(String str : gaebXMLPojo.total_price_part_gaeb.split("<>"))
		{
                     String  tempString = str.replaceAll("\n", "").replaceAll("\t", "");
                    if((!(tempString.isEmpty()))&&(!(tempString==null)))
                    {
                        TOTAL_PRICE.put(tempString.split("-")[0], tempString.split("-")[1]);
                    }
			
		}
		out.append("\n"+"23" + String.format("%-72s", index_Object_Number+ "   "+StringUtils.leftPad(SINGLE_PRICE.get(index_Object_Number).replaceAll("\\.", "")+"0", 11,"0")+ "   "+StringUtils.leftPad(TOTAL_PRICE.get(index_Object_Number).replaceAll("\\.", ""), 12,"0")) + String.format("%06d", lineCount));lineCount++;
	}
	
           /*
        Method to add Group Footer
     @param:gaebXMLPojo
        @param:Sub
        */
	public void addGroupFooter(GAEBXMLPojo gaebXMLPojo,Sub sub) throws IOException
	{
		
		String temp  =sub.group_nr_gaeb;
		String index_Object_Number = sub.los_nr_gaeb+"0"+sub.group_nr_gaeb;
		
		for(String str : gaebXMLPojo.group_price_gaeb.split("<>"))
		{
                    String  tempString = str.replaceAll("\n", "").replaceAll("\t", "");
                    if((!(tempString.isEmpty()))&&(!(tempString==null)))
                    {
                        GROUP_PRICE.put(tempString.split("-")[0], tempString.split("-")[1]);
                    }
			
		}
		
		out.append("\n"+"32" + String.format("%-72s", sub.los_nr_gaeb+"0"+sub.group_nr_gaeb+"       "+StringUtils.leftPad(GROUP_PRICE.get(index_Object_Number).replaceAll("\\.", ""), 12,"0")) + String.format("%06d", lineCount));lineCount++;
	}
	
            /*
        Method to add Module Footer
      @param:gaebXMLPojo
        @param:Sub
        */
	public void addModuleFooter(GAEBXMLPojo gaebXMLPojo,Sub sub) throws IOException
	{
		
		
		String index_Object_Number = sub.los_nr_gaeb;
		for(String str : gaebXMLPojo.los_price_gaeb.split("<>"))
		{
                     String  tempString = str.replaceAll("\n", "").replaceAll("\t", "");
                    if((!(tempString.isEmpty()))&&(!(tempString==null)))
                    {
                        LOS_PRICE.put(tempString.split("-")[0], tempString.split("-")[1]);
                    }
			
		}
		
		out.append("\n"+"32" + String.format("%-72s",index_Object_Number+"         " +StringUtils.leftPad(LOS_PRICE.get(index_Object_Number).replaceAll("\\.", ""), 12,"0")) + String.format("%06d", lineCount));lineCount++;
	}
	
            /*
        Method to add End Section
       @param:gaebXMLPojo
        
        */
	public void addEndSection(GAEBXMLPojo gaebXMLPojo) throws IOException
	{
		String VAT_AND_TOTAL_WITH_VAT = "19"+StringUtils.leftPad(gaebXMLPojo.netto_post_project_mapping.replaceAll("\\.", ""), 14, "0");
		String total = StringUtils.leftPad(gaebXMLPojo.pricing_subtotal_net_mapping.replaceAll("\\.", ""), 12, "0");
		String intermediate_result2 = StringUtils.rightPad(total+"         "+VAT_AND_TOTAL_WITH_VAT, 67, " ");
		
                String intermediateResult3 = StringUtils.leftPad(String.valueOf(GenerateTXTFile.total_item), 5, "0");
		
                System.out.println("intermediate_result2 is "+intermediate_result2);
                System.out.println("intermediate_result3 is "+intermediateResult3);
                out.append("\n"+"99" + String.format("%-72s", intermediate_result2+intermediateResult3) + String.format("%06d", lineCount));lineCount++;
	}
	
}






